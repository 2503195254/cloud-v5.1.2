<?php
namespace app\index\controller;
use think\Controller;
use think\Db;

/**
 * 授权插件：前台页面
 *  - query：免登录授权查询页（/license-query）
 *  - my：用户中心「我的授权」/user/mylicense（查看+下载附件）
 */
class License extends Controller
{
    protected $web;

    public function _initialize()
    {
        $this->web = Db::name('web')->where('id', 1)->find();
    }

    /** 插件是否安装 */
    protected function plugLoaded()
    {
        $entry = PATH . 'plugins/license/license/license.php';
        $installed = 0;
        try { $installed = Db::name('plugin')->where('code', 'license')->find() ? 1 : 0; } catch (\Throwable $e) {}
        if (!is_file($entry) || !$installed) return false;
        include_once $entry;
        return true;
    }

    /** 本系统授权状态（供前台横幅 JS 检测；未启用本地验证时返回 enabled=0） */
    public function status()
    {
        $this->plugLoaded();
        $data = ['enabled' => 0, 'valid' => 0, 'msg' => '', 'domain' => ''];
        // 统一使用主系统内嵌授权检测（总是可用，授权后 code=1 则横幅消失）
        if (function_exists('vhss_system_license')) {
            $r = vhss_system_license();
            $code = (int)($r['code'] ?? 0);
            $data['enabled'] = 1;
            $data['valid']   = ($code === 1) ? 1 : 0;
            $data['msg']     = isset($r['msg']) ? $r['msg'] : '';
            $data['domain']  = isset($r['domain']) ? $r['domain'] : '';
        }
        return json($data);
    }

    /** 免登录授权查询页 */
    public function query()
    {
        $this->plugLoaded();
        $result = null;
        $kw = trim(input('kw'));
        if ($kw !== '') {
            $result = [
                'kw' => $kw,
                'found' => 0,
                'list' => [],
            ];
            if (function_exists('license_dispatch') && function_exists('license_api_query')) {
                // 走插件查询
                ob_start();
                try {
                    $cfg = license_config();
                    if (function_exists('license_verify')) {
                        $list = [];
                        try {
                            $q = Db::name('license');
                            $rows = $q->select();
                            foreach ($rows as $r) {
                                $codeUp = strtoupper($kw);
                                $kwLow = strtolower($kw);
                                if (strtoupper($r['code']) === $codeUp || in_array($kwLow, license_domains($r['domains']))) {
                                    $v = license_verify($r['code'], $kwLow);
                                    $list[] = [
                                        'code' => $r['code'], 'product' => $r['product'], 'uname' => $r['uname'],
                                        'type' => $r['type'], 'status' => $r['status'], 'expire_time' => $r['expire_time'],
                                        'domains' => license_domains($r['domains']),
                                        'valid' => ($v['code'] === 1) ? 1 : 0,
                                        'state_msg' => $v['code'] === 1 ? '有效' : $v['msg'],
                                        'level_name' => $r['level_name'] ?? '',
                                        'edition' => !empty($r['level_name']) ? $r['level_name'] : ($r['product'] ?? ''),
                                    ];
                                }
                            }
                        } catch (\Throwable $e) {}
                        $result['list'] = $list;
                        $result['found'] = count($list);
                    }
                } catch (\Throwable $e) {}
                ob_end_clean();
            }
        }
        return $this->fetch(APP_PATH . 'index/view/' . ($this->web['template'] ?? 'default') . '/licensequery.html', [
            'webname' => $this->web['name'], 'description' => $this->web['description'], 'keywords' => $this->web['keywords'], 'favicon' => $this->web['favicon'],
            'result' => $result,
        ]);
    }

    /** 用户中心：我的授权 */
    public function my()
    {
        if (!session("userid")) { $this->redirect('/login'); return; }
        $this->plugLoaded();
        $user = Db::name('user')->where('id', session("userid"))->find();
        $licenses = function_exists('license_by_user') ? license_by_user(session("userid")) : [];
        $self = function_exists('license_self_cfg') ? license_self_cfg() : ['reset_price'=>5,'upgrade_price'=>10];
        return $this->fetch(APP_PATH . 'index/view/' . ($this->web['template'] ?? 'default') . '/user/mylicense.html', [
            'webname' => $this->web['name'], 'description' => $this->web['description'], 'keywords' => $this->web['keywords'], 'favicon' => $this->web['favicon'],
            'user' => $user, 'licenses' => $licenses, 'self' => $self,
        ]);
    }

    /** 用户中心：授权自助操作（重置绑定/提升域名上限，付费） */
    public function selfdo()
    {
        if (!session("userid")) { return json(['code' => -1, 'msg' => '请先登录']); }
        $this->plugLoaded();
        $action = trim(input('action'));
        $id = intval(input('id'));
        if (!function_exists('license_user_pay')) return json(['code' => -1, 'msg' => '授权功能未就绪']);
        $r = license_user_pay(session("userid"), $id, $action);
        return json(['code' => $r['code'], 'msg' => $r['msg']]);
    }

    /** 下载附件（需登录 + 属于该用户的授权） */
    public function download()
    {
        if (!session("userid")) { exit('请先登录'); }
        $aid = intval(input('aid'));
        $this->plugLoaded();
        try {
            $a = Db::name('license_attach')->where('id', $aid)->find();
            if (!$a) exit('附件不存在');
            $lic = Db::name('license')->where('id', $a['license_id'])->find();
            if (!$lic || $lic['userid'] != session("userid")) exit('无权下载');
            $file = PATH . 'public/' . $a['filepath'];
            if (!is_file($file)) exit('文件不存在');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $a['filename'] . '"');
            header('Content-Length: ' . filesize($file));
            readfile($file);
            exit;
        } catch (\Throwable $e) { exit('下载失败'); }
    }
}