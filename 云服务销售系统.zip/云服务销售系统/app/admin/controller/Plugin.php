<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;
use think\Request;

/**
 * 通用插件管理系统
 * 支持：扫描插件 / 安装 / 卸载 / 启用停用 / 配置
 * 插件存放于根目录 plugins/ 下，每个插件为一个子目录。
 * 插件约定：plugins/{类型}/{插件标识}/插件标识.php 为入口文件，
 * 入口文件可定义: 插件信息数组 + 安装/卸载/配置逻辑。
 */
class Plugin extends Controller
{
    protected $root;      // 网站根目录
    protected $columns;   // yun_plugin 表字段约束（建表用）

    public function _initialize()
    {
        if (!session("adminid")) {
            $this->redirect(admin_url('/login'));
        }
        $this->user = Db::name('admin')->where('id', session("adminid"))->find();
        $this->web  = Db::name('web')->where('id', 1)->find();
        $this->root = PATH; // 如 /path/to/project/
        // 授权插件是否启用（仅启用后后台菜单才显示"授权管理"）
$pl = 0;
        if (is_file(PATH . 'plugins/license/license/license.php')) {
            try { $plRow = Db::name('plugin')->where('code', 'license')->find(); if ($plRow && (int)$plRow['status'] == 1) $pl = 1; } catch (\Throwable $e) {}
        }
        $this->assign('plug_license', $pl);
        // 内嵌系统授权（供后台横幅显示）
        $sysLic = function_exists('vhss_system_license') ? vhss_system_license() : ['code'=>-1,'msg'=>'','domain'=>'','edition'=>''];
        $this->assign('sys_lic', $sysLic);
        $this->assign('sys_lic_msg', $sysLic['msg'] ?? '');
        $this->assign('sys_lic_domain', $sysLic['domain'] ?? '');
        $this->columns = [
            'id'        => 'int(11) NOT NULL AUTO_INCREMENT',
            'name'      => "varchar(100) NOT NULL DEFAULT ''",  // 插件名称
            'type'      => "varchar(50) NOT NULL DEFAULT 'other'", // 类型：api/pay/host/template/other
            'code'      => "varchar(100) NOT NULL DEFAULT ''",  // 插件唯一标识(目录名)
            'version'   => "varchar(30) NOT NULL DEFAULT '1.0.0'",
            'desc'      => "varchar(500) NOT NULL DEFAULT ''",
            'status'    => "tinyint(1) NOT NULL DEFAULT '0'",   // 1=启用 0=停用
            'config'    => "text",                               // 插件配置(JSON)
            'installtime'=>"int(11) NOT NULL DEFAULT '0'",
            'PRIMARY KEY (`id`), UNIQUE KEY `code` (`code`)',
        ];
        $this->ensureTable();
        $this->ensureDefaultPlugins();
        $this->assign([
            'webname'   => isset($this->web['name']) ? $this->web['name'] : '',
            'user'      => $this->user,
            'admin_path'=> admin_path(),
        ]);
    }

    /** 确保 yun_plugin 表存在 */
    protected function ensureTable()
    {
        @clearstatcache(true);
        try {
            $exists = Db::query("SHOW TABLES LIKE 'yun_plugin'");
        } catch (\Throwable $e) { $exists = []; }
        // 判断表是否存在
        if (empty($exists)) {
            $defs = [];
            foreach (array_slice($this->columns, 0, -1) as $k => $v) $defs[] = "`$k` $v";
            $defs[] = $this->columns['PRIMARY KEY'];
            $sql = "CREATE TABLE IF NOT EXISTS `yun_plugin` (" . implode(", ", $defs) . ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
            try { Db::execute($sql); } catch (\Throwable $e) {}
        }
    }

    /**
     * 默认已安装插件：源码自带的原有插件（服务器插件 default/easypanel/mnbt、支付插件 epay/f2fpay）
     * 首次进后台自动补齐为「已安装」并默认「启用」；
     * 已存在但仍停用的默认插件，也会在此自动置为启用（保证既有库同样生效）。
     * 说明：api 对接插件与 license 授权插件不在默认清单内，保持由用户手动安装/启用。
     */
    protected function ensureDefaultPlugins()
    {
        $defaults = [
            ['type'=>'host', 'code'=>'default'],
            ['type'=>'host', 'code'=>'easypanel'],
            ['type'=>'host', 'code'=>'mnbt'],
            ['type'=>'pay',  'code'=>'epay'],
            ['type'=>'pay',  'code'=>'f2fpay'],
        ];
        try {
            $installed = [];
            $rows = Db::name('plugin')->field('code')->select();
            foreach ($rows as $r) $installed[$r['code']] = 1;
            foreach ($defaults as $d) {
                $type = $d['type']; $code = $d['code'];
                // 入口存在性：host 用 {code}.php；pay 插件入口为 set.php（go/notify/return/set）
                $entry = $this->root . 'plugins/' . $type . '/' . $code . '/' . $code . '.php';
                if ($type === 'pay') {
                    $entry2 = $this->root . 'plugins/' . $type . '/' . $code . '/set.php';
                    if (!is_file($entry2)) continue;
                    $entry = $entry2; // pay 插件配置入口为 set.php
                } elseif (!is_file($entry)) continue;
                if (isset($installed[$code])) {
                    // 已安装：确保默认插件处于启用状态
                    Db::name('plugin')->where('code', $code)->update(['status' => 1]);
                    continue;
                }
                // pay 插件用友好名称
                if ($type === 'pay') {
                    $nameMap = ['epay' => '易支付', 'f2fpay' => '当面付'];
                    $info = ['name' => isset($nameMap[$code]) ? $nameMap[$code] : $code, 'type' => $type, 'code' => $code, 'version' => '1.0.0', 'desc' => $code . ' 支付插件'];
                } else {
                    $info = $this->readInfo($type, $code, $entry);
                    if (!$info) continue;
                }
                // 加载安装钩子（若存在）
                if (file_exists($entry)) {
                    if (!function_exists($code . '_plugin_install')) { $this->loadPluginEntry($entry, $code); }
                    $this->callHook($code, 'plugin_install');
                }
                Db::name('plugin')->insert([
                    'name' => $info['name'], 'type' => $type, 'code' => $code,
                    'version' => $info['version'], 'desc' => $info['desc'],
                    'status' => 1, 'config' => '', 'installtime' => time(),
                ]);
                $installed[$code] = 1;
            }
        } catch (\Throwable $e) {}
    }

    /** 扫描插件目录，返回可用插件列表 */
    protected function scanPlugins()
    {
        $out = [];
        $base = $this->root . 'plugins';
        if (!is_dir($base)) return $out;
        $types = @scandir($base);
        foreach ($types as $t) {
            if ($t === '.' || $t === '..' || !is_dir($base . '/' . $t)) continue;
            $tdir = $base . '/' . $t;
            $plugs = @scandir($tdir);
            foreach ($plugs as $p) {
                if ($p === '.' || $p === '..' || !is_dir($tdir . '/' . $p)) continue;
                // API 对接插件统一由 plugins/api/api 登记（type=api, code=api），
                // 排除 host 目录下的同标识 api，避免出现“api 对接 与 api”两个重复插件。
                if ($t === 'host' && $p === 'api') continue;
                $entry = $tdir . '/' . $p . '/' . $p . '.php';
                if (!file_exists($entry)) {
                    // 也可能入口文件名不同，尝试读取目录内第一个 php
                    $files = glob($tdir . '/' . $p . '/*.php');
                    $entry = $files ? $files[0] : '';
                }
                $info = $this->readInfo($t, $p, $entry);
                if ($info) $out[] = $info;
            }
        }
        return $out;
    }

    /** 读取插件信息(仅当入口文件为 {code}.php 且含 $plugin_info 才 include，避免误执行只会 exit 的支付回调脚本) */
    protected function readInfo($type, $code, $entry)
    {
        $info = [
            'type' => $type, 'code' => $code,
            'name' => $code, 'version' => '1.0.0',
            'desc' => '', 'entry' => $entry,
        ];
        // 仅接受入口文件名与插件标识完全一致的 .php，防止把 go.php/return.php/notify.php 当成插件入口去 include
        if ($entry && is_file($entry) && basename($entry) === $code . '.php') {
            $plugin_info = [];
            // 用函数包裹 include，隔离 $plugin_info 但不执行会 exit 的顶层代码
            $__f = function () use ($entry, &$plugin_info) { $plugin_info = []; include_once $entry; return isset($plugin_info); };
            try { $__f(); } catch (\Throwable $e) {}
            if (!empty($plugin_info) && is_array($plugin_info)) {
                $info = array_merge($info, $plugin_info);
            }
        }
        return $info;
    }

    /** 插件类型 → 中文名映射 */
    protected function typeNames()
    {
        return [
            'api'    => '对接插件',
            'host'   => '服务器插件',
            'pay'    => '支付插件',
            'license'=> '授权插件',
            'template'=> '模板插件',
            'other'  => '功能插件',
        ];
    }

    /** 插件列表页（支持分类 + 搜索） */
    public function index()
    {
        $typeFilter = trim(input('type'));
        $kw = trim(input('kw'));
        $typeNames = $this->typeNames();
        $plugins = $this->scanPlugins();
        // 合并已安装状态
        $installed = Db::name('plugin')->select();
        $map = [];
        foreach ($installed as $r) $map[$r['code']] = $r;
        $list = [];
        foreach ($plugins as $p) {
            $p['installed'] = isset($map[$p['code']]);
            $p['status'] = $p['installed'] ? $map[$p['code']]['status'] : 0;
            $p['config'] = $p['installed'] ? $map[$p['code']]['config'] : '';
            $p['type_name'] = isset($typeNames[$p['type']]) ? $typeNames[$p['type']] : $p['type'];
            // 配置引导提示：已安装但可能尚未正式配置的插件，给出「去配置」指引
            $p['setup_hint'] = '';
            try {
                if ($p['installed']) {
                    if ($p['type'] === 'host' && $p['code'] !== 'api') {
                        // 服务器插件：是否有服务器使用它
                        $used = Db::name('server')->where('serverplugins', $p['code'])->count();
                        $p['setup_hint'] = $used > 0 ? '已在服务器中配置使用' : '请前往「产品设置 → 服务器」添加服务器并选用该插件';
                    } elseif ($p['type'] === 'pay') {
                        $p['setup_hint'] = '请前往「支付」页面配置支付接口';
                    } elseif ($p['type'] === 'template') {
                        $p['setup_hint'] = '该模板为前台页面展示模板';
                    }
                }
            } catch (\Throwable $e) {}
            // 分类过滤
            if ($typeFilter !== '' && $p['type'] !== $typeFilter) continue;
            // 关键搜索（名称/标识/类型中文）
            if ($kw !== '') {
                $kwLow = strtolower($kw);
                if (
                    stripos($p['name'], $kw) === false &&
                    stripos($p['code'], $kwLow) === false &&
                    stripos($p['type'], $kwLow) === false &&
                    stripos($p['type_name'], $kw) === false
                ) continue;
            }
            $list[] = $p;
        }
        return $this->fetch(APP_PATH . 'admin/view/' . $this->web['admintemplate'] . '/plugin.html', [
            'plugin' => $list, 'type_filter' => $typeFilter, 'kw' => $kw, 'typeNames' => $typeNames,
        ]);
    }

    /** 调用插件钩子：优先 {$code}_{$hook}（带前缀，避免多插件函数冲突），否则 {$hook}（兼容旧的无前缀插件）
     * @param mixed ...$args 传给钩子的参数 */
    protected function callHook($code, $hook, ...$args)
    {
        // 带前缀
        if (function_exists($code . '_' . $hook)) { return @call_user_func_array($code . '_' . $hook, $args); }
        // 无前缀（旧插件）
        if (function_exists($hook)) { return @call_user_func_array($hook, $args); }
        return null;
    }

    /** 加载单个插件入口（include_once，仅当同名函数未声明时避免重复加载冲突） */
    protected function loadPluginEntry($entry, $code)
    {
        if (is_file($entry)) { include_once $entry; }
    }

    /** 安装插件 */
    public function install()
    {
        $code   = trim(input('code'));
        $type   = trim(input('type'));
        if (!$code || !$type) return json(['code' => -1, 'msg' => '参数错误']);
        $entry = $this->root . 'plugins/' . $type . '/' . $code . '/' . $code . '.php';
        $info = $this->readInfo($type, $code, $entry);
        // 运行插件安装钩子（仅加载目标插件入口，避免重复声明）
        if (file_exists($entry)) {
            if (!function_exists($code . '_plugin_install') || true) { $this->loadPluginEntry($entry, $code); }
            $r = $this->callHook($code, 'plugin_install');
            if ($r === false) return json(['code' => -1, 'msg' => '安装失败']);
        }
        $exists = Db::name('plugin')->where('code', $code)->find();
        if ($exists) return json(['code' => -1, 'msg' => '插件已安装']);
        Db::name('plugin')->insert([
            'name' => $info['name'], 'type' => $type, 'code' => $code,
            'version' => $info['version'], 'desc' => $info['desc'],
            'status' => 0, 'config' => '', 'installtime' => time(),
        ]);
        return json(['code' => 1, 'msg' => '安装成功']);
    }

    /** 卸载插件 */
    public function uninstall()
    {
        $code = trim(input('code'));
        $type = trim(input('type'));
        if (!$code) return json(['code' => -1, 'msg' => '参数错误']);
        $entry = $this->root . 'plugins/' . $type . '/' . $code . '/' . $code . '.php';
        if (file_exists($entry)) {
            $this->loadPluginEntry($entry, $code);
            $this->callHook($code, 'plugin_uninstall');
        }
        Db::name('plugin')->where('code', $code)->delete();
        return json(['code' => 1, 'msg' => '卸载成功']);
    }

    /** 启用/停用 */
    public function setstatus()
    {
        $code = trim(input('code'));
        $status = intval(input('status')) ? 1 : 0;
        if (!$code) return json(['code' => -1, 'msg' => '参数错误']);
        if ($status) {
            // 启用插件时自动保存一次配置数据（若尚未保存过）
            try {
                $row = Db::name('plugin')->where('code', $code)->find();
                $type = $row ? $row['type'] : '';
                $cfgSaved = !empty($row['config']);
                $cfgJson = $row['config'] ?? '';
                $curCfg = ($cfgJson !== '') ? json_decode($cfgJson, true) : null;
                if (!$cfgSaved || !is_array($curCfg) || empty($curCfg)) {
                    if ($type) {
                        $fields = $this->configFields($type, $code);
                        $cfg = [];
                        if (is_array($fields)) {
                            foreach ($fields as $f) {
                                $n = isset($f['name']) ? $f['name'] : '';
                                if ($n === '') continue;
                                $cfg[$n] = isset($f['default']) ? $f['default'] : '';
                            }
                        }
                        if (!empty($cfg)) {
                            Db::name('plugin')->where('code', $code)->update(['config' => json_encode($cfg)]);
                            $entry = $this->root . 'plugins/' . $type . '/' . $code . '/' . $code . '.php';
                            if (file_exists($entry)) { $this->loadPluginEntry($entry, $code); $this->callHook($code, 'plugin_config_save', $cfg); }
                        }
                    }
                }
            } catch (\Throwable $e) {}
        }
        Db::name('plugin')->where('code', $code)->update(['status' => $status]);
        return json(['code' => 1, 'msg' => $status ? '已启用' : '已停用']);
    }

    /** 触发插件“同步”类操作（如拉取上级API商品）。约定插件暴露 {code}_sync() 返回 [code,msg,data] */
    public function sync()
    {
        $code = trim(input('code'));
        if (!$code) return json(['code' => -1, 'msg' => '参数错误']);
        $entry = PATH . 'plugins/api/' . $code . '/' . $code . '.php';
        if ($code !== 'api' || !file_exists($entry)) return json(['code' => -1, 'msg' => '该插件不支持同步']);
        include_once $entry;
        $fn = $code . '_sync_products';
        if (!function_exists($fn)) return json(['code' => -1, 'msg' => '插件未提供同步函数']);
        $r = call_user_func($fn, 'admin');
        return json(['code' => $r['code'], 'msg' => $r['msg'], 'synced' => $r['synced'] ?? 0]);
    }

    /** 插件配置页 */
    public function config()
    {
        $code = trim(input('code'));
        $type = trim(input('type'));
        $row = Db::name('plugin')->where('code', $code)->find();
        if (!$row) $this->redirect(admin_url('/plugin'));
        $fields = $this->configFields($type, $code);
        if (Request::instance()->isPost()) {
            $data = input('post.');
            $cfg = [];
            foreach ($fields as $f) {
                $n = $f['name'];
                $cfg[$n] = isset($data[$n]) ? (is_array($data[$n]) ? json_encode($data[$n]) : $data[$n]) : '';
            }
            Db::name('plugin')->where('code', $code)->update(['config' => json_encode($cfg)]);
            // 调用插件保存钩子（带前缀，兼容无前缀）
            $entry = $this->root . 'plugins/' . $type . '/' . $code . '/' . $code . '.php';
            if (file_exists($entry)) { $this->loadPluginEntry($entry, $code); $this->callHook($code, 'plugin_config_save', $cfg); }
            return json(['code' => 1, 'msg' => '保存成功']);
        }
        $cur = json_decode($row['config'], true) ?: [];
        foreach ($fields as $k => $f) {
            $v = isset($cur[$f['name']]) ? $cur[$f['name']] : (isset($f['default']) ? $f['default'] : '');
            // 保证 value 为标量可渲染，绝不当成代码/数组输出
            $fields[$k]['value'] = is_scalar($v) ? $v : (is_array($v) ? json_encode($v, JSON_UNESCAPED_UNICODE) : '');
        }
        return $this->fetch(APP_PATH . 'admin/view/' . $this->web['admintemplate'] . '/pluginconfig.html', ['plugin' => $row, 'fields' => $fields]);
    }

    /** 读取插件配置字段定义 */
    protected function configFields($type, $code)
    {
        $entry = $this->root . 'plugins/' . $type . '/' . $code . '/' . $code . '.php';
        $fields = [];
        if (file_exists($entry)) {
            // 确保插件入口已加载（以便拿到其定义的配置字段函数）
            if (!function_exists($code . '_plugin_config_fields') && !function_exists('plugin_config_fields')) {
                include_once $entry;
            }
            // 优先使用插件提供的配置字段函数——在 PHP-FPM 常驻进程中也不依赖 include_once 重新加载，稳定可靠
            $fn = $code . '_plugin_config_fields';
            if (function_exists($fn)) {
                $fields = (array) @call_user_func($fn);
            }
            if (!$fields) {
                // 兼容旧插件：读取顶层 $plugin_config 全局数组
                $plugin_config = [];
                include_once $entry;
                if (is_array($plugin_config)) $fields = $plugin_config;
            }
            // 防御性：确保配置字段可被模板安全渲染（标量）
            foreach ($fields as $k => $f) {
                if (!is_array($f)) $f = [];
                $fields[$k]['title']  = isset($f['title']) ? (string)$f['title'] : '';
                $fields[$k]['prompt'] = isset($f['prompt']) ? (string)$f['prompt'] : '';
                $fields[$k]['type']   = isset($f['type']) ? (string)$f['type'] : 'input';
                $fields[$k]['name']   = isset($f['name']) ? (string)$f['name'] : '';
            }
        }
        return $fields;
    }

    /** ============ API 上游对接管理（商品映射 / 连通测试 / 操作日志） ============ */
    public function apimanage()
    {
        $code = 'api';
        $row = Db::name('plugin')->where('code', $code)->find();
        if (!$row) $this->redirect(admin_url('/plugin'));
        $apiFile = PATH . 'plugins/api/' . $code . '/' . $code . '.php';
        if (!is_file($apiFile)) return json(['code' => -1, 'msg' => 'API插件入口缺失']);
        if (!function_exists('api_map_list')) { include_once $apiFile; }
        // POST 处理各动作
        if (Request::instance()->isPost()) {
            $act = trim(input('act'));
            // 连通性测试
            if ($act === 'test') {
                if (!function_exists('api_test_connection')) include_once $apiFile;
                $r = api_test_connection();
                return json(['code' => $r['code'], 'msg' => $r['msg']]);
            }
            // 拉取上游商品
            if ($act === 'fetch') {
                if (!function_exists('api_fetch_upstream_products')) include_once $apiFile;
                $r = api_fetch_upstream_products();
                return json(['code' => $r['code'], 'msg' => $r['msg'], 'list' => $r['list'] ?? []]);
            }
            // 保存商品映射
            if ($act === 'mapsave') {
                if (!function_exists('api_map_save')) include_once $apiFile;
                $r = api_map_save(
                    trim(input('up_id')), intval(input('cartid')), trim(input('cycle')),
                    trim(input('mapstatus')), trim(input('remark')), intval(input('mid'))
                );
                return json($r);
            }
            // 删除映射
            if ($act === 'mapdel') {
                if (!function_exists('api_ensure')) include_once $apiFile;
                try { Db::name('api_map')->where('id', intval(input('mid')))->delete(); return json(['code' => 1, 'msg' => '已删除']); }
                catch (\Throwable $e) { return json(['code' => -1, 'msg' => '删除失败']); }
            }
            // 手动同步全部下游订单状态
            if ($act === 'syncall') {
                if (!function_exists('api_cron_sync_status')) include_once $apiFile;
                $r = api_cron_sync_status();
                return json($r);
            }
            // 清空操作日志
            if ($act === 'logclear') {
                if (!function_exists('api_log_clear')) include_once $apiFile;
                $ok = api_log_clear();
                return json(['code' => $ok ? 1 : -1, 'msg' => $ok ? '已清空' : '清空失败']);
            }
            return json(['code' => -1, 'msg' => '未知操作']);
        }
        // GET：展示管理页
        // 商品映射列表
        $maps = [];
        try { $maps = (array) Db::name('api_map')->order('id desc')->select(); } catch (\Throwable $e) {}
        $cartNames = [];
        foreach ((array) Db::name('cart')->select() as $c) $cartNames[$c['id']] = $c['name'];
        foreach ($maps as &$m) { $m['cart_name'] = isset($cartNames[$m['cartid']]) ? $cartNames[$m['cartid']] : ('商品#' . $m['cartid']); }
        // 本地商品下拉（已映射的排除或标记）
        $localCarts = (array) Db::name('cart')->order('sort desc, id asc')->select();
        // 操作日志
        $logs = [];
        try { $logs = (array) Db::name('api_log')->order('id desc')->limit(100)->select(); }
        catch (\Throwable $e) { try { $logs = (array) Db::name('api_synclog')->order('id desc')->limit(100)->select(); } catch (\Throwable $e2) {} }
        // 插件配置（用于展示当前上游地址/key 等）
        $curCfg = json_decode($row['config'], true) ?: [];
        return $this->fetch(APP_PATH . 'admin/view/' . $this->web['admintemplate'] . '/apimanage.html', [
            'plugin' => $row, 'maps' => $maps, 'localCarts' => $localCarts, 'logs' => $logs,
            'cfg' => $curCfg,
        ]);
    }
}
