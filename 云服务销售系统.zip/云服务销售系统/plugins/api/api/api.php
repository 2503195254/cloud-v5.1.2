<?php
/**
 * 云服务销售系统 - API 对接插件（标识：api）
 * ------------------------------------------------
 * 功能：
 *  1) 对外提供 HTTP API，接收他站/客户对接：商品、价格(分组/其他折扣)、下单、订单查询、上下级绑定、余额同步。
 *  2) 拉取上级 API：可配置上级系统接口地址+key，一键同步上级商品/分组/价格/折扣到本系统商品库(yun_cart)。
 *  3) 开通 API：后台可设“开通价格”，前台用户付费开通后获得专属 API 密钥，可在用户中心查看/使用。
 *  4) 前台用户中心：我的API界面，展示/生成专属密钥、我的API订单。
 *
 * 本文件为插件入口，由插件框架自动加载：(插件管理 / 前台 /api/:plugin/:action 分发)。
 */

$plugin_info = [
    'name'    => 'API对接',
    'version' => '1.1.0',
    'desc'    => '跨系统 API 对接：对外提供商品/折扣/下单/上下级/余额接口；可拉取上级 API 商品同步到本系统；支持前台用户开通专属 API 密钥。',
];

// 后台配置字段（已统一去重，无重复命名）
$plugin_config = [
    // ---------- 对外 API（本系统对外提供接口） ----------
    ['name'=>'api_enable','title'=>'对外API开关','type'=>'switch','prompt'=>'是否开启对外 API 对接','default'=>'1'],
    ['name'=>'api_key','title'=>'对外API密钥','type'=>'input','prompt'=>'他站/客户对接本系统时携带的密钥','default'=>''],
    ['name'=>'api_sign_secret','title'=>'对外签名秘钥','type'=>'input','prompt'=>'请求签名校验秘钥，留空则仅用 key','default'=>''],
    ['name'=>'api_group_discount','title'=>'分组折扣(json)','type'=>'textarea','prompt'=>'[{"group":"vip","discount":"0.9"}]','default'=>'[{"group":"vip","discount":"0.9"}]'],
    ['name'=>'api_other_discount','title'=>'其他折扣(统一)','type'=>'input','prompt'=>'统一折扣率，1无折扣 0.9九折','default'=>'1'],
    ['name'=>'api_upper_ratio','title'=>'上级返利比例','type'=>'input','prompt'=>'API订单上级返利(0.1=10%)','default'=>'0.1'],

    // ---------- 下游对接上游 API（经销商模式）------------
    ['name'=>'upstream_enable','title'=>'上游对接总开关','type'=>'switch','prompt'=>'开启后本系统可拉取上游商品并转发开通','default'=>'0'],
    ['name'=>'upstream_url','title'=>'上游API地址','type'=>'input','prompt'=>'同系统上游的 API 基址，如 https://上游域名/api/api','default'=>''],
    ['name'=>'upstream_appid','title'=>'上游AppID','type'=>'input','prompt'=>'本系统在对方(上游)系统自助开通的 AppID','default'=>''],
    ['name'=>'upstream_appkey','title'=>'上游AppKey(密钥)','type'=>'input','prompt'=>'本系统在对方(上游)系统自助开通的 AppKey','default'=>''],
    ['name'=>'api_timeout','title'=>'请求超时(秒)','type'=>'input','prompt'=>'调用上游API的超时秒数','default'=>'8'],
    ['name'=>'order_auto','title'=>'自动开通开关','type'=>'switch','prompt'=>'开启后用户购买即自动转发上游开通；关闭则需后台手动提交','default'=>'1'],
    ['name'=>'order_retry','title'=>'接口失败重试次数','type'=>'input','prompt'=>'自动开通失败时的重试次数(0为不重试)','default'=>'2'],
    ['name'=>'order_fail_pending','title'=>'失败标记待人工','type'=>'switch','prompt'=>'重试仍失败时是否标记订单为异常待人工处理','default'=>'1'],
    ['name'=>'status_sync_enable','title'=>'产品状态同步开关','type'=>'switch','prompt'=>'开启后在计划任务/手动同步上游产品运行状态与到期时间','default'=>'1'],

    // ---------- 原有：拉取上级 API 同步商品 ----------
    ['name'=>'sync_enable','title'=>'启用拉取上级同步','type'=>'switch','prompt'=>'开启后可用下面地址拉取上级API商品','default'=>'0'],
    ['name'=>'sync_cycle','title'=>'同步商品计费周期','type'=>'input','prompt'=>'默认 month（月）','default'=>'month'],
    ['name'=>'sync_mark','title'=>'同步商品前缀/分类','type'=>'input','prompt'=>'同步过来的商品名前缀或归属分类,留空用上级原名','default'=>''],

    // ---------- 前台自助开通 API ----------
    ['name'=>'open_enable','title'=>'开启前台自助开通','type'=>'switch','prompt'=>'是否允许前台用户自助开通API','default'=>'1'],
    ['name'=>'open_price','title'=>'开通API价格(元)','type'=>'input','prompt'=>'前台付费开通API的价格,0为免费','default'=>'0'],
    ['name'=>'open_key_length','title'=>'专属密钥长度','type'=>'input','prompt'=>'生成专属API密钥的字符长度(16-64)','default'=>'32'],
    ['name'=>'open_cycle','title'=>'开通有效期(月)','type'=>'input','prompt'=>'付费开通后有效月数,0为永久','default'=>'0'],
];
/** 配置字段（供后台插件配置表单模板化渲染）。自包含返回。 */
function api_plugin_config_fields () {
    return [
    ['name'=>'api_enable','title'=>'对外API开关','type'=>'switch','prompt'=>'是否开启对外 API 对接','default'=>'1'],
    ['name'=>'api_key','title'=>'对外API密钥','type'=>'input','prompt'=>'他站/客户对接本系统时携带的密钥','default'=>''],
    ['name'=>'api_sign_secret','title'=>'对外签名秘钥','type'=>'input','prompt'=>'请求签名校验秘钥，留空则仅用 key','default'=>''],
    ['name'=>'api_group_discount','title'=>'分组折扣(json)','type'=>'textarea','prompt'=>'[{"group":"vip","discount":"0.9"}]','default'=>'[{"group":"vip","discount":"0.9"}]'],
    ['name'=>'api_other_discount','title'=>'其他折扣(统一)','type'=>'input','prompt'=>'统一折扣率，1无折扣 0.9九折','default'=>'1'],
    ['name'=>'api_upper_ratio','title'=>'上级返利比例','type'=>'input','prompt'=>'API订单上级返利(0.1=10%)','default'=>'0.1'],

    // ---------- 下游对接上游 API（经销商模式）------------
    ['name'=>'upstream_enable','title'=>'上游对接总开关','type'=>'switch','prompt'=>'开启后本系统可拉取上游商品并转发开通','default'=>'0'],
    ['name'=>'upstream_url','title'=>'上游API地址','type'=>'input','prompt'=>'同系统上游的 API 基址，如 https://上游域名/api/api','default'=>''],
    ['name'=>'upstream_appid','title'=>'上游AppID','type'=>'input','prompt'=>'本系统在对方(上游)系统自助开通的 AppID','default'=>''],
    ['name'=>'upstream_appkey','title'=>'上游AppKey(密钥)','type'=>'input','prompt'=>'本系统在对方(上游)系统自助开通的 AppKey','default'=>''],
    ['name'=>'api_timeout','title'=>'请求超时(秒)','type'=>'input','prompt'=>'调用上游API的超时秒数','default'=>'8'],
    ['name'=>'order_auto','title'=>'自动开通开关','type'=>'switch','prompt'=>'开启后用户购买即自动转发上游开通；关闭则需后台手动提交','default'=>'1'],
    ['name'=>'order_retry','title'=>'接口失败重试次数','type'=>'input','prompt'=>'自动开通失败时的重试次数(0为不重试)','default'=>'2'],
    ['name'=>'order_fail_pending','title'=>'失败标记待人工','type'=>'switch','prompt'=>'重试仍失败时是否标记订单为异常待人工处理','default'=>'1'],
    ['name'=>'status_sync_enable','title'=>'产品状态同步开关','type'=>'switch','prompt'=>'开启后在计划任务/手动同步上游产品运行状态与到期时间','default'=>'1'],

    // ---------- 原有：拉取上级 API 同步商品 ----------
    ['name'=>'sync_enable','title'=>'启用拉取上级同步','type'=>'switch','prompt'=>'开启后可用下面地址拉取上级API商品','default'=>'0'],
    ['name'=>'sync_cycle','title'=>'同步商品计费周期','type'=>'input','prompt'=>'默认 month（月）','default'=>'month'],
    ['name'=>'sync_mark','title'=>'同步商品前缀/分类','type'=>'input','prompt'=>'同步过来的商品名前缀或归属分类,留空用上级原名','default'=>''],

    // ---------- 前台自助开通 API ----------
    ['name'=>'open_enable','title'=>'开启前台自助开通','type'=>'switch','prompt'=>'是否允许前台用户自助开通API','default'=>'1'],
    ['name'=>'open_price','title'=>'开通API价格(元)','type'=>'input','prompt'=>'前台付费开通API的价格,0为免费','default'=>'0'],
    ['name'=>'open_key_length','title'=>'专属密钥长度','type'=>'input','prompt'=>'生成专属API密钥的字符长度(16-64)','default'=>'32'],
    ['name'=>'open_cycle','title'=>'开通有效期(月)','type'=>'input','prompt'=>'付费开通后有效月数,0为永久','default'=>'0'],
];
}

/**
 * 安装钩子：创建本插件数据表
 */
function api_plugin_install () {
    try {
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_app` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `uid` INT(11) NOT NULL DEFAULT '0',
            `appid` VARCHAR(64) NOT NULL DEFAULT '',
            `appname` VARCHAR(100) NOT NULL DEFAULT '',
            `appkey` VARCHAR(64) NOT NULL DEFAULT '',
            `status` TINYINT(1) NOT NULL DEFAULT '1',
            `expire` INT(11) NOT NULL DEFAULT '0',
            `remark` VARCHAR(255) NOT NULL DEFAULT '',
            `create_time` INT(11) NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`), UNIQUE KEY `appid` (`appid`), KEY `uid` (`uid`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_order` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `out_trade_no` VARCHAR(64) NOT NULL DEFAULT '',
            `order_id` INT(11) NOT NULL DEFAULT '0',
            `appid` VARCHAR(64) NOT NULL DEFAULT '',
            `cartid` INT(11) NOT NULL DEFAULT '0',
            `cycle` VARCHAR(50) NOT NULL DEFAULT '',
            `num` INT(11) NOT NULL DEFAULT '1',
            `paymoney` VARCHAR(50) NOT NULL DEFAULT '0',
            `discount` VARCHAR(20) NOT NULL DEFAULT '1',
            `upper` VARCHAR(100) NOT NULL DEFAULT '',
            `state` VARCHAR(20) NOT NULL DEFAULT '0',
            `create_time` INT(11) NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`), UNIQUE KEY `out_trade_no` (`out_trade_no`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_synclog` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `type` VARCHAR(20) NOT NULL DEFAULT 'product',
            `content` TEXT,
            `create_time` INT(11) NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_map` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `up_id` VARCHAR(64) NOT NULL DEFAULT '',
            `cartid` INT(11) NOT NULL DEFAULT '0',
            `cycle` VARCHAR(50) NOT NULL DEFAULT 'month',
            `status` TINYINT(1) NOT NULL DEFAULT '1',
            `remark` VARCHAR(255) NOT NULL DEFAULT '',
            `create_time` INT(11) NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`), KEY `up_id` (`up_id`), KEY `cartid` (`cartid`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_log` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `type` VARCHAR(40) NOT NULL DEFAULT '',
            `content` TEXT,
            `create_time` INT(11) NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`), KEY `type` (`type`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        return true;
    } catch (\Throwable $e) {
        return false;
    }
}

function api_plugin_uninstall () { return true; }
function api_plugin_config_save ($cfg) { return true; }

/* ============================================================
 * 工具函数
 * ============================================================ */

function api_config () {
    static $cfg = null;
    if ($cfg !== null) return $cfg;
    try {
        $row = \think\Db::name('plugin')->where('code', 'api')->find();
        $cfg = $row ? (json_decode($row['config'], true) ?: []) : [];
    } catch (\Throwable $e) { $cfg = []; }
    return $cfg;
}

function api_out ($code, $msg, $data = null) {
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    $r = ['code' => $code, 'msg' => $msg];
    if ($data !== null) $r['data'] = $data;
    exit(json_encode($r));
}

/* 简易 HTTP GET（用于拉取上级 API） */
function api_http_get ($url, $timeout = 15) {
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        if ($res !== false && $res !== '') return $res;
    }
    return @file_get_contents($url);
}
function api_http_post ($url, $data, $timeout = 15) {
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($data),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        if ($res !== false && $res !== '') return $res;
    }
    return @file_get_contents($url, false, stream_context_create(['http'=>['method'=>'POST','header'=>'Content-Type: application/x-www-form-urlencoded','content'=>http_build_query($data)]]));
}

/* 生成专属密钥 */
function api_gen_key ($len = 32) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    $key = '';
    $max = strlen($chars) - 1;
    for ($i = 0; $i < max(16, intval($len)); $i++) $key .= $chars[random_int(0, $max)];
    return $key;
}

/* ============================================================
 * 对外鉴权与接口
 * ============================================================ */

/**
 * 对外接口鉴权：校验「自助开通的专属凭据」(appid + appkey)。
 * 任何接入方（经销商/客户/系统）都先在用户中心自助开通一把专属钥匙，
 * 然后用 appid + appkey 调用本系统对外 API —— 彻底取代后台手动发「对外api密钥」。
 * 兼容：若后台配置了 api_key(平台级密钥)，仍可作为通用放行凭据。
 * @return array 当前资质 app 记录(含 uid/appid) 或配置
 */
function api_auth () {
    $cfg = api_config();
    if (empty($cfg['api_enable']) || $cfg['api_enable'] === '0') api_out(-1, 'API功能未开启', null);
    // 读取凭据：支持 appid+appkey（推荐，自助开通）或 key（平台级，可选兼容）
    $appid  = trim($_REQUEST['appid']  ?? ($_SERVER['HTTP_X_API_APPID']  ?? ''));
    $appkey = trim($_REQUEST['appkey'] ?? ($_SERVER['HTTP_X_API_KEY']    ?? ''))
           ?: trim($_REQUEST['key']    ?? ($_SERVER['HTTP_X_API_KEY']    ?? ''));
    if ($appkey === '') api_out(-1, '缺少密钥(appkey/key)', null);

    // 方式一：自助开通的专属凭据 appid+appkey
    if ($appid !== '') {
        $app = null;
        try { $app = \think\Db::name('api_app')->where('appid', $appid)->find(); }
        catch (\Throwable $e) {}
        if (!$app) api_out(-1, 'AppID 不存在', null);
        if ($app['status'] != 1) api_out(-1, '该凭据已被停用', null);
        if (intval($app['expire']) > 0 && intval($app['expire']) < time()) api_out(-1, '该凭据已过期', null);
        $isPlatform = false;
        // 校验密钥：appkey 一致 或 与平台 api_key 一致（平台级放行）
        if (strcmp($app['appkey'], $appkey) === 0) {
            $isPlatform = false;
        } elseif (!empty($cfg['api_key']) && strcmp($cfg['api_key'], $appkey) === 0) {
            $isPlatform = true; // 平台级密钥放行
        } else {
            api_out(-1, '密钥无效', null);
        }
        // 返回身份
        return ['appid'=>$app['appid'], 'uid'=>intval($app['uid']), 'app'=>$app, 'is_platform'=>$isPlatform, 'cfg'=>$cfg];
    }

    // 方式二：仅平台级 api_key（未提供 appid 时兼容旧调用）
    if (empty($cfg['api_key'])) api_out(-1, '未配置平台api_key；请使用用户中心「自助开通」的 AppID/密钥对接', null);
    if (strcmp($cfg['api_key'], $appkey) !== 0) api_out(-1, '密钥无效', null);
    // 平台级 key：支持 time+sign 校验（可选）
    if (!empty($cfg['api_sign_secret'])) {
        $time = trim($_REQUEST['time'] ?? '');
        $sign = trim($_REQUEST['sign'] ?? '');
        if ($time === '' || $sign === '') api_out(-1, '缺少时间戳/签名', null);
        if (abs(time() - intval($time)) > 300) api_out(-1, '时间戳超时', null);
        if (strtolower($sign) !== md5($cfg['api_key'] . $time . $cfg['api_sign_secret'])) api_out(-1, '签名错误', null);
    }
    return ['appid'=>'', 'uid'=>0, 'app'=>null, 'is_platform'=>true, 'cfg'=>$cfg];
}

function api_products () {
    $cart = \think\Db::name('cart')->where('hide', '0')->order('sort desc, id asc')->select();
    $pmap = [];
    foreach ((array)\think\Db::name('product')->select() as $p) $pmap[$p['id']] = $p['name'];
    $out = [];
    foreach ($cart as $c) $out[] = [
        'id'=>$c['id'],'name'=>$c['name'],'content'=>$c['content'],'money'=>$c['money'],
        'cycle'=>$c['cycle'],'firstmo'=>$c['firstmo'],'inventory'=>(int)$c['inventory'],
        'classification'=>isset($pmap[$c['product']])?$pmap[$c['product']]:'','serverid'=>$c['serverid'],
    ];
    return $out;
}

function api_calc_price ($cartItem, $cycle, $num, $group = '') {
    $cfg = api_config();
    $price = floatval($cartItem['money']);
    if ($price <= 0) return ['price'=>0,'discount'=>1,'paymoney'=>0];
    if ($cycle === 'unrestricted') $num = 1;
    $num = max(1, floatval($num));
    $base = $price * $num;
    $gdiscount = 1.0;
    foreach ((array)json_decode($cfg['api_group_discount'] ?? '[]', true) as $g) {
        if (isset($g['group']) && $g['group'] === $group && isset($g['discount'])) { $gdiscount = floatval($g['discount']); break; }
    }
    $od = floatval($cfg['api_other_discount'] ?? '1');
    if ($od <= 0 || $od > 1) $od = 1;
    $discount = round($gdiscount * $od, 4);
    return ['price'=>round($base,2),'discount'=>$discount,'paymoney'=>round($base*$discount,2)];
}

/* ============================================================
 * 拉取上级 API → 同步商品到本系统
 * ============================================================ */

/**
 * 拉取上级商品列表（product）并同步到本系统 yun_cart。
 * 依据名称去重：同名且 cycle 相同的视为同一商品，更新价格；否则新增。
 * @param string $byTrigger 触发来源(sync_log/手动/前台)
 * @return array [code, msg, synced, products_count]
 */
function api_sync_products ($byTrigger = 'manual') {
    api_ensure();
    $cfg = api_config();
    if (empty($cfg['sync_enable']) || $cfg['sync_enable'] === '0') return ['code'=>-1,'msg'=>'未启用拉取上级同步'];
    // 统一使用「上游API地址」(upstream_url)与上游密钥，与开通/状态同步共用同一上游入口
    $base = rtrim(trim($cfg['upstream_url'] ?? ''), '/');
    if ($base === '' || strpos($base, 'http') !== 0) return ['code'=>-1,'msg'=>'请先配置上游API地址'];
    // 复用统一上游请求（携带 key + 可选签名 + 超时）
    $respData = api_admin_request('product');
    if (!is_array($respData) || !isset($respData['code']) || $respData['code'] != 1) {
        return ['code'=>-1,'msg'=>is_array($respData)?($respData['msg']??'拉取失败'):'拉取失败'];
    }
    $products = $respData['data']['products'] ?? [];
    if (!is_array($products) || count($products) == 0) return ['code'=>-1,'msg'=>'上游无商品数据'];

    $mark = trim($cfg['sync_mark'] ?? '');
    $cycle = trim($cfg['sync_cycle'] ?? 'month');
    $synced = 0;
    $existing = (array)\think\Db::name('cart')->select();
    foreach ($products as $p) {
        $name = ($mark !== '' ? $mark . ':' : '') . trim($p['name'] ?? '');
        if ($name === '') continue;
        // 找到同名同cycle的已有商品
        $dup = null;
        foreach ($existing as $e) {
            if ($e['name'] === $name && ($e['cycle'] ?? '') === $cycle) { $dup = $e; break; }
        }
        $money = isset($p['money']) ? $p['money'] : '0';
        $content = $p['content'] ?? $p['name'] ?? '';
        $inventory = isset($p['inventory']) && $p['inventory'] > 0 ? $p['inventory'] : 100;
        $firstmo = (isset($p['firstmo']) && $p['firstmo'] == '1') ? '1' : '0';
        $serverid = $p['serverid'] ?? '1';
        $pid = $p['id'] ?? 0;
        // 归到“极速API同步”产品类(若无则复用 product=默认)
        $productId = api_ensure_classification();
        if ($dup) {
            \think\Db::name('cart')->where('id', $dup['id'])->update([
                'money'=>$money,'content'=>$content,'inventory'=>$inventory,
                'cycle'=>$cycle,'firstmo'=>$firstmo,'serverid'=>$serverid,'hide'=>'0',
                'upgrade'=>$dup['upgrade']??'0',
            ]);
        } else {
            \think\Db::name('cart')->insert([
                'product'=>$productId,'name'=>$name,'content'=>$content,'money'=>$money,
                'cycle'=>$cycle,'firstmo'=>$firstmo,'serverid'=>$serverid,'upgrade'=>'0',
                'buy'=>'1','hide'=>'0','sort'=>time()%1000,'inventory'=>$inventory,
            ]);
            $existing[] = ['name'=>$name,'cycle'=>$cycle,'id'=>0];
        }
        $synced++;
    }
    try {
        \think\Db::name('api_synclog')->insert(['type'=>'product','content'=>"同步$synced个商品(来自上级)", 'create_time'=>time()]);
    } catch (\Throwable $e) {}
    return ['code'=>1,'msg'=>"同步完成，共 $synced 个商品",'synced'=>$synced,'products_count'=>count($products)];
}

/* 确保存在“同步商品”归属的产品分类，返回其 id */
function api_ensure_classification () {
    try {
        $row = \think\Db::name('product')->where('name', 'API同步商品')->find();
        if ($row) return $row['id'];
        $id = \think\Db::name('product')->insertGetId(['name'=>'API同步商品','content'=>'由API插件自动同步','sort'=>0]);
        return $id;
    } catch (\Throwable $e) { return 1; }
}

/* ============================================================
 * 前台开通 / 专属密钥
 * ============================================================ */

/** 当前用户是否已开通API，返回其 appid 记录(或null) */
function api_user_app ($uid) {
    try { return \think\Db::name('api_app')->where('uid', $uid)->order('id asc')->find(); }
    catch (\Throwable $e) { return null; }
}

/** 开通API(为某用户创建专属密钥) */
function api_open_for_user ($uid, $paid = 0) {
    api_ensure();
    $cfg = api_config();
    if (empty($cfg['open_enable']) || $cfg['open_enable'] === '0') return ['code'=>-1,'msg'=>'前台开通未开启'];
    $app = api_user_app($uid);
    $len = intval($cfg['open_key_length'] ?? 32);
    $expire = (intval($cfg['open_cycle'] ?? 0) > 0) ? time() + intval($cfg['open_cycle'])*86400*30 : 0;
    if ($app) {
        // 已开通：续期
        if ($expire) { $app['expire'] = ($app['expire'] > time()) ? $app['expire'] + intval($cfg['open_cycle'])*86400*30 : $expire; }
        $key = api_gen_key($len);
        \think\Db::name('api_app')->where('id', $app['id'])->update(['appkey'=>$key,'expire'=>$app['expire']]);
        return ['code'=>1,'msg'=>'已更新专属密钥','data'=>['appid'=>$app['appid'],'appkey'=>$key,'expire'=>$app['expire']]];
    }
    $appid = 'UA' . $uid . time() . rand(100,999);
    $key = api_gen_key($len);
    \think\Db::name('api_app')->insert([
        'uid'=>$uid,'appid'=>$appid,'appname'=>'用户API-'.$uid,'appkey'=>$key,
        'status'=>1,'expire'=>$expire,'remark'=>'','create_time'=>time(),
    ]);
    return ['code'=>1,'msg'=>'开通成功','data'=>['appid'=>$appid,'appkey'=>$key,'expire'=>$expire]];
}

/** 前台用户中心：我的API 数据 */
function api_my_panel ($uid) {
    api_ensure();
    $cfg = api_config();
    $app = api_user_app($uid);
    $enabled = !empty($cfg['open_enable']) && $cfg['open_enable'] === '1';
    $price  = floatval($cfg['open_price'] ?? 0);
    $expired = 0;
    if ($app && $app['expire'] > 0 && $app['expire'] < time()) $expired = 1;
    // 我的API订单
    $orders = [];
    if ($app) {
        try { $orders = (array)\think\Db::name('api_order')->where('appid', $app['appid'])->order('id desc')->limit(20)->select(); }
        catch (\Throwable $e) {}
    }
    return [
        'enabled'=>$enabled,'price'=>$price,'open_cycle'=>intval($cfg['open_cycle']??0),
        'app'=>$app ? ['appid'=>$app['appid'],'appkey'=>$app['appkey'],'status'=>$app['status'],'expire'=>$app['expire'],'expired'=>$expired] : null,
        'orders'=>$orders,'time'=>time(),
    ];
}

/* ============================================================
 * 对外业务 action
 * ============================================================ */

function api_action_product () { api_out(1, 'success', ['products'=>api_products()]); }

function api_action_price () {
    $id = intval($_REQUEST['id'] ?? 0);
    $cycle = trim($_REQUEST['cycle'] ?? 'month');
    $num = floatval($_REQUEST['num'] ?? 1);
    $group = trim($_REQUEST['group'] ?? '');
    $item = \think\Db::name('cart')->where('id', $id)->find();
    if (!$item) api_out(-1, '商品不存在');
    $r = api_calc_price($item, $cycle, $num, $group);
    api_out(1, 'success', ['cart'=>['id'=>$item['id'],'name'=>$item['name'],'cycle'=>$cycle,'inventory'=>(int)$item['inventory']],'price'=>$r['price'],'discount'=>$r['discount'],'paymoney'=>$r['paymoney']]);
}

function api_action_order () {
    api_auth();
    $id = intval($_POST['id'] ?? 0);
    $cycle = trim($_POST['cycle'] ?? 'month');
    $num = floatval($_POST['num'] ?? 1);
    $group = trim($_POST['group'] ?? '');
    $upper = trim($_POST['aff_upper'] ?? '');
    $out_trade_no = trim($_POST['out_trade_no'] ?? ('API'.time().rand(100,999)));
    $item = \think\Db::name('cart')->where('id', $id)->find();
    if (!$item) api_out(-1, '商品不存在');
    if ((int)$item['inventory'] < 1) api_out(-1, '商品库存不足');
    if ($upper !== '') {
        $u = \think\Db::name('user')->where('user',$upper)->find();
        if (!$u) $u = \think\Db::name('user')->where('id',$upper)->find();
        if (!$u) api_out(-1, '上级不存在');
    }
    $r = api_calc_price($item, $cycle, $num, $group);
    $appid = $_GET['appid'] ?? ($_SERVER['HTTP_X_API_APPID'] ?? '');
    try {
        \think\Db::name('api_order')->insert([
            'out_trade_no'=>$out_trade_no,'appid'=>$appid,'cartid'=>$item['id'],'cycle'=>$cycle,
            'num'=>(int)$num,'paymoney'=>$r['paymoney'],'discount'=>$r['discount'],'upper'=>$upper,'state'=>'0','create_time'=>time(),
        ]);
    } catch (\Throwable $e) { api_out(-1, '订单写入失败'); }
    api_out(1, '下单成功', ['out_trade_no'=>$out_trade_no,'paymoney'=>$r['paymoney'],'product'=>$item['name'],'cycle'=>$cycle,'num'=>(int)$num]);
}

function api_action_query () {
    $out_trade_no = trim($_REQUEST['out_trade_no'] ?? '');
    if ($out_trade_no === '') api_out(-1, '缺少订单号');
    $row = \think\Db::name('api_order')->where('out_trade_no', $out_trade_no)->find();
    if (!$row) api_out(-1, '订单不存在');
    api_out(1, 'success', ['out_trade_no'=>$row['out_trade_no'],'paymoney'=>$row['paymoney'],'discount'=>$row['discount'],'state'=>$row['state'],'order_id'=>$row['order_id'],'product'=>$row['cartid']]);
}

function api_action_balance () {
    api_auth();
    $account = trim($_REQUEST['account'] ?? '');
    if ($account === '') api_out(-1, '缺少 account');
    $u = \think\Db::name('user')->where('user',$account)->find();
    if (!$u) $u = \think\Db::name('user')->where('id',$account)->find();
    if (!$u) api_out(-1, '用户不存在');
    api_out(1, 'success', ['account'=>$u['user'],'balance'=>$u['money']]);
}

function api_action_upper () {
    $account = trim($_REQUEST['account'] ?? '');
    if ($account === '') api_out(-1, '缺少 account');
    $u = \think\Db::name('user')->where('user',$account)->find();
    if (!$u) $u = \think\Db::name('user')->where('id',$account)->find();
    if (!$u) api_out(-1, '上级不存在');
    api_out(1, 'success', ['account'=>$u['user'],'name'=>$u['name'],'id'=>$u['id']]);
}

/** 前台开通服务端响应：uid 通过参数传入(由User控制器调用) */
function api_action_open () {
    $cfg = api_config();
    if (empty($cfg['open_enable']) || $cfg['open_enable'] === '0') api_out(-1, '前台开通未开启');
    // 这里由前台 User 控制器二次调用 api_open_for_user，并处理支付。此处可读 uid。
    $uid = intval($_REQUEST['uid'] ?? 0);
    if ($uid <= 0) api_out(-1, '缺少用户');
    // 若开通价格>0 且未支付，则提示先下单，由前台处理支付；此处仅返回需支付金额
    $price = floatval($cfg['open_price'] ?? 0);
    if ($price > 0) {
        api_out(1, 'need_pay', ['price'=>$price,'msg'=>'请先支付开通费用']);
    }
    $r = api_open_for_user($uid, 1);
    api_out($r['code'], $r['msg'], $r['data'] ?? null);
}

/** 确保数据表存在 */
function api_ensure () {
    try {
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_order` (`id` INT(11) NOT NULL AUTO_INCREMENT,`out_trade_no` VARCHAR(64) NOT NULL DEFAULT '',`order_id` INT(11) NOT NULL DEFAULT '0',`appid` VARCHAR(64) NOT NULL DEFAULT '',`cartid` INT(11) NOT NULL DEFAULT '0',`cycle` VARCHAR(50) NOT NULL DEFAULT '',`num` INT(11) NOT NULL DEFAULT '1',`paymoney` VARCHAR(50) NOT NULL DEFAULT '0',`discount` VARCHAR(20) NOT NULL DEFAULT '1',`upper` VARCHAR(100) NOT NULL DEFAULT '',`state` VARCHAR(20) NOT NULL DEFAULT '0',`create_time` INT(11) NOT NULL DEFAULT '0',PRIMARY KEY (`id`),UNIQUE KEY `out_trade_no` (`out_trade_no`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_app` (`id` INT(11) NOT NULL AUTO_INCREMENT,`uid` INT(11) NOT NULL DEFAULT '0',`appid` VARCHAR(64) NOT NULL DEFAULT '',`appname` VARCHAR(100) NOT NULL DEFAULT '',`appkey` VARCHAR(64) NOT NULL DEFAULT '',`status` TINYINT(1) NOT NULL DEFAULT '1',`expire` INT(11) NOT NULL DEFAULT '0',`remark` VARCHAR(255) NOT NULL DEFAULT '',`create_time` INT(11) NOT NULL DEFAULT '0',PRIMARY KEY (`id`),UNIQUE KEY `appid` (`appid`),KEY `uid` (`uid`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_synclog` (`id` INT(11) NOT NULL AUTO_INCREMENT,`type` VARCHAR(20) NOT NULL DEFAULT 'product',`content` TEXT,`create_time` INT(11) NOT NULL DEFAULT '0',PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_map` (`id` INT(11) NOT NULL AUTO_INCREMENT,`up_id` VARCHAR(64) NOT NULL DEFAULT '',`cartid` INT(11) NOT NULL DEFAULT '0',`cycle` VARCHAR(50) NOT NULL DEFAULT 'month',`status` TINYINT(1) NOT NULL DEFAULT '1',`remark` VARCHAR(255) NOT NULL DEFAULT '',`create_time` INT(11) NOT NULL DEFAULT '0',PRIMARY KEY (`id`),KEY `up_id` (`up_id`),KEY `cartid` (`cartid`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_log` (`id` INT(11) NOT NULL AUTO_INCREMENT,`type` VARCHAR(40) NOT NULL DEFAULT '',`content` TEXT,`create_time` INT(11) NOT NULL DEFAULT '0',PRIMARY KEY (`id`),KEY `type` (`type`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
    } catch (\Throwable $e) {}
}

/**
 * 统一分发入口（供前台 Api 控制器调用）：/api/api/{action}
 */
function api_dispatch ($action) {
    api_ensure();
    switch ($action) {
        case 'product': return api_action_product();
        case 'price':   return api_action_price();
        case 'order':   return api_action_order();
        case 'query':   return api_action_query();
        case 'balance': return api_action_balance();
        case 'upper':   return api_action_upper();
        case 'open':    return api_action_open();
        case 'test':    return api_action_test();
        case 'create':  return api_action_create();
        case 'status':  return api_action_status();
        case 'suspend':    return api_action_suspend();
        case 'unsuspend':  return api_action_unsuspend();
        case 'terminate':  return api_action_terminate();
        case 'renew':      return api_action_renew();
        case 'upgrade':    return api_action_upgrade();
        case 'sync':    // 手动触发同步(带key)
            api_auth(); $r = api_sync_products('manual'); api_out($r['code'], $r['msg'], ['synced'=>$r['synced']??0]);
        default: api_out(-1, '未知的接口 action');
    }
}

/* ============================================================
 * 下游对接上游 API —— 后台管理功能模块（独立函数名，避免与host插件冲突）
 * ============================================================ */

/* 读取上游对接配置 */
function api_admin_cfg()
{
    $cfg = api_config();
    return $cfg;
}

/* 调用上游API（与 host/api/api.php 协议一致） */
function api_admin_request($action, $params = [], $timeout = 0)
{
    $cfg = api_admin_cfg();
    if (empty($cfg['upstream_enable']) || $cfg['upstream_enable'] === '0') {
        return ['code'=>-1, 'msg'=>'上游对接总开关未开启'];
    }
    $base = rtrim(trim($cfg['upstream_url'] ?? ''), '/');
    if ($base === '' || strpos($base, 'http') !== 0) {
        return ['code'=>-1, 'msg'=>'请先配置上游API地址'];
    }
    $key    = trim($cfg['upstream_appid'] ?? '');
    $secret = trim($cfg['upstream_appkey'] ?? '');
    if ($key === '') {
        return ['code'=>-1, 'msg'=>'未填写“上游AppID”：请先在对方(上游)系统用户中心自助开通专属API并填写其 AppID'];
    }
    if ($secret === '') {
        return ['code'=>-1, 'msg'=>'未填写“上游AppKey”：请填写在对方系统自助开通的 AppKey'];
    }
    $to     = $timeout > 0 ? $timeout : max(10, intval($cfg['api_timeout'] ?? 15));
    // 组装凭据：appid + appkey（对应对方系统「自助开通」的专属钥匙）
    $auth = ['appid'=>$key, 'appkey'=>$secret];
    $params = array_merge($params, $auth);
    $query = ($action !== '' ? '/' . $action : '') . '?' . http_build_query($auth);
    $url   = $base . $query;
    $resp = '';
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($params),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => $to,
            CURLOPT_TIMEOUT => $to,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => ['X-Api-Appid: ' . $key, 'X-Api-Key: ' . $secret, 'Content-Type: application/x-www-form-urlencoded'],
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
    }
    if ($resp === false || $resp === '') {
        $resp = @file_get_contents($url, false, stream_context_create([
            'http' => ['method'=>'POST','header'=>"X-Api-Appid: $key\r\nX-Api-Key: $secret\r\nContent-Type: application/x-www-form-urlencoded",'content'=>http_build_query($params),'timeout'=>$to]
        ]));
    }
    $json = json_decode($resp, true);
    if (!is_array($json)) {
        return ['code'=>-1, 'msg'=>'上游响应解析失败', 'raw'=>mb_substr((string)$resp,0,500)];
    }
    return $json;
}

/* 连通性测试 */
function api_test_connection()
{
    $cfg = api_admin_cfg();
    $msg = [];
    if (empty($cfg['upstream_enable']) || $cfg['upstream_enable'] === '0') $msg[] = '上游对接总开关未开启';
    if (trim($cfg['upstream_url'] ?? '') === '') $msg[] = '未填上游API地址';
    if (trim($cfg['upstream_appid'] ?? '') === '') $msg[] = '未填上游AppID';
    if (trim($cfg['upstream_appkey'] ?? '') === '') $msg[] = '未填上游AppKey';
    if ($msg) return ['code'=>-1, 'msg'=>implode('；', $msg)];
    $ret = api_admin_request('test');
    if (!isset($ret['code']) || $ret['code'] != 1) {
        return ['code'=>-1, 'msg'=>'连接失败：'.($ret['msg'] ?? '上游无响应')];
    }
    return ['code'=>1, 'msg'=>'连接成功，上游响应正常'];
}

/* 拉取上游商品列表（供映射管理展示） */
function api_fetch_upstream_products()
{
    $ret = api_admin_request('product');
    if (!isset($ret['code']) || $ret['code'] != 1) {
        return ['code'=>-1, 'msg'=>($ret['msg'] ?? '拉取失败'), 'list'=>[]];
    }
    $list = $ret['data']['products'] ?? [];
    if (!is_array($list)) $list = [];
    return ['code'=>1, 'msg'=>'拉取成功', 'list'=>$list];
}

/* 商品映射列表 */
function api_map_list()
{
    api_ensure();
    $rows = [];
    try { $rows = (array)\think\Db::name('api_map')->order('id desc')->select(); }
    catch (\Throwable $e) {}
    // 附带本地商品名称
    $cartNames = [];
    foreach ((array)\think\Db::name('cart')->select() as $c) $cartNames[$c['id']] = $c['name'];
    foreach ($rows as &$r) {
        $r['cart_name'] = isset($cartNames[$r['cartid']]) ? $cartNames[$r['cartid']] : ('商品#'.$r['cartid']);
    }
    return $rows;
}

/* 保存商品映射（新增或更新） */
function api_map_save($up_id, $cartid, $cycle, $status, $remark = '', $id = 0)
{
    api_ensure();
    $up_id = trim($up_id);
    $cartid = intval($cartid);
    if ($up_id === '' || $cartid <= 0) return ['code'=>-1, 'msg'=>'上游商品ID与本地商品不能为空'];
    $cycle = in_array($cycle, ['day','month','season','year','unrestricted']) ? $cycle : 'month';
    $data = [
        'up_id'=>$up_id, 'cartid'=>$cartid, 'cycle'=>$cycle,
        'status'=>($status=='0'?'0':'1'), 'remark'=>mb_substr(trim($remark),0,200),
    ];
    try {
        if ($id > 0) {
            \think\Db::name('api_map')->where('id', $id)->update($data);
        } else {
            $data['create_time'] = time();
            \think\Db::name('api_map')->insert($data);
        }
        // 确保存在“API上游”服务器记录，并把本地商品关联到该服务器（关键：让系统开通走 api 服务器插件）
        $srv = null;
        try { $srv = \think\Db::name('server')->where('serverplugins','api')->find(); }
        catch (\Throwable $e) {}
        if (!$srv) {
            try {
                $srvId = \think\Db::name('server')->insertGetId([
                    'name'=>'API上游对接','host'=>'','ip'=>'','security'=>'','port'=>'80','ssl'=>'0',
                    'user'=>'','password'=>'','serverplugins'=>'api','data1'=>'api',
                ]);
                $srv = ['id'=>$srvId];
            } catch (\Throwable $e) {}
        }
        if ($srv && isset($srv['id'])) {
            try {
                $cartRow = \think\Db::name('cart')->where('id', $cartid)->find();
                if ($cartRow && (empty($cartRow['serverid']) || $cartRow['serverid']=='0')) {
                    \think\Db::name('cart')->where('id', $cartid)->update(['serverid'=>$srv['id']]);
                }
            } catch (\Throwable $e) {}
        }
        api_write_log_or_synclog('map', '保存商品映射：上游='.$up_id.' 本地='.$cartid);
        return ['code'=>1, 'msg'=>'保存成功'];
    } catch (\Throwable $e) {
        return ['code'=>-1, 'msg'=>'保存失败：'.$e->getMessage()];
    }
}

/* 记录操作日志（兼容器插件/便于归档） */
function api_write_log_or_synclog($type, $content)
{
    try { \think\Db::name('api_log')->insert(['type'=>$type, 'content'=>mb_substr((string)$content,0,1500), 'create_time'=>time()]); }
    catch (\Throwable $e) {
        try { \think\Db::name('api_synclog')->insert(['type'=>$type, 'content'=>mb_substr((string)$content,0,1500), 'create_time'=>time()]); }
        catch (\Throwable $e2) {}
    }
}

/* 操作日志列表 */
function api_log_list($type = '', $limit = 50)
{
    api_ensure();
    try {
        $q = \think\Db::name('api_log');
        if ($type !== '') $q = $q->where('type', $type);
        return $q->order('id desc')->limit(intval($limit))->select();
    } catch (\Throwable $e) {
        try { return \think\Db::name('api_synclog')->order('id desc')->limit(intval($limit))->select(); }
        catch (\Throwable $e2) { return []; }
    }
}

/* 清空操作日志 */
function api_log_clear()
{
    api_ensure();
    try { \think\Db::name('api_log')->where('1=1')->delete(); return true; }
    catch (\Throwable $e) { return false; }
}

/* 转发开通单个本地订单到上游（后台手动/自动重试） */
function api_forward_create($orderId)
{
    api_ensure();
    $order = \think\Db::name('order')->where('id', intval($orderId))->find();
    if (!$order) return ['code'=>-1, 'msg'=>'订单不存在'];
    $cart = \think\Db::name('cart')->where('id', $order['cartid'])->find();
    if (!$cart) return ['code'=>-1, 'msg'=>'商品不存在'];
    $map = null;
    try { $map = \think\Db::name('api_map')->where('cartid', $cart['id'])->where('status','1')->find(); }
    catch (\Throwable $e) {}
    if (!$map) return ['code'=>-1, 'msg'=>'该商品未配置上游API商品映射'];
    $cycle = trim($map['cycle'] ?? ($cart['cycle'] ?? 'month'));
    $params = [
        'up_id'=>$map['up_id'], 'cycle'=>$cycle, 'num'=>1,
        'user'=>trim($order['user'] ?? ''), 'password'=>trim($order['password'] ?? ''),
        'cartid'=>intval($cart['id']),
    ];
    // 按重试次数尝试
    $retry = max(0, intval(api_admin_cfg()['order_retry'] ?? 2));
    $ret = null; $lastMsg = '';
    for ($i = 0; $i <= $retry; $i++) {
        $ret = api_admin_request('create', $params);
        if (isset($ret['code']) && $ret['code'] == 1) { $lastMsg = ''; break; }
        $lastMsg = $ret['msg'] ?? '上游无响应';
    }
    if (!isset($ret['code']) || $ret['code'] != 1) {
        // 标记失败待人工
        \think\Db::name('order')->where('id', $order['id'])->update(['data1'=>'ERR', 'data8'=>mb_substr($lastMsg,0,200)]);
        api_write_log_or_synclog('create', '转发开通失败(重试'.$retry.'次)：#'.$order['id'].' '.$lastMsg);
        return ['code'=>-1, 'msg'=>'开通失败：'.$lastMsg];
    }
    $d = $ret['data'] ?? [];
    \think\Db::name('order')->where('id', $order['id'])->update([
        'user'=>($d['username'] ?? $order['user']),
        'password'=>($d['password'] ?? $order['password']),
        'state'=>'1',
        'data1'=>$d['up_order_id'] ?? '', 'data2'=>$map['up_id'], 'data3'=>($d['expire_time'] ?? $order['ztime']),
        'data4'=>'1', 'data5'=>$d['panel_url'] ?? '', 'data6'=>$d['username'] ?? $order['user'],
        'data7'=>$d['password'] ?? $order['password'], 'data8'=>($d['remark'] ?? ''),
    ]);
    api_write_log_or_synclog('create', '转发开通成功：#'.$order['id'].' 上游订单='.($d['up_order_id'] ?? ''));
    return ['code'=>1, 'msg'=>'开通成功', 'up_order_id'=>($d['up_order_id'] ?? '')];
}

/* 同步单个订单的上游状态（回写本地） */
function api_sync_upstream_status($orderId)
{
    api_ensure();
    $order = \think\Db::name('order')->where('id', intval($orderId))->find();
    if (!$order) return ['code'=>-1, 'msg'=>'订单不存在'];
    $upOrderId = trim($order['data1'] ?? '');
    if ($upOrderId === '' || $upOrderId === 'PENDING' || $upOrderId === 'ERR') {
        return ['code'=>-1, 'msg'=>'该订单尚无上游订单ID'];
    }
    $ret = api_admin_request('status', ['up_order_id'=>$upOrderId]);
    if (!isset($ret['code']) || $ret['code'] != 1) {
        api_write_log_or_synclog('status', '同步状态失败：#'.$order['id'].' '.($ret['msg'] ?? '未知错误'));
        return ['code'=>-1, 'msg'=>($ret['msg'] ?? '同步失败')];
    }
    $d = $ret['data'] ?? [];
    $upState = isset($d['state']) ? (string)$d['state'] : '';
    $upExpire = isset($d['expire_time']) ? intval($d['expire_time']) : 0;
    $localState = '1';
    if ($upState === '2') $localState = '2';
    elseif ($upState === '3' || $upState === '0') $localState = '3';
    $upd = ['state'=>$localState, 'data4'=>$upState, 'data3'=>$upExpire ? $upExpire : $order['data3']];
    if (!empty($d['panel_url'])) $upd['data5'] = $d['panel_url'];
    if (!empty($d['username']))  $upd['data6'] = $d['username'];
    if (!empty($d['password']))  $upd['data7'] = $d['password'];
    if (!empty($d['remark']))    $upd['data8'] = $d['remark'];
    if ($upExpire) $upd['ztime'] = $upExpire;
    \think\Db::name('order')->where('id', $order['id'])->update($upd);
    api_write_log_or_synclog('status', '同步状态成功：#'.$order['id'].' 上游状态='.$upState);
    return ['code'=>1, 'msg'=>'同步成功', 'state'=>$upState, 'expire_time'=>$upExpire];
}

/* 计划任务批量同步所有已开通的上游订单状态 */
function api_cron_sync_status()
{
    api_ensure();
    $cfg = api_admin_cfg();
    if (empty($cfg['status_sync_enable']) || $cfg['status_sync_enable'] === '0') {
        return ['code'=>-1, 'msg'=>'产品状态同步开关未开启'];
    }
    // 查找所有已获得上游订单ID且未被终止的订单
    $orders = [];
    try {
        $orders = \think\Db::name('order')->where('data1','neq','')->where('data1','neq','PENDING')->where('data1','neq','ERR')->select();
    } catch (\Throwable $e) {}
    $ok = 0; $fail = 0;
    foreach ($orders as $o) {
        $r = api_sync_upstream_status($o['id']);
        if (isset($r['code']) && $r['code'] == 1) $ok++; else $fail++;
    }
    api_write_log_or_synclog('cron', "计划任务状态同步完成：成功 $ok 条，失败 $fail 条");
    return ['code'=>1, 'msg'=>"状态同步完成：成功 $ok，失败 $fail，共 ".count($orders).' 条'];
}

/* ============================================================
 * 上游接口（本系统作为上游，供下游同系统调用）
 * 下游 -> 上游：/api/api/test | product | create | status
 * ============================================================ */

/* 连通性测试（宽松探活：不必带key也能确认网络通；若带key则校验） */
function api_action_test () {
    // 若请求携带了 key，则做完整校验；否则仅探活返回 pong
    $hasKey = trim($_REQUEST['key'] ?? '') !== '' || !empty($_SERVER['HTTP_X_API_KEY']);
    if ($hasKey) {
        api_auth();
    }
    api_out(1, 'pong', ['time'=>time(), 'system'=>'云服务销售系统']);
}

/* 上游侧：接收下游开通请求，真正创建实例（实时从经销商余额扣款 + 产品归属经销商） */
function api_action_create () {
    $auth  = api_auth();
    $cfg   = $auth['cfg'] ?? [];
    $up_id   = trim($_POST['up_id'] ?? '');
    $cycle   = trim($_POST['cycle'] ?? 'month');
    $num     = max(1, intval($_POST['num'] ?? 1));
    $user    = trim($_POST['user'] ?? '');
    $password= trim($_POST['password'] ?? '');
    $cartid  = intval($_POST['cartid'] ?? 0);
    if ($up_id === '') api_out(-1, '缺少上游商品ID(up_id)');
    // up_id 即为上游系统的本地 cartid（映射时记录的是上游商品在本库的cartid）
    $cart = \think\Db::name('cart')->where('id', intval($up_id))->find();
    if (!$cart) api_out(-1, '商品不存在');
    if ((int)$cart['inventory'] < 1) api_out(-1, '商品库存不足');

    // 实时扣款：先计算应付金额
    $pr = api_calc_price($cart, $cycle, $num, '');
    $pay = floatval($pr['paymoney'] ?? 0);
    if ($pay < 0) $pay = 0;

    // 经销商身份（product归属与扣款账户）：app.uid 即调用方在上游的用户账号
    $uid = intval($auth['uid'] ?? 0);
    if ($uid <= 0) api_out(-1, '未识别对接方账户，无法扣款开通');
    $dealer = \think\Db::name('user')->where('id', $uid)->find();
    if (!$dealer) api_out(-1, '对接方账户不存在');

    $server = \think\Db::name('server')->where('id', $cart['serverid'])->find();
    // 计算购买时长
    $times = 2592000; // 默认月
    if ($cycle === 'day') $times = 86400 * $num;
    elseif ($cycle === 'month') $times = 2592000 * $num;
    elseif ($cycle === 'season') $times = 7879680 * $num;
    elseif ($cycle === 'year') $times = 31536000 * $num;
    elseif ($cycle === 'unrestricted') $times = 315360000 * $num;

    // 余额校验与扣款（实时扣款模式）
    $balance = floatval($dealer['money'] ?? 0);
    if ($pay > 0 && $balance < $pay) {
        api_out(-1, '对接方账户余额不足，开通失败（需 '.$pay.' 元，当前余额 '.$balance.' 元，请先充值）');
    }
    // ======= 通用开通：与具体插件解耦 =======
    // 先按订单商品绑定关系尝试调用其所对应的 host 插件开通（任意插件都行）
    $data2 = ['user'=>$user, 'password'=>$password, 'time'=>$num];
    $result = ['code'=>-1, 'msg'=>'服务器未配置', 'id'=>0];
    $pluginUsed = '';
    if ($server && $server['serverplugins']) {
        $pluginUsed = $server['serverplugins'];
        $entryFile = PATH . 'plugins/host/' . $server['serverplugins'] . '/' . $server['serverplugins'] . '.php';
        if (is_file($entryFile)) {
            include_once $entryFile;
            $fn = $server['serverplugins'] . '_CreateAccount';
            if (function_exists($fn)) {
                $result = @$fn($server, $data2, $cart, $times);
            }
        }
    } else {
        // 无插件：直接建单（通用兜底）
        try {
            $oid = \think\Db::name('order')->insertGetId([
                'user'=>$user, 'password'=>$password, 'userid'=>$uid,
                'cartid'=>$cart['id'], 'atime'=>time(), 'ztime'=>time()+$times, 'state'=>'1',
            ]);
            $result = ['code'=>1, 'msg'=>'创建成功', 'id'=>$oid];
        } catch (\Throwable $e) {}
    }
    if (!isset($result['code']) || $result['code'] != 1) {
        api_out(-1, '开通失败：'.($result['msg'] ?? '未知错误'));
    }
    // ======= 授权类商品：通用补充授权码 =======
    $licenseCode = '';
    if (isset($cart['islicense']) && $cart['islicense'] == '1') {
        $licEntry = PATH . 'plugins/license/license/license.php';
        if (is_file($licEntry)) {
            include_once $licEntry;
            if (function_exists('license_add')) {
                $uname = $dealer['user'] ? $dealer['user'] : ($dealer['name'] ? $dealer['name'] : ('user'.$uid));
                $lr = license_add([
                    'product' => $cart['name'],
                    'userid' => $uid,
                    'uname' => $uname,
                    'domain_limit' => 1,
                    'status' => 1,
                    'remark' => 'API对接开通',
                    'level_id' => intval($cart['lic_level_id'] ?? 0),
                    'duration' => $num,
                    'type' => ($cycle === 'unrestricted') ? 'permanent' : 'normal',
                ]);
                if ($lr['code'] == 1) {
                    $licenseCode = $lr['license_code'] ?? '';
                    // 把授权码写进订单 data11，并尝试关联 order_id
                    try {
                        \think\Db::name('license')->where('code', $licenseCode)->update(['order_id' => intval($result['id'])]);
                    } catch (\Throwable $e) {}
                }
            }
        }
    }
    // 真正扣款（开通成功后才扣）
    if ($pay > 0) {
        try {
            \think\Db::name('user')->where('id', $uid)->setDec('money', $pay);
        } catch (\Throwable $e) {}
    }
    // 找到上游创建的订单 id 并归到经销商账户下
    $upOrderId = isset($result['id']) ? $result['id'] : 0;
    if ($upOrderId) {
        try {
            \think\Db::name('order')->where('id', $upOrderId)->update([
                'userid'=>$uid, 'data9'=>(string)$pay, 'data10'=>time(),
                'data11'=>$licenseCode,
            ]);
        } catch (\Throwable $e) {}
        $orderRow = \think\Db::name('order')->where('id', $upOrderId)->find();
    } else {
        // 最终兜底建单
        try {
            $oid = \think\Db::name('order')->insertGetId([
                'user'=>$user, 'password'=>$password, 'userid'=>$uid,
                'cartid'=>$cart['id'], 'atime'=>time(), 'ztime'=>time()+$times, 'state'=>'1',
                'data9'=>(string)$pay, 'data10'=>time(), 'data11'=>$licenseCode,
            ]);
            $upOrderId = $oid;
            $orderRow = \think\Db::name('order')->where('id', $oid)->find();
        } catch (\Throwable $e) {}
    }
    // 通用完整信息快照（与插件无关，全量返回）
    $info = api_order_info($orderRow, $cart, $server, $pay);
    $info['license_code'] = $licenseCode;
    $info['plugin'] = $pluginUsed;
    api_out(1, '开通成功', $info);
}

/**
 * 通用构建「产品信息快照」：把上游订单的全部可见字段 + 面板一起返回。
 * 与具体插件解耦——无论上游任何插件开通，只要结果写进了订单，都能完整透传。
 */
function api_order_info ($orderRow, $cart, $server, $pay) {
    $info = [
        'up_order_id' => (string)($orderRow['id'] ?? '0'),
        'username' => $orderRow['user'] ?? '',
        'password' => $orderRow['password'] ?? '',
        'expire_time' => intval($orderRow['ztime'] ?? 0),
        'created_at' => intval($orderRow['atime'] ?? 0),
        'state' => (string)($orderRow['state'] ?? '1'),
        'product_name' => $cart['name'] ?? '',
        'cycle' => $cart['cycle'] ?? '',
        'deduct' => $pay > 0 ? (string)$pay : (string)($orderRow['data9'] ?? '0'),
        'panel_url' => (isset($server['host']) && $server['host']) ? ('http' . (isset($server['ssl'])&&$server['ssl']=='1'?'s':'') . '://' . $server['host'] . (isset($server['port'])?':'.$server['port']:'') . '/') : '',
    ];
    // 通用扩展字段透传：order 的 data1~data20 全部带上，避免漏掉任何插件写入的信息
    for ($i = 1; $i <= 20; $i++) {
        $info['data'.$i] = isset($orderRow['data'.$i]) ? (string)$orderRow['data'.$i] : '';
    }
    // 授权产品：补充授权码（如存在）
    $licCode = trim($orderRow['data11'] ?? '');
    if ($licCode === '' && isset($cart['islicense']) && $cart['islicense'] == '1') {
        try {
            $lic = \think\Db::name('license')->where('order_id', intval($orderRow['id']))->find();
            if ($lic) $licCode = $lic['code'];
        } catch (\Throwable $e) {}
    }
    $info['license_code'] = $licCode;
    return $info;
}

/* 上游侧：查询实例状态（按 up_order_id = 上游order.id） */
function api_action_status () {
    $auth = api_auth();
    $upOrderId = trim($_REQUEST['up_order_id'] ?? '');
    if ($upOrderId === '') api_out(-1, '缺少 up_order_id');
    $order = \think\Db::name('order')->where('id', intval($upOrderId))->find();
    if (!$order) api_out(-1, '实例不存在');
    // 归属校验：若确认调用方身份(uid)，防止越权查看他人实例
    $uid = intval($auth['uid'] ?? 0);
    if ($uid > 0 && !empty($order['userid']) && intval($order['userid']) > 0 && intval($order['userid']) !== $uid) {
        api_out(-1, '无权查看该实例');
    }
    // 上游状态：1正常 2暂停 3终止
    $state = '1';
    if ($order['state'] == '2') $state = '2';
    elseif ($order['state'] == '3') $state = '3';
    $cart = \think\Db::name('cart')->where('id', $order['cartid'])->find();
    $server = \think\Db::name('server')->where('id', ($cart['serverid'] ?? 0))->find();
    // 通用完整信息快照（与插件无关，含 data1~data20 与授权码）
    $info = api_order_info($order, $cart, $server, 0);
    $info['state'] = $state;
    api_out(1, 'success', $info);
}

/* ============================================================
 * 上游侧：产品生命周期管理（供下游转发）
 * 下游->上游：suspend | unsuspend | terminate | renew | upgrade
 * 每个操作都校验归属 + 调用上游订单商品绑定的 host 插件执行
 * ============================================================ */

/* 按订单加载其商品绑定的上游 host 插件，返回可调用的函数前缀 */
function api_load_order_plugin ($order, $authUid) {
    if (!$order) api_out(-1, '实例不存在');
    // 归属校验：防止越权操作他人实例
    $uid = intval($authUid ?? 0);
    if ($uid > 0 && !empty($order['userid']) && intval($order['userid']) > 0 && intval($order['userid']) !== $uid) {
        api_out(-1, '无权操作该实例');
    }
    $cart = \think\Db::name('cart')->where('id', intval($order['cartid']))->find();
    $server = \think\Db::name('server')->where('id', ($cart['serverid'] ?? 0))->find();
    $prefix = ($server && $server['serverplugins']) ? $server['serverplugins'] : '';
    if ($prefix !== '') {
        $file = PATH . 'plugins/host/' . $prefix . '/' . $prefix . '.php';
        if (is_file($file)) { include_once $file; }
    }
    return ['cart'=>$cart, 'server'=>$server, 'prefix'=>$prefix];
}

/* 暂停 */
function api_action_suspend () {
    $auth = api_auth();
    $up_order_id = intval($_REQUEST['up_order_id'] ?? 0);
    if ($up_order_id <= 0) api_out(-1, '缺少 up_order_id');
    $order = \think\Db::name('order')->where('id', $up_order_id)->find();
    $p = api_load_order_plugin($order, $auth['uid'] ?? 0);
    $fn = $p['prefix'] . '_SuspendAccount';
    if ($p['prefix'] !== '' && function_exists($fn)) {
        @$fn($p['server'], $order, $p['cart']);
    }
    \think\Db::name('order')->where('id', $up_order_id)->update(['state'=>'2','data4'=>'2']);
    api_out(1, '暂停成功', ['up_order_id'=>(string)$up_order_id, 'state'=>'2']);
}

/* 解除暂停 */
function api_action_unsuspend () {
    $auth = api_auth();
    $up_order_id = intval($_REQUEST['up_order_id'] ?? 0);
    if ($up_order_id <= 0) api_out(-1, '缺少 up_order_id');
    $order = \think\Db::name('order')->where('id', $up_order_id)->find();
    $p = api_load_order_plugin($order, $auth['uid'] ?? 0);
    $fn = $p['prefix'] . '_UnsuspendAccount';
    if ($p['prefix'] !== '' && function_exists($fn)) {
        @$fn($p['server'], $order, $p['cart']);
    }
    \think\Db::name('order')->where('id', $up_order_id)->update(['state'=>'1','data4'=>'1']);
    api_out(1, '解除暂停成功', ['up_order_id'=>(string)$up_order_id, 'state'=>'1']);
}

/* 终止 */
function api_action_terminate () {
    $auth = api_auth();
    $up_order_id = intval($_REQUEST['up_order_id'] ?? 0);
    if ($up_order_id <= 0) api_out(-1, '缺少 up_order_id');
    $order = \think\Db::name('order')->where('id', $up_order_id)->find();
    $p = api_load_order_plugin($order, $auth['uid'] ?? 0);
    $fn = $p['prefix'] . '_TerminateAccount';
    if ($p['prefix'] !== '' && function_exists($fn)) {
        @$fn($p['server'], $order, $p['cart']);
    }
    \think\Db::name('order')->where('id', $up_order_id)->update(['state'=>'3','data4'=>'3']);
    api_out(1, '终止成功', ['up_order_id'=>(string)$up_order_id, 'state'=>'3']);
}

/* 续费：实时从经销商余额扣费并延长上游订单 */
function api_action_renew () {
    $auth = api_auth();
    $cfg = $auth['cfg'] ?? [];
    $up_order_id = intval($_REQUEST['up_order_id'] ?? 0);
    $num = max(1, intval($_REQUEST['num'] ?? 1));
    if ($up_order_id <= 0) api_out(-1, '缺少 up_order_id');
    $order = \think\Db::name('order')->where('id', $up_order_id)->find();
    if (!$order) api_out(-1, '实例不存在');
    $uid = intval($auth['uid'] ?? 0);
    if ($uid <= 0) api_out(-1, '未识别对接方账户，无法续费');
    $dealer = \think\Db::name('user')->where('id', $uid)->find();
    if (!$dealer) api_out(-1, '对接方账户不存在');
    // 计算续费金额
    $cart = \think\Db::name('cart')->where('id', intval($order['cartid']))->find();
    $cycle = trim($order['data2'] ?? ($cart['cycle'] ?? 'month'));
    $cycle = ($cycle === '') ? 'month' : $cycle;
    $pr = api_calc_price($cart, $cycle, $num, '');
    $pay = floatval($pr['paymoney'] ?? 0);
    // 余额校验
    $balance = floatval($dealer['money'] ?? 0);
    if ($pay > 0 && $balance < $pay) {
        api_out(-1, '对接方账户余额不足，续费失败（需 '.$pay.' 元，当前余额 '.$balance.' 元，请先充值）');
    }
    // 调上游订单商品绑定的 host 插件续费
    $p = api_load_order_plugin($order, $uid);
    $fn = $p['prefix'] . '_renew';
    if ($p['prefix'] !== '' && function_exists($fn)) {
        @$fn($p['server'], $order, $p['cart'], $num);
    } elseif ($p['prefix'] !== '' && function_exists($p['prefix'].'_RenewAccount')) {
        @call_user_func($p['prefix'].'_RenewAccount', $p['server'], $order, $p['cart']);
    }
    // 扣款 + 延长到期时间
    if ($pay > 0) {
        try { \think\Db::name('user')->where('id', $uid)->setDec('money', $pay); } catch (\Throwable $e) {}
    }
    $times = 2592000 * $num;
    $newZ = time() + $times;
    \think\Db::name('order')->where('id', $up_order_id)->update(['ztime'=>$newZ, 'data3'=>$newZ]);
    if ($order['data9'] !== '') {
        $old = floatval($order['data9']);
        \think\Db::name('order')->where('id', $up_order_id)->update(['data9'=>($old + $pay)]);
    }
    api_out(1, '续费成功', ['up_order_id'=>(string)$up_order_id, 'expire_time'=>$newZ, 'deduct'=>$pay]);
}

/* 升级：实时计算补差扣款并迁移上游订单到新商品 */
function api_action_upgrade () {
    $auth = api_auth();
    $up_order_id = intval($_REQUEST['up_order_id'] ?? 0);
    $new_up_id   = intval($_REQUEST['up_id'] ?? 0);
    if ($up_order_id <= 0) api_out(-1, '缺少 up_order_id');
    if ($new_up_id <= 0) api_out(-1, '缺少新商品 up_id');
    $order = \think\Db::name('order')->where('id', $up_order_id)->find();
    if (!$order) api_out(-1, '实例不存在');
    $uid = intval($auth['uid'] ?? 0);
    if ($uid <= 0) api_out(-1, '未识别对接方账户，无法升级');
    $dealer = \think\Db::name('user')->where('id', $uid)->find();
    if (!$dealer) api_out(-1, '对接方账户不存在');
    $newCart = \think\Db::name('cart')->where('id', $new_up_id)->find();
    if (!$newCart) api_out(-1, '新商品不存在');
    // 补差：新商品周期价 - 旧商品周期价
    $cycle = trim($_REQUEST['cycle'] ?? 'month');
    $pOld = api_calc_price(\think\Db::name('cart')->where('id', intval($order['cartid']))->find(), $cycle, 1, '');
    $pNew = api_calc_price($newCart, $cycle, 1, '');
    $diff = floatval($pNew['paymoney'] ?? 0) - floatval($pOld['paymoney'] ?? 0);
    if ($diff < 0) $diff = 0;
    $balance = floatval($dealer['money'] ?? 0);
    if ($diff > 0 && $balance < $diff) {
        api_out(-1, '对接方账户余额不足，升级失败（需补 '.$diff.' 元，当前余额 '.$balance.' 元）');
    }
    $p = api_load_order_plugin($order, $uid);
    $fn = $p['prefix'] . '_upgrade';
    if ($p['prefix'] !== '' && function_exists($fn)) {
        @$fn($p['server'], $order, $p['cart'], $newCart);
    } elseif ($p['prefix'] !== '' && function_exists($p['prefix'].'_UpgradeAccount')) {
        @call_user_func($p['prefix'].'_UpgradeAccount', $p['server'], $order, $p['cart'], $newCart);
    }
    if ($diff > 0) {
        try { \think\Db::name('user')->where('id', $uid)->setDec('money', $diff); } catch (\Throwable $e) {}
    }
    \think\Db::name('order')->where('id', $up_order_id)->update(['cartid'=>$new_up_id, 'data2'=>$new_up_id]);
    api_out(1, '升级成功', ['up_order_id'=>(string)$up_order_id, 'new_cartid'=>$new_up_id, 'deduct'=>$diff]);
}
