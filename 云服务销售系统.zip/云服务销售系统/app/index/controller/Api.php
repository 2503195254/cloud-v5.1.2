<?php
namespace app\index\controller;
use think\Controller;
use think\Request;

/**
 * 前台插件 API 统一入口
 * 路由示例：/api/vhss_api/product   -> 调用 plugins/api/vhss_api/vhss_api.php 的 vhss_api_dispatch('product')
 *          /api/vhss_api/price
 *          /api/vhss_api/order
 * 请求方需携带 key(API密钥)，可选用 sign 签名。
 */
class Api extends Controller
{
    public function index($plugin = '', $action = '')
    {
        $plugin = trim($plugin);
        $action = trim($action);
        if ($plugin === '' || $action === '') {
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['code' => -1, 'msg' => '缺少插件或接口参数']));
        }
        // 安全校验：仅允许 [a-zA-Z0-9_-]
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $plugin) || !preg_match('/^[a-zA-Z0-9_-]+$/', $action)) {
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['code' => -1, 'msg' => '参数格式非法']));
        }
        $dir = PATH . 'plugins/api/' . $plugin;
        $entry = $dir . '/' . $plugin . '.php';
        if (!file_exists($entry)) {
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['code' => -1, 'msg' => '插件不存在或未安装']));
        }
        // 加载插件并检查是否已启用
        $installed = false; $enabled = false;
        try { $pl = \think\Db::name('plugin')->where('code', $plugin)->find(); if ($pl) { $installed = true; $enabled = intval($pl['status']) === 1; } } catch (\Throwable $e) {}
        include_once $entry;
        $dispatch = $plugin . '_dispatch';
        if (!function_exists($dispatch)) {
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['code' => -1, 'msg' => '插件接口未实现']));
        }
        // 未安装时也允许访问（插件内部会校验是否开启）
        call_user_func($dispatch, $action);
        header('Content-Type: application/json; charset=utf-8');
        exit(json_encode(['code' => -1, 'msg' => '接口无返回']));
    }
}