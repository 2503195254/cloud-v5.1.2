<?php
/**
 * 云服务销售系统 - 授权插件（标识：license）
 * -----------------------------------------------
 * 功能：
 *  1) 后台授权管理：添加/编辑/删除授权，生成授权码，设时限(日/月/年/一次性/永久)、绑定域名数量。
 *  2) 授权下可添加附件，用户中心可下载。
 *  3) 授权端验证接口：/license_api/verify 校验授权码+域名，返回状态/到期/产品等。
 *  4) 用户端验证文件：client_auth.php（独立文件），嵌入被授权系统向授权端验证。
 *  5) 前台授权查询页：任何人凭授权码/域名免登录查询。
 *  6) 系统级验证：进入后台检测，未授权可通过“去授权”→ 输授权码 → 自动绑定当前域名。
 *  7) 完全独立：本插件缺失时，系统其余功能照常运行。
 */

$plugin_info = [
    'name'    => '授权系统',
    'version' => '1.0.0',
    'desc'    => '销售/管理授权码，支持产品授权、绑定域名、附件交付、授权端+用户端验证、前台查询；可销售任何物品的授权。',
];

// 后台配置字段
$plugin_config = [
    ['name'=>'lic_enable','title'=>'授权端功能开关','type'=>'switch','prompt'=>'开启后本系统可销售/管理授权并提供验证接口','default'=>'1'],
    ['name'=>'lic_verify_secret','title'=>'验证签名秘钥','type'=>'input','prompt'=>'用户端请求验证时用于签名的秘钥，双方保持一致','default'=>''],
    ['name'=>'lic_max_domains','title'=>'默认绑定域名数','type'=>'input','prompt'=>'新授权允许绑定的域名数量上限','default'=>'1'],
    ['name'=>'lic_default_reset','title'=>'默认免费重置次数','type'=>'input','prompt'=>'后台新增授权时默认免费重置绑定次数上限(可单个覆盖)','default'=>'2'],
    ['name'=>'lic_auto_bind','title'=>'允许自动绑定域名','type'=>'switch','prompt'=>'后台“去授权”输入授权码时自动绑定当前域名','default'=>'1'],
    ['name'=>'lic_query_open','title'=>'开启前台免登录查询','type'=>'switch','prompt'=>'允许任何人凭授权码查询授权状态','default'=>'1'],
    ['name'=>'lic_reset_price','title'=>'重置绑定单价(元)','type'=>'input','prompt'=>'用户中心免费重置次数用完后，付费重置一次的单价','default'=>'5'],
    ['name'=>'lic_upgrade_price','title'=>'提升域名上限单价(元/个)','type'=>'input','prompt'=>'用户中心付费每提升1个绑定域名上限的单价','default'=>'10'],

    // ---------- 本系统自身授权验证（进入后台/前台自动检测） ----------
    ['name'=>'local_enable','title'=>'启用本系统授权验证','type'=>'switch','prompt'=>'默认开启：访问系统即自动检测授权，未授权则前后台提示','default'=>'1'],
    ['name'=>'local_server','title'=>'本系统授权端地址','type'=>'input','prompt'=>'用户端验证对接的授权端地址，默认 https://idc.pantd.com/license_api','default'=>'https://idc.pantd.com/license_api'],
    ['name'=>'local_code','title'=>'本系统授权码','type'=>'input','prompt'=>'本系统的授权码(由授权端发放)，留空则视为未授权，可通过后台“去授权”输入授权码自动绑定','default'=>''],
    ['name'=>'local_secret','title'=>'本系统签名秘钥','type'=>'input','prompt'=>'与授权端一致的签名秘钥(可留空)','default'=>''],
    // ---------- 授权端定期自检（按周期向授权端重新验证，避免每次访问都连授权端） ----------
    ['name'=>'selfcheck_server','title'=>'自检授权端地址(可在源码改)','type'=>'input','prompt'=>'用于定期自检的授权端地址，默认与“本系统授权端地址”一致，留空则使用本系统授权端地址','default'=>''],
    ['name'=>'selfcheck_month','title'=>'自检周期(月)','type'=>'select','prompt'=>'每隔几个月向授权端自动重新验证一次：1/3/6/12 选择一项，留空/0 则每次访问都实时验证','default'=>'','option'=>['0'=>'实时验证(默认)','1'=>'1个月','3'=>'3个月','6'=>'6个月','12'=>'12个月']],
    ['name'=>'selfcheck_last','title'=>'上次自检时间(自动记录)','type'=>'input','prompt'=>'系统自动记录上次成功自检的时间，到期后再次访问将重新验证','default'=>'0'],
];
// 把配置字段注册到全局，供 configFields 在任意 include 作用域及常驻进程下都能稳定读取
$GLOBALS['license_plugin_config'] = $plugin_config;

/* ============================================================
 * 数据表
 * ============================================================ */

function license_ensure () {
    try {
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_license` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `code` VARCHAR(64) NOT NULL DEFAULT '',
            `product` VARCHAR(200) NOT NULL DEFAULT '',
            `userid` INT(11) NOT NULL DEFAULT '0',
            `uname` VARCHAR(100) NOT NULL DEFAULT '',
            `type` VARCHAR(20) NOT NULL DEFAULT 'permanent',
            `domain_limit` INT(11) NOT NULL DEFAULT '1',
            `domains` TEXT,
            `status` TINYINT(1) NOT NULL DEFAULT '1',
            `create_time` INT(11) NOT NULL DEFAULT '0',
            `expire_time` INT(11) NOT NULL DEFAULT '0',
            `remark` VARCHAR(500) NOT NULL DEFAULT '',
            `reset_limit` INT(11) NOT NULL DEFAULT '0',
            `reset_used` INT(11) NOT NULL DEFAULT '0',
            `level_id` INT(11) NOT NULL DEFAULT '0',
            `level_name` VARCHAR(100) NOT NULL DEFAULT '',
            PRIMARY KEY (`id`), UNIQUE KEY `code` (`code`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        // ---------- 老库兼容：确保字段存在（先查信息架构，存在才跳过，避免每次请求都报错/加列） ----------
        $cols = [];
        try {
            $rows = \think\Db::query("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'yun_license'");
            foreach ($rows as $r) { $c = (string)($r['COLUMN_NAME'] ?? $r['column_name'] ?? ''); if ($c !== '') $cols[strtolower($c)] = 1; }
        } catch (\Throwable $e) { $cols = []; }
        $need = [
            'reset_limit' => "ALTER TABLE `yun_license` ADD `reset_limit` INT(11) NOT NULL DEFAULT '0'",
            'reset_used'  => "ALTER TABLE `yun_license` ADD `reset_used` INT(11) NOT NULL DEFAULT '0'",
            'level_id'    => "ALTER TABLE `yun_license` ADD `level_id` INT(11) NOT NULL DEFAULT '0'",
            'level_name'  => "ALTER TABLE `yun_license` ADD `level_name` VARCHAR(100) NOT NULL DEFAULT ''",
        ];
        foreach ($need as $col => $sql) {
            if (!isset($cols[strtolower($col)])) { try { \think\Db::execute($sql); } catch (\Throwable $e) {} }
        }
        // 授权等级表
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_license_level` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(100) NOT NULL DEFAULT '',
            `sort` INT(11) NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        \think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_license_attach` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `license_id` INT(11) NOT NULL DEFAULT '0',
            `filename` VARCHAR(300) NOT NULL DEFAULT '',
            `filepath` VARCHAR(500) NOT NULL DEFAULT '',
            `filesize` VARCHAR(50) NOT NULL DEFAULT '0',
            `create_time` INT(11) NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`), KEY `license_id` (`license_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
    } catch (\Throwable $e) {}
}

function license_plugin_install () { license_ensure(); return true; }
function license_plugin_uninstall () { return true; }
function license_plugin_config_save ($cfg) { return true; }
/* 返回插件配置字段定义（避免依赖 include_once 全局变量在常驻进程中被缓存/覆盖） */
function license_plugin_config_fields () {
    // 从全局读取（插件 include 时已注册），在常驻进程/任意 include 作用域下都稳定
    if (isset($GLOBALS['license_plugin_config']) && is_array($GLOBALS['license_plugin_config'])) {
        return $GLOBALS['license_plugin_config'];
    }
    global $plugin_config;
    return is_array($plugin_config) ? $plugin_config : [];
}

/* ============================================================
 * 工具函数
 * ============================================================ */

function license_config () {
    static $cfg = null;
    if ($cfg !== null) return $cfg;
    try {
        $row = \think\Db::name('plugin')->where('code', 'license')->find();
        $cfg = $row ? (json_decode($row['config'], true) ?: []) : [];
    } catch (\Throwable $e) { $cfg = []; }
    return $cfg;
}

function license_out ($code, $msg, $data = null) {
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    $r = ['code' => $code, 'msg' => $msg];
    if ($data !== null) $r['data'] = $data;
    exit(json_encode($r));
}

/** 生成唯一授权码（可读性强，不含易混淆字符） */
function license_gen_code ($len = 16) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $code = '';
    $max = strlen($chars) - 1;
    for ($i = 0; $i < $len; $i++) $code .= $chars[random_int(0, $max)];
    // 加时间错避免重复
    return $code;
}

/** 解析域名列表(去空白、去重复、转小写) */
function license_domains ($str) {
    if (is_array($str)) $arr = $str;
    else $arr = array_map('trim', explode(',', (string)$str));
    $out = [];
    foreach ($arr as $d) {
        $d = strtolower(trim($d));
        if ($d !== '' && !in_array($d, $out)) $out[] = $d;
    }
    return $out;
}

/**
 * 验证授权核心逻辑（授权端内部使用）
 * @param string $code    授权码
 * @param string $domain  当前域名(可选)
 * @return array [code, msg, data]
 *   code=1 有效; =0 无效/过期/域名不匹配; =-1 参数错误
 */
function license_verify ($code, $domain = '') {
    license_ensure();
    $code = strtoupper(trim($code));
    if ($code === '') return ['code' => -1, 'msg' => '缺少授权码', 'data' => null];
    $row = null;
    try { $row = \think\Db::name('license')->where('code', $code)->find(); }
    catch (\Throwable $e) {}
    if (!$row) return ['code' => 0, 'msg' => '授权码不存在', 'data' => null];

    // 状态
    if ($row['status'] != 1) return ['code' => 0, 'msg' => '授权已被停用', 'data' => null];

    // 时限
    $type = $row['type'];
    $now = time();
    $expired = false;
    if ($type === 'once') {
        // 一次性：视为即时生效，仅允许 use 一次（由业务方控制），此处不设过期
    } elseif ($type === 'permanent') {
        // 永久
    } else {
        // daily/monthly/yearly 依据 expire_time
        if ($row['expire_time'] > 0 && $now > $row['expire_time']) $expired = true;
    }

    // 域名校验
    $domainOk = true;
    $curDomain = strtolower(trim($domain));
    if ($curDomain !== '') {
        $domains = license_domains($row['domains']);
        if (!empty($domains)) {
            if (!in_array($curDomain, $domains)) $domainOk = false;
        }
    }

    if ($expired) return ['code' => 0, 'msg' => '授权已过期', 'data' => null];
    if (!$domainOk) return ['code' => 0, 'msg' => '授权未绑定该域名', 'data' => null];

    $data = [
        'code' => $row['code'],
        'product' => $row['product'],
        'type' => $type,
        'status' => 1,
        'expire_time' => $row['expire_time'],
        'domains' => license_domains($row['domains']),
        'uname' => $row['uname'],
        'level_name' => $row['level_name'] ?? '',
    ];
    return ['code' => 1, 'msg' => '授权有效', 'data' => $data];
}

/** 计算过期时间戳：based on type + duration */
function license_expire ($type, $num = 1) {
    $n = max(1, intval($num));
    switch ($type) {
        case 'day': return time() + $n * 86400;
        case 'month': return time() + $n * 86400 * 30;
        case 'year': return time() + $n * 86400 * 365;
        case 'once': return 0; // 一次性，无到期
        case 'permanent': return 0; // 永久
        default: return 0;
    }
}

/* ============================================================
 * 授权端对外验证接口：/license_api/{action}
 * ============================================================ */

function license_dispatch ($action) {
    license_ensure();
    switch ($action) {
        case 'verify': return license_api_verify();
        case 'bind':   return license_api_bind();
        case 'query':  return license_api_query();
        default: license_out(-1, '未知接口');
    }
}

/** 验证接口：?code=授权码&domain=域名[&sign=] */
function license_api_verify () {
    $cfg = license_config();
    if (empty($cfg['lic_enable']) || $cfg['lic_enable'] === '0') license_out(-1, '授权端未开启');
    $code = trim($_REQUEST['code'] ?? '');
    $domain = trim($_REQUEST['domain'] ?? '');
    if ($code === '') license_out(-1, '缺少授权码');
    // 可选签名校验
    $secret = $cfg['lic_verify_secret'] ?? '';
    if ($secret !== '') {
        $sign = trim($_REQUEST['sign'] ?? '');
        $ok = ('s' . $code . $domain . $secret) === $sign;
        // 简化签名：md5(code+domain+secret)
        if (strtolower($sign) !== md5($code . $domain . $secret)) license_out(-1, '签名错误');
    }
    $r = license_verify($code, $domain);
    if ($r['code'] === 1) license_out(1, $r['msg'], $r['data']);
    else license_out(0, $r['msg'], null);
}

/** 绑定域名接口：?code=授权码&domain=域名（把域名加入授权，需在限额内） */
function license_api_bind () {
    $cfg = license_config();
    if (empty($cfg['lic_enable']) || $cfg['lic_enable'] === '0') license_out(-1, '授权端未开启');
    $code = strtoupper(trim($_REQUEST['code'] ?? ''));
    $domain = strtolower(trim($_REQUEST['domain'] ?? ''));
    if ($code === '' || $domain === '') license_out(-1, '参数不全');
    $row = null;
    try { $row = \think\Db::name('license')->where('code', $code)->find(); }
    catch (\Throwable $e) {}
    if (!$row) license_out(0, '授权码不存在');
    if ($row['status'] != 1) license_out(0, '授权已停用');
    $domains = license_domains($row['domains']);
    if (!in_array($domain, $domains)) {
        $limit = intval($row['domain_limit'] > 0 ? $row['domain_limit'] : ($cfg['lic_max_domains'] ?? 1));
        if ($limit > 0 && count($domains) >= $limit) license_out(0, '已达绑定域名上限(' . $limit . '个)');
        $domains[] = $domain;
        try { \think\Db::name('license')->where('id', $row['id'])->update(['domains' => implode(',', $domains)]); }
        catch (\Throwable $e) { license_out(-1, '绑定失败'); }
    }
    license_out(1, '绑定成功', ['code' => $code, 'domain' => $domain, 'domains' => $domains]);
}

/** 前台免登录查询接口：?code=授权码 或 ?domain=域名 */
function license_api_query () {
    $cfg = license_config();
    if (empty($cfg['lic_query_open']) || $cfg['lic_query_open'] === '0') license_out(-1, '查询未开启');
    $code = strtoupper(trim($_REQUEST['code'] ?? ''));
    $domain = strtolower(trim($_REQUEST['domain'] ?? ''));
    if ($code === '' && $domain === '') license_out(0, '请输入授权码或域名查询');
    $list = [];
    try {
        $query = \think\Db::name('license');
        if ($code !== '') $query = $query->where('code', $code);
        if ($domain !== '') {
            $rows = $query->select();
            foreach ($rows as $r) {
                if (in_array($domain, license_domains($r['domains']))) $list[] = $r;
            }
        } else {
            $list = $query->select();
        }
    } catch (\Throwable $e) {}
    $out = [];
    foreach ($list as $r) {
        $v = license_verify($r['code'], $domain);
        $out[] = [
            'code' => $r['code'], 'product' => $r['product'], 'uname' => $r['uname'],
            'type' => $r['type'], 'status' => $r['status'],
            'expire_time' => $r['expire_time'],
            'domains' => license_domains($r['domains']),
            'valid' => ($v['code'] === 1) ? 1 : 0,
            'state_msg' => $v['code'] === 1 ? '有效' : $v['msg'],
            'level_name' => $r['level_name'] ?? '',
            'edition' => !empty($r['level_name']) ? $r['level_name'] : ($r['product'] ?? ''),
        ];
    }
    license_out(1, 'success', ['count' => count($out), 'list' => $out]);
}

/* ============================================================
 * “去授权”绑定：后台输入授权码自动绑定当前域名
 * ============================================================ */

/** 后台“去授权”函数：输入授权码，自动绑定本系统当前访问域名，返回授权状态 */
function license_activate ($code, $domain) {
    license_ensure();
    $cfg = license_config();
    if (empty($cfg['lic_enable']) || $cfg['lic_enable'] === '0') return ['code' => -1, 'msg' => '授权端未开启'];
    $code = strtoupper(trim($code));
    $domain = strtolower(trim($domain));
    if ($code === '' || $domain === '') return ['code' => -1, 'msg' => '参数不全'];
    $row = null;
    try { $row = \think\Db::name('license')->where('code', $code)->find(); }
    catch (\Throwable $e) {}
    if (!$row) return ['code' => 0, 'msg' => '授权码不存在'];
    if ($row['status'] != 1) return ['code' => 0, 'msg' => '授权已停用'];
    // 自动绑定域名（若开启且未超限）
    $bindable = !empty($cfg['lic_auto_bind']) && $cfg['lic_auto_bind'] === '1';
    $domains = license_domains($row['domains']);
    if ($bindable && !in_array($domain, $domains)) {
        $limit = intval($row['domain_limit'] > 0 ? $row['domain_limit'] : ($cfg['lic_max_domains'] ?? 1));
        if ($limit > 0 && count($domains) >= $limit) return ['code' => 0, 'msg' => '授权已达绑定域名上限(' . $limit . '个)'];
        $domains[] = $domain;
        try { \think\Db::name('license')->where('id', $row['id'])->update(['domains' => implode(',', $domains)]); }
        catch (\Throwable $e) {}
    }
    $r = license_verify($code, $domain);
    return ['code' => $r['code'], 'msg' => $r['msg'], 'data' => $r['data']];
}

/* ============================================================
 * 后台授权管理辅助（供后台控制器调用）
 * ============================================================ */

/** 添加上一条授权并写库 */
function license_add ($opts) {
    license_ensure();
    $cfg = license_config();
    $code = strtoupper(trim($opts['code'] ?? ''));
    if ($code === '') { do { $code = license_gen_code(); } while (license_code_exists($code)); }
    $type = $opts['type'] ?? 'permanent';
    $dur = intval($opts['duration'] ?? 1);
    if ($dur < 1) $dur = 1;
    $expire = license_expire($type, $dur);
    $limit = intval($opts['domain_limit'] ?? 0);
    if ($limit < 1) $limit = intval($cfg['lic_max_domains'] ?? 1);
    if ($limit < 1) $limit = 1;
    $domains = license_domains($opts['domains'] ?? '');
    $defaultReset = intval($cfg['lic_default_reset'] ?? 2);
    $resetLimit = isset($opts['reset_limit']) ? intval($opts['reset_limit']) : $defaultReset;
    // 授权等级
    $levelId = isset($opts['level_id']) ? intval($opts['level_id']) : 0;
    $levelName = trim($opts['level_name'] ?? '');
    if ($levelId > 0 && $levelName === '') {
        $lrow = null;
        try { $lrow = \think\Db::name('license_level')->where('id', $levelId)->find(); } catch (\Throwable $e) {}
        if ($lrow) $levelName = $lrow['name'];
    }
    try {
        $id = \think\Db::name('license')->insertGetId([
            'code' => $code, 'product' => $opts['product'] ?? '',
            'userid' => intval($opts['userid'] ?? 0), 'uname' => $opts['uname'] ?? '',
            'type' => $type, 'domain_limit' => $limit,
            'domains' => implode(',', $domains), 'status' => intval($opts['status'] ?? 1),
            'create_time' => time(), 'expire_time' => $expire, 'remark' => $opts['remark'] ?? '',
            'reset_limit' => $resetLimit, 'reset_used' => intval($opts['reset_used'] ?? 0),
            'level_id' => $levelId, 'level_name' => $levelName,
        ]);
        return ['code' => 1, 'id' => $id, 'license_code' => $code, 'msg' => '添加成功'];
    } catch (\Throwable $e) {
        return ['code' => -1, 'msg' => '添加失败：' . $e->getMessage()];
    }
}

/* ============================================================
 * 授权等级（普惠版/专业版…）
 * ============================================================ */

/** 等级列表 */
function license_level_list () {
    license_ensure();
    try { return \think\Db::name('license_level')->order('sort asc, id asc')->select(); }
    catch (\Throwable $e) { return []; }
}

/** 新增等级 */
function license_level_add ($name, $sort = 0) {
    license_ensure();
    $name = trim($name);
    if ($name === '') return ['code' => 0, 'msg' => '等级名称不能为空'];
    try {
        \think\Db::name('license_level')->insert(['name' => $name, 'sort' => intval($sort)]);
        return ['code' => 1, 'msg' => '新增成功'];
    } catch (\Throwable $e) { return ['code' => 0, 'msg' => '新增失败']; }
}

/** 重命名等级 */
function license_level_rename ($id, $name) {
    license_ensure();
    $name = trim($name);
    if ($name === '') return ['code' => 0, 'msg' => '等级名称不能为空'];
    try {
        \think\Db::name('license_level')->where('id', intval($id))->update(['name' => $name]);
        // 同步已绑定该等级的授权
        \think\Db::name('license')->where('level_id', intval($id))->update(['level_name' => $name]);
        return ['code' => 1, 'msg' => '已保存'];
    } catch (\Throwable $e) { return ['code' => 0, 'msg' => '保存失败']; }
}

/** 删除等级 */
function license_level_del ($id) {
    license_ensure();
    try {
        \think\Db::name('license')->where('level_id', intval($id))->update(['level_id' => 0, 'level_name' => '']);
        \think\Db::name('license_level')->where('id', intval($id))->delete();
        return ['code' => 1, 'msg' => '已删除'];
    } catch (\Throwable $e) { return ['code' => 0, 'msg' => '删除失败']; }
}

/** 解析等级（将授权记录附加 level 信息，供接口/列表返回） */
function license_attach_level ($item) {
    if (is_array($item) && (empty($item['level_name']))) {
        $item['level_name'] = '';
    }
    return $item;
}

function license_code_exists ($code) {
    try { return \think\Db::name('license')->where('code', $code)->find() ? true : false; }
    catch (\Throwable $e) { return false; }
}

/** 附加文件（附件表） */
function license_attach_add ($license_id, $filename, $filepath, $filesize = 0) {
    try {
        \think\Db::name('license_attach')->insert([
            'license_id' => intval($license_id), 'filename' => $filename,
            'filepath' => $filepath, 'filesize' => $filesize, 'create_time' => time(),
        ]);
        return true;
    } catch (\Throwable $e) { return false; }
}

/** 取某授权的附件列表 */
function license_attach_list ($license_id) {
    try { return \think\Db::name('license_attach')->where('license_id', $license_id)->order('id desc')->select(); }
    catch (\Throwable $e) { return []; }
}

/** 取某用户所有授权（用于用户中心） */
function license_by_user ($uid) {
    try {
        $rows = \think\Db::name('license')->where('userid', $uid)->order('id desc')->select();
        foreach ($rows as &$r) {
            $r['attach'] = license_attach_list($r['id']);
            $r['domains_arr'] = license_domains($r['domains']);
            $r['expired'] = (in_array($r['type'], ['day','month','year']) && $r['expire_time']>0 && time()>$r['expire_time']) ? 1 : 0;
            $r['reset_left'] = max(0, intval($r['reset_limit'] ?? 0) - intval($r['reset_used'] ?? 0));
        }
        return $rows;
    } catch (\Throwable $e) { return []; }
}

/* ============================================================
 * 授权自助管理：重置绑定 / 付费提升域名上限（前台用户中心）
 * ============================================================ */

/** 获取用户中心自助管理的费用配置（后台授权插件配置可调整） */
function license_self_cfg () {
    $cfg = license_config();
    return [
        // 重置绑定次数用完后，付费重置一次的单价（元）
        'reset_price' => floatval($cfg['lic_reset_price'] ?? 5),
        // 提升1个域名上限的单价（元）
        'upgrade_price' => floatval($cfg['lic_upgrade_price'] ?? 10),
    ];
}

/**
 * 前台用户充值支付授权自助操作（使用站内余额扣款）
 * @param int $uid 用户id
 * @param int $id 授权id
 * @param string $action reset=重置绑定 / upgrade=提升域名上限(1个)
 * @return array [code, msg]
 */
function license_user_pay ($uid, $id, $action) {
    license_ensure();
    $uid = intval($uid);
    try {
        $lic = \think\Db::name('license')->where('id', $id)->find();
        if (!$lic || intval($lic['userid']) !== $uid) return ['code' => 0, 'msg' => '授权不存在'];
        $user = \think\Db::name('user')->where('id', $uid)->find();
        if (!$user) return ['code' => 0, 'msg' => '用户不存在'];
        $self = license_self_cfg();
        if ($action === 'reset') {
            // 重置绑定：有免费次数则不扣费；无则扣费
            $left = max(0, intval($lic['reset_limit'] ?? 0) - intval($lic['reset_used'] ?? 0));
            $fee = ($left > 0) ? 0 : $self['reset_price'];
            if ($fee > 0 && floatval($user['money']) < $fee) return ['code' => 0, 'msg' => '余额不足，请先充值'];
            \think\Db::name('license')->where('id', $id)->update(['domains' => '', 'reset_used' => intval($lic['reset_used'] ?? 0) + 1]);
            if ($fee > 0) {
                \think\Db::name('user')->where('id', $uid)->update(['money' => round(floatval($user['money']) - $fee, 2)]);
                \think\Db::name('transaction')->insert([
                    'userid' => $uid, 'content' => '授权重置绑定，授权码:' . $lic['code'] . '，消费:' . $fee,
                    'time' => time(),
                ]);
            }
            return ['code' => 1, 'msg' => $fee > 0 ? ('重置成功，已扣费 ' . $fee . ' 元') : '重置成功（使用免费次数）', 'fee' => $fee];
        } elseif ($action === 'upgrade') {
            $fee = $self['upgrade_price'];
            if (floatval($user['money']) < $fee) return ['code' => 0, 'msg' => '余额不足，请先充值'];
            $nl = intval($lic['domain_limit'] ?? 1) + 1;
            \think\Db::name('license')->where('id', $id)->update(['domain_limit' => $nl]);
            \think\Db::name('user')->where('id', $uid)->update(['money' => round(floatval($user['money']) - $fee, 2)]);
            \think\Db::name('transaction')->insert([
                'userid' => $uid, 'content' => '授权提升域名上限，授权码:' . $lic['code'] . '，消费:' . $fee,
                'time' => time(),
            ]);
            return ['code' => 1, 'msg' => '提升成功，已扣费 ' . $fee . ' 元，现上限 ' . $nl . ' 个域名', 'fee' => $fee, 'domain_limit' => $nl];
        }
        return ['code' => 0, 'msg' => '未知操作'];
    } catch (\Throwable $e) {
        return ['code' => 0, 'msg' => '操作失败'];
    }
}

/* ============================================================
 * 本系统自身授权验证（用户端模式）：进入后台/前台提示
 * ============================================================ */

/**
 * 检查“本系统”自身的授权状态。
 * 本系统作为用户端，向授权端(local_server)的 /verify 接口验证 local_code。
 * 说明：
 *  - 默认即自动检测（local_enable 默认开启）；访问系统任意页面会调用本函数。
 *  - 授权端地址默认 https://idc.pantd.com/license_api，可后台配置。
 *  - 本系统未填授权码(local_code)或授权端连接失败/校验失败 → 一律视为【未授权】(code=0)。
 * @return array ['code'=>1已授权/0未授权,'verified'=>bool,'msg'=>string,'domain'=>string,'cfg_ready'=>bool]
 */
function license_check_local () {
    $cfg = license_config();
    // 未开启授权验证（仅当显式关闭才算关闭）
    if (isset($cfg['local_enable']) && $cfg['local_enable'] === '0') {
        return ['code' => -1, 'msg' => '未启用本系统授权验证', 'verified' => false, 'domain' => ''];
    }
    // 授权端地址（默认 idc.pantd.com）
    $server = rtrim(trim($cfg['local_server'] ?? ''), '/');
    if ($server === '') $server = 'https://idc.pantd.com/license_api';
    $code = trim($cfg['local_code'] ?? '');
    $secret = trim($cfg['local_secret'] ?? '');
    // 当前访问域名
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $host = preg_replace('/:\d+$/', '', $host);
    $domain = strtolower(trim($host));
    // 未填本系统授权码 → 未授权（等待后台“去授权”）
    if ($code === '') {
        return ['code' => 0, 'msg' => '系统未授权，请前往后台“去授权”输入授权码', 'verified' => false, 'domain' => $domain];
    }
    // ===== 授权端定期自检：在自检周期内复用上次成功结果，避免每次访问都连授权端 =====
    $selfMonth = intval($cfg['selfcheck_month'] ?? 0);
    if ($selfMonth > 0) {
        $lastOk = intval($cfg['selfcheck_last'] ?? 0);
        if ($lastOk > 0 && time() < $lastOk + $selfMonth * 30 * 86400) {
            return ['code' => 1, 'msg' => '已授权', 'verified' => true, 'domain' => $domain, 'cached' => true];
        }
    }
    $url = $server . '/verify?code=' . urlencode($code) . '&domain=' . urlencode($domain);
    if ($secret !== '') $url .= '&sign=' . md5($code . $domain . $secret);
    $resp = false;
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
    }
    if ($resp === false || $resp === '') $resp = @file_get_contents($url);
    $json = json_decode($resp, true);
    if (!is_array($json)) {
        // 授权端连不上 → 视为未授权
        return ['code' => 0, 'msg' => '授权验证失败：无法连接授权服务器(' . $server . ')', 'verified' => false, 'domain' => $domain];
    }
    if (isset($json['code']) && $json['code'] == 1) {
        // 记录本次成功自检时间
        try {
            $cfg['selfcheck_last'] = (string)time();
            \think\Db::name('plugin')->where('code', 'license')->update(['config' => json_encode($cfg, JSON_UNESCAPED_UNICODE)]);
        } catch (\Throwable $e) {}
        return ['code' => 1, 'msg' => ($json['msg'] ?? '已授权'), 'verified' => true, 'domain' => $domain, 'data' => ($json['data'] ?? null)];
    }
    return ['code' => 0, 'msg' => ($json['msg'] ?? '未授权'), 'verified' => true, 'domain' => $domain];
}

/**
 * “去授权”：后台输入授权码，向授权端 bind 接口自动绑定当前域名，并开启本系统验证。
 * @param string $code 输入的授权码
 * @return array ['code'=>1成功/0失败/-1未启用,'msg'=>string,'domain'=>string]
 */
function license_activate_local ($code) {
    $cfg = license_config();
    if (empty($cfg['lic_enable']) || $cfg['lic_enable'] === '0') {
        return ['code' => -1, 'msg' => '授权端功能未开启'];
    }
    $server = rtrim(trim($cfg['local_server'] ?? ''), '/');
    if ($server === '') return ['code' => -1, 'msg' => '请先在插件配置中填写授权端地址'];
    $domain = '';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $host = preg_replace('/:\d+$/', '', $host);
    $domain = strtolower(trim($host));
    $code = strtoupper(trim($code));
    if ($code === '') return ['code' => -1, 'msg' => '请输入授权码'];
    // 向授权端 bind 接口绑定域名
    $url = $server . '/bind?code=' . urlencode($code) . '&domain=' . urlencode($domain);
    $resp = false;
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 12, CURLOPT_TIMEOUT => 12,
            CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
    }
    if ($resp === false || $resp === '') $resp = @file_get_contents($url);
    $json = json_decode($resp, true);
    if (!is_array($json)) {
        return ['code' => 0, 'msg' => '无法连接授权端服务器，请检查授权端地址'];
    }
    if (isset($json['code']) && $json['code'] == 1) {
        // 绑定成功 → 把 code 写入本系统配置，开启本地验证
        $cfg['local_code'] = $code;
        $cfg['local_enable'] = '1';
        try { \think\Db::name('plugin')->where('code', 'license')->update(['config' => json_encode($cfg, JSON_UNESCAPED_UNICODE)]); }
        catch (\Throwable $e) {}
        return ['code' => 1, 'msg' => '授权成功，已绑定域名 ' . $domain, 'domain' => $domain];
    }
    return ['code' => 0, 'msg' => ($json['msg'] ?? '授权失败')];
}
