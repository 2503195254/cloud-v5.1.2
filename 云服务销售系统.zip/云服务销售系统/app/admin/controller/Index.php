<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;
use think\Request;
use PHPMailer\PHPMailer\PHPMailer;

class Index extends Controller
{
public function _initialize() {
		if(!session("adminid")) {
			$this->redirect(admin_url('/login'));
		}
		$this->user=Db::name('admin')->where('id',session("adminid"))->find();
		$this->web=Db::name('web')->where('id',1)->find();
		$this->assign([
		            'webname'  => $this->web['name'],
		"user"=>$this->user,
        "admin_path"=>admin_path(),
		        ]);
		// 授权插件是否启用（用于后台菜单条件显示：仅启用后才出现）
		$plugLicenseInstalled = 0;
		$licEntry = PATH . 'plugins/license/license/license.php';
		if (is_file($licEntry)) {
			try { $licRow = Db::name('plugin')->where('code', 'license')->find(); if ($licRow && (int)$licRow['status'] == 1) $plugLicenseInstalled = 1; } catch (\Throwable $e) {}
		}
		$this->assign('plug_license', $plugLicenseInstalled);
		// 系统级授权：内嵌检测，一进入后台即校验，不依赖插件
		$this->sys_lic = vhss_system_license();
		$this->assign('sys_lic', $this->sys_lic);
		$this->assign('sys_lic_msg', $this->sys_lic['msg'] ?? '');
		$this->assign('sys_lic_domain', $this->sys_lic['domain'] ?? '');
		$this->assign('sys_edition', $this->sys_lic['edition'] ?? '');
		$this->assign('sys_version', vhss_version());
		$this->assign('sys_product', vhss_product());
	}


public function sq($id=null){
if($id){
$data1=Db::name('sq')->where("id",$id)->find();
if($data1){
if(Request::instance()->isPost()) {
$info=input("post.");
if($info["domain"]==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$data4=Db::name('sq')->where("id",$id)->update($info);
if($data4){
$array["code"]="1";
$array["msg"]="修改成功!";
}else{
$array["code"]="-1";
$array["msg"]="修改失败!";
}
}
return $array;
}
return $this->fetch('/'.$this->web["admintemplate"]."/sqs",[
"sq"=>$data1,
]);
}else{
$this->redirect(admin_url('/sq'));
}
}else{
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="add"){
$info=input("post.");
if($info["domain"]==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
unset($info["act"]);
$info["time"]=time();
$data1=Db::name('sq')->insertGetId($info);
if($data1){
$array["code"]="1";
$array["msg"]="添加成功!";
}else{
$array["code"]="-1";
$array["msg"]="添加失败!";
}
}
return $array;
}
if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name("sq")->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已经删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}

if(input("act")=="qbdelete"){
$data11=Db::name("sq")->select();
$a="0";
$b="0";
for($i=0;$i<count($data11);$i++){
$data1=Db::name("sq")->where("id",$data11[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过此条记录了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}
}
$search=input("search");
if($search){
$data=Db::name('sq')->whereor("id", 'like', '%'.$search.'%')->whereor("domain", 'like', '%'.$search.'%')->whereor("ip", 'like', '%'.$search.'%')->whereor("qq", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('sq')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/sq",[
"sq"=>$data,
]);
}
}
    public function index()
    {
//用户数量
$usercount = Db::name('user')->count();
$ticketcount1 = Db::name('ticket')->where("state","1")->count();
$ticketcount2 = Db::name('ticket')->where("state","2")->count();
$pay=Db::name('pay')->where([
"state"=>"1",
])->select();
$paymoney="0";
for($i=0;$i<count($pay);$i++){
$paymoney=$pay[$i]["money"]+$paymoney;
}
$paymoney1="0";
$time1=date("Y-m-d",time());
for($i=0;$i<count($pay);$i++){
$time2=date("Y-m-d",$pay[$i]["time"]);
if($time1==$time2){
$paymoney1=$pay[$i]["money"]+$paymoney1;
}
}

	
return $this->fetch('/'.$this->web["admintemplate"]."/index",[
"usercount"=>$usercount,
"ticketcount"=>$ticketcount1+$ticketcount2,
"paymoney"=>$paymoney,
"paymoney1"=>$paymoney1,
]);
    }

public function info(){
if(Request::instance()->isPost()) {
$name=input("name");
$mail=input("mail");
$qq=input("qq");
if($name=="" || $mail=="" || $qq==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$data=Db::name('admin')->where('id',$this->user["id"])->update([
"name" =>$name,
"mail"=>$mail,
"qq"=>$qq,
]);
if($data){
$array["code"]="1";
$array["msg"]="修改信息成功!";
}else{
$array["code"]="-1";
$array["msg"]="修改信息失败!";
}
}
return $array;
}
	
return $this->fetch('/'.$this->web["admintemplate"]."/info");
}



public function password(){
if(Request::instance()->isPost()) {
$oldpassword=input("oldpassword");
$password=input("password");
$newpassword=input("newpassword");
if($oldpassword=="" || $password=="" || $newpassword==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
if(!password_verify($oldpassword,$this->user["password"])){
$array["code"]="-1";
$array["msg"]="旧密码错误!";
}else{
if($password!=$newpassword){
$array["code"]="-1";
$array["msg"]="两次新密码不可一致!";
}else{
$data=Db::name('admin')->where('id',$this->user["id"])->update([
"password" =>password_hash($password,PASSWORD_DEFAULT),
]);
if($data){
$array["code"]="1";
$array["msg"]="修改密码成功!";
}else{
$array["code"]="-1";
$array["msg"]="修改密码失败!";
}
}
}
}
return $array;
}
	
return $this->fetch('/'.$this->web["admintemplate"]."/password");
}

public function logout() {
		session("adminid",null);
		$this->redirect(admin_url('/login'));
	}

/** 系统信息页：查看版本/信息/授权状态，去授权 */
public function sysinfo(){
	$lic = vhss_system_license();
	$licCode = vhss_lic_key();
	// 去授权：输入授权码 → 先向授权端验证，成功则保存授权码并重新检测
	if(Request::instance()->isPost()){
		$code = strtoupper(trim(input('code')));
		if($code === ''){
			return json(['code'=>-1,'msg'=>'请输入授权码']);
		}
		$domain = preg_replace('/:\d+$/', '', isset($_SERVER['HTTP_HOST'])?$_SERVER['HTTP_HOST']:'');
		$domain = strtolower(trim($domain));
		$server = vhss_lic_server();
		// 向授权端 bind 绑定域名
		$resp = false;
		if(function_exists('curl_init')){
			$ch = curl_init();
			curl_setopt_array($ch, [
				CURLOPT_URL => $server.'/bind?code='.urlencode($code).'&domain='.urlencode($domain),
				CURLOPT_RETURNTRANSFER=>true, CURLOPT_CONNECTTIMEOUT=>10, CURLOPT_TIMEOUT=>10,
				CURLOPT_SSL_VERIFYPEER=>false, CURLOPT_SSL_VERIFYHOST=>false,
			]);
			$resp = curl_exec($ch); curl_close($ch);
		}
		if($resp===false || $resp==='') $resp = @file_get_contents($server.'/bind?code='.urlencode($code).'&domain='.urlencode($domain));
		$json = json_decode($resp, true);
		if(!is_array($json)){
			return json(['code'=>0,'msg'=>'无法连接授权服务器，请确认已联网或稍后再试']);
		}
		if(isset($json['code']) && $json['code']==1){
			vhss_lic_save_key($code);
			return json(['code'=>1,'msg'=>'授权成功，已绑定域名 '.$domain]);
		}
		return json(['code'=>0,'msg'=>($json['msg'] ?? '授权失败')]);
	}
	// 版本与框架信息
	$phpVersion = PHP_VERSION;
	$dbInfo = '';
	try { $dbInfo = Db::query('SELECT VERSION() AS v'); $dbVersion = $dbInfo[0]['v'] ?? ''; } catch(\Throwable $e){ $dbVersion=''; }
	return $this->fetch('/'.$this->web["admintemplate"].'/sysinfo',[
		'lic'=>$lic,'lic_code'=>$licCode,
		'sys_version'=>vhss_version(),'sys_product'=>vhss_product(),
		'lic_server'=>vhss_lic_server(),
		'php_version'=>$phpVersion,'mysql_version'=>$dbVersion,
	]);
}


public function set() {
if(Request::instance()->isPost()) {
$webinput=input("post.");
// 后台访问地址（独立于 web 表保存，修改后旧地址立即失效）
$adminPathFlag = '';
if(isset($webinput["admin_path"])){
    $newPath = trim($webinput["admin_path"]);
    unset($webinput["admin_path"]);
    $oldWebPath = isset($this->web["admin_path"]) ? $this->web["admin_path"] : '';
    if($newPath !== $oldWebPath){
        if($newPath !== admin_path()){
            if(admin_save_path($newPath)){
                $adminPathFlag = '1';
            } else {
                $array["code"]="-1";
                $array["msg"]="后台地址格式错误或使用了保留字（仅允许字母、数字、下划线，且不能与前台上传/登录等路径相同）!";
                return $array;
            }
        }
    }
}
if($webinput["zcyxyz"]=="1" && $webinput["email"]!="1"){
$array["code"]="-1";
$array["msg"]="修改失败,开启注册邮箱验证需要先开启邮箱通知!";
}else{
if($webinput["yxdl"]=="1" && $webinput["email"]!="1"){
$array["code"]="-1";
$array["msg"]="修改失败,开启邮箱登录需要先开启邮箱通知!";
}else{
$data=Db::name('web')->where('id',"1")->update($webinput);
// update 返回受影响行数(0=无变化/1=成功,false=失败)，此处成功视为 $data!==false
if($data !== false){
$array["code"]="1";
if($adminPathFlag=="1"){
$array["msg"]="修改成功!后台地址已更新为: /".admin_path()."，旧地址已失效,请使用新地址访问后台。";
$array["admin_path"]=admin_url('');
}else{
$array["msg"]="修改成功!";
}
}else{
$array["code"]="-1";
$array["msg"]="修改失败!";
}
}
}

return $array;
}
return $this->fetch('/'.$this->web["admintemplate"]."/set",[
"web"=>$this->web,
"cronurl"=>(isHTTPS() ? 'https://' : 'http://').$_SERVER['HTTP_HOST']."/cron",
"template"=>my_dir(PATH."/app/index/view/"),
"admintemplate"=>my_dir(PATH."/app/admin/view/"),
]);
	}

	/* ===== 系统设置 · 独立子页面（配置提交统一走 /admin/set，仅更新各自提交的字段） ===== */

	/** 基本设置页 */
	public function sysbase() {
		return $this->fetch('/'.$this->web["admintemplate"]."/sysbase",[
			"web"=>$this->web,
			"template"=>my_dir(PATH."/app/index/view/"),
			"admintemplate"=>my_dir(PATH."/app/admin/view/"),
		]);
	}

	/** 邮箱设置页 */
	public function mailset() {
		return $this->fetch('/'.$this->web["admintemplate"]."/mailset",[
			"web"=>$this->web,
		]);
	}

	/** 邮箱验证测试：用当前 SMTP 配置发送一封测试邮件 */
	public function mailtest() {
		if(!Request::instance()->isPost()) return json(['code'=>-1,'msg'=>'参数错误']);
		$to = trim(input('testto'));
		if($to==='' || strpos($to,'@')===false) return json(['code'=>-1,'msg'=>'请输入正确的收件邮箱']);
		try {
			$r = Index::email($to, '邮箱配置测试邮件', '这是一封测试邮件，说明您的 SMTP 邮箱配置正确，可以正常发送邮件。<br/>发送时间：'.date('Y-m-d H:i:s').'<br/><br/>');
			if(isset($r['code']) && intval($r['code'])==1) return json(['code'=>1,'msg'=>'测试邮件已发送，请查收']);
			return json(['code'=>-1,'msg'=>$r['msg'] ?? '发送失败']);
		} catch (\Throwable $e) {
			return json(['code'=>-1,'msg'=>'发送失败：'.$e->getMessage()]);
		}
	}

	/** 推广中心页 */
	public function affset() {
		return $this->fetch('/'.$this->web["admintemplate"]."/affset",[
			"web"=>$this->web,
		]);
	}

	/** 计划任务页（检测各计划任务 + 启用/停用开关） */
	public function cronset() {
		if(Request::instance()->isPost()) {
			$x = input('post.');
			$data = [
				'crontask_1' => input('crontask_1') ? '1' : '0',
				'crontask_2' => input('crontask_2') ? '1' : '0',
				'crontask_3' => input('crontask_3') ? '1' : '0',
				'crontask_4' => input('crontask_4') ? '1' : '0',
				'crontask_5' => input('crontask_5') ? '1' : '0',
			];
			foreach ($data as $k => $v) {
				$exists = Db::name('set')->where('k', $k)->find();
				if ($exists) Db::name('set')->where('k', $k)->update(['v' => $v]);
				else Db::name('set')->insert(['k' => $k, 'v' => $v]);
			}
			// 同步保存到期/清理参数到 web 表
			$webUpd = [];
			foreach (['cronzz','cronsc','paycron','tickcron'] as $fk) {
				if (isset($x[$fk])) $webUpd[$fk] = $x[$fk];
			}
			if ($webUpd) Db::name('web')->where('id', '1')->update($webUpd);
			$array['code'] = '1'; $array['msg'] = '保存成功';
			return json($array);
		}
		// 读取各任务启用状态（默认启用）
		$task = ['crontask_1'=>'1','crontask_2'=>'1','crontask_3'=>'1','crontask_4'=>'1','crontask_5'=>'1'];
		try {
			$rows = Db::name('set')->select();
			foreach ($rows as $r) if (isset($task[$r['k']])) $task[$r['k']] = $r['v'];
		} catch (\Throwable $e) {}
		return $this->fetch('/'.$this->web["admintemplate"]."/cronset",[
			"web"=>$this->web,
			"cronurl"=>(isHTTPS() ? 'https://' : 'http://').$_SERVER['HTTP_HOST']."/cron",
			"task"=>$task,
		]);
	}

	/** 邮箱验证设置页 */
	public function yxset() {
		return $this->fetch('/'.$this->web["admintemplate"]."/yxset",[
			"web"=>$this->web,
		]);
	}

	/** 确保邮件模板表存在（含 category/enabled 字段，兼容旧表升级） */
	protected function ensureEmailTplTable() {
		try {
			Db::execute("CREATE TABLE IF NOT EXISTS `yun_email_tpl` (`id` INT(11) NOT NULL AUTO_INCREMENT,`name` VARCHAR(100) NOT NULL DEFAULT '',`subject` VARCHAR(200) NOT NULL DEFAULT '',`content` TEXT,`category` VARCHAR(50) NOT NULL DEFAULT '通知',`enabled` TINYINT(1) NOT NULL DEFAULT '1',`create_time` INT(11) NOT NULL DEFAULT '0',PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
			// 旧表升级：补齐可能缺失的字段
			$cols = Db::query("SHOW COLUMNS FROM `yun_email_tpl`");
			$has = array_column($cols, 'Field');
			if (!in_array('category', $has)) Db::execute("ALTER TABLE `yun_email_tpl` ADD COLUMN `category` VARCHAR(50) NOT NULL DEFAULT '通知' COMMENT '分类'");
			if (!in_array('enabled', $has)) Db::execute("ALTER TABLE `yun_email_tpl` ADD COLUMN `enabled` TINYINT(1) NOT NULL DEFAULT '1' COMMENT '是否启用'");
		} catch (\Throwable $e) {}
	}

	/**
	 * 系统自带邮件模板（原源码中各处发送的邮件主题）。
	 * 首次进入「邮件模板配置」时自动补齐，可后台编辑；
	 * 发送时按邮件主题匹配模板，模板内容中的 {内容} 占位符会被替换为系统动态拼好的正文。
	 */
	protected function ensureSysMailTpls() {
		try {
			$subjects = array(
				'回复工单通知','关闭工单通知','你的工单已被站长关闭','你的提现申请已处理',
				'推广余额提现通知','产品过户通知','产品接收通知','过户成功通知',
				'修改邮箱通知','请求绑定邮箱通知','旧密码修改密码通知','修改密码通知',
				'邮箱修改密码通知','提交工单通知','客户提交工单通知','客户回复工单通知',
				'找回密码通知','重置密码通知','登录成功通知','邮箱登录验证码通知',
				'邮箱登录成功通知','注册成功通知','注册验证码通知','购买授权成功通知',
				'购买产品通知','产品暂停通知','产品终止通知','工单关闭通知',
			);
			// 默认模板样式（腾讯云风格邮件模板：以邮件标题为主题，无品牌名与英文，正文排版丰富）
			$defaultBody = '<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,\'Microsoft YaHei\',sans-serif;">'
				. '<div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);">'
				. '<div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;">'
				. '<div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div>'
				. '<div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div>'
				. '</div>'
				. '<div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;">'
				. '<p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p>'
				. '<div style="margin:0 0 18px;">{内容}</div>'
				. '<div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">'
				. '温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>'
				. '如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。'
				. '</div>'
				. '</div>'
				. '<div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">'
				. '这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理'
				. '</div>'
				. '</div>'
				. '</div>';
			// 去重：同一 subject 只保留一条模板（避免历史重复插入导致列表/发送出现“内容重复”）
			try {
				$all = Db::name('email_tpl')->field('id,subject')->select();
				$seen = [];
				if ($all) {
					foreach ($all as $a) {
						$s = trim((string)$a['subject']);
						if ($s === '') continue;
						if (isset($seen[$s])) { Db::name('email_tpl')->where('id', $a['id'])->delete(); }
						else { $seen[$s] = 1; }
					}
				}
			} catch (\Throwable $e) {}
			foreach ($subjects as $sub) {
				$exists = Db::name('email_tpl')->where('subject', $sub)->find();
				// 分类：含“验证码”关键词归为验证码，否则通知
				$cat = (mb_strpos($sub, '验证码') !== false) ? '验证码' : '通知';
				if ($exists) {
					// 已存在：纠正分类（旧数据默认“通知”，验证码类应归为验证码）
					$curCat = isset($exists['category']) ? $exists['category'] : '';
					if ($cat === '验证码' && $curCat !== '验证码') {
						Db::name('email_tpl')->where('id', $exists['id'])->update(['category' => '验证码']);
					}
					// 旧预置模板自动升级为腾讯云新样式：若 content 仍是旧的品牌头样式（含 ☁ 云服务销售系统、Cloud 英文 或 旧页脚），则替换为新样式
					$curContent = isset($exists['content']) ? (string)$exists['content'] : '';
					$isOldStyle = (strpos($curContent, '☁ 云服务销售系统') !== false)
						|| (strpos($curContent, 'Cloud Service Sales System') !== false)
						|| (strpos($curContent, '本邮件由云服务销售系统自动发送') !== false);
					if ($isOldStyle) {
						Db::name('email_tpl')->where('id', $exists['id'])->update(['content' => $defaultBody]);
					}
				} else {
					Db::name('email_tpl')->insert([
						'name' => $sub, 'subject' => $sub, 'category' => $cat, 'enabled' => 1,
						'content' => $defaultBody, 'create_time' => time(),
					]);
				}
			}
		} catch (\Throwable $e) {}
	}

	/** 邮件模板配置：列表（分页/搜索/分类 + 启停/删除 + 编辑/新建入口） */
	public function mailtemplate() {
		$this->ensureEmailTplTable();
		$this->ensureSysMailTpls();
		$act = trim(input('act'));
		$id  = intval(input('id'));
		// 启用/禁用快捷切换（POST）
		if ($act === 'toggle' && Request::instance()->isPost() && $id > 0) {
			$row = Db::name('email_tpl')->where('id', $id)->find();
			$nw  = (intval($row['enabled']) === 1) ? 0 : 1;
			Db::name('email_tpl')->where('id', $id)->update(['enabled' => $nw]);
			return json(['code' => 1, 'msg' => $nw ? '已启用' : '已禁用', 'enabled' => $nw]);
		}
		// 删除（GET）
		if ($act === 'del' && $id > 0) {
			Db::name('email_tpl')->where('id', $id)->delete();
			return json(['code' => 1, 'msg' => '已删除']);
		}
		// 搜索 + 分类筛选 + 分页
		$keyword = trim(input('keyword'));
		$catSel  = trim(input('category'));
		$query = Db::name('email_tpl');
		if ($keyword !== '') $query = $query->where('name|subject', 'like', '%' . $keyword . '%');
		if ($catSel !== '') $query = $query->where('category', $catSel);
		$pageSize = 10;
		$list = $query->order('id desc')->paginate($pageSize);
		$listData = is_object($list) ? (method_exists($list, 'toArray') ? $list->toArray()['data'] : $list) : $list;
		if (is_object($list) && method_exists($list, 'render')) $pageHtml = $list->render();
		else $pageHtml = '';
		// 分类下拉选项
		$catRows = Db::name('email_tpl')->field('category')->group('category')->select();
		$cats = [];
		foreach ((array)$catRows as $c) if (!empty($c['category'])) $cats[] = $c['category'];
		return $this->fetch('/'.$this->web["admintemplate"]."/mailtemplate",[
			"list" => $listData, "page" => $pageHtml,
			"keyword" => $keyword, "cat_sel" => $catSel, "cats" => $cats,
		]);
	}

	/** 邮件模板 新建/编辑 独立页面：GET 渲染表单，POST 保存，保存/取消后返回列表 */
	public function mailtemplateEdit() {
		$this->ensureEmailTplTable();
		$id = intval(input('id'));
		if (Request::instance()->isPost()) {
			$idPost  = intval(input('id'));
			$name    = trim(input('name'));
			$subject = trim(input('subject'));
			$content = input('content');
			$category= trim(input('category')) ?: '通知';
			$enabled = (input('enabled') ? 1 : 0);
			if ($name === '' || $subject === '') return json(['code' => -1, 'msg' => '请填写模板名称与主题']);
			$data = ['name' => $name, 'subject' => $subject, 'content' => $content, 'category' => $category, 'enabled' => $enabled];
			if ($idPost > 0) {
				Db::name('email_tpl')->where('id', $idPost)->update($data);
				$msg = '保存成功';
			} else {
				$data['create_time'] = time();
				$data['enabled'] = 1; // 新增默认启用
				Db::name('email_tpl')->insert($data);
				$msg = '新增成功';
			}
			// 保存成功后返回列表页（JSON 由前端跳转）
			return json(['code' => 1, 'msg' => $msg, 'back' => admin_url('/mailtemplate')]);
		}
		$row = ($id > 0) ? Db::name('email_tpl')->where('id', $id)->find() : [];
		return $this->fetch('/'.$this->web["admintemplate"]."/mailtemplate_edit",[
			"row" => $row,
		]);
	}

	/**
	 * 查看开发文档：读取 docs 目录下的 Markdown 文档并做简单渲染展示
	 */
	public function docs() {
		// 可靠定位 docs 目录：优先 ROOT_PATH，再回退 dirname(APP_PATH)，防止环境差异导致找不到
		$docsDir = '';
		foreach ([ROOT_PATH.'docs', dirname(APP_PATH).DS.'docs'] as $cand) {
			if (is_dir($cand)) { $docsDir = $cand; break; }
		}
		$docs = [];
		if ($docsDir !== '') {
			$files = glob($docsDir . DIRECTORY_SEPARATOR . '*.md');
			if (!$files) $files = [];
			natsort($files);
			foreach ($files as $f) {
				$docs[] = [
					'file' => basename($f),
					'title' => preg_replace('/\.md$/', '', basename($f)),
				];
			}
		}
		$sel = trim(input('doc'));
		if ($sel === '' && $docs) $sel = $docs[0]['file'];
		$safeSel = preg_replace('/[^a-zA-Z0-9_\-\x{4e00}-\x{9fa5}（）()\.]/u', '', $sel);
		$content = '';
		if ($safeSel !== '') {
			$fp = $docsDir . '/' . $safeSel;
			if (is_file($fp)) $content = file_get_contents($fp);
		}
		// 简单 Markdown 渲染：标题 / 分隔线 / 无序列表 / 代码块 / 换行
		$html = htmlspecialchars($content, ENT_NOQUOTES, 'UTF-8');
		$lines = preg_split('/\r?\n/', $html);
		$out = ''; $inCode = false;
		foreach ($lines as $ln) {
			if (preg_match('/^\s*```/', $ln)) {
				if (!$inCode) { $out .= '<pre class="doc-code">'; $inCode = true; }
				else { $out .= '</pre>'; $inCode = false; }
				continue;
			}
			if ($inCode) { $out .= htmlspecialchars($ln, ENT_NOQUOTES, 'UTF-8') . "\n"; continue; }
			if (preg_match('/^#{1,6}\s+(.*)$/', $ln, $m)) {
				$lvl = substr_count($m[0], '#');
				$out .= '<h' . $lvl . '>' . $m[1] . '</h' . $lvl . '>';
			} elseif (preg_match('/^-\s+(.*)$/', $ln, $m) || preg_match('/^\*\s+(.*)$/', $ln, $m)) {
				$out .= '<li>' . $m[1] . '</li>';
			} elseif (preg_match('/^\s*---+\s*$/', $ln)) {
				$out .= '<hr>';
			} elseif (trim($ln) === '') {
				$out .= '<br>';
			} else {
				$out .= '<p>' . $ln . '</p>';
			}
		}
		if ($inCode) $out .= '</pre>';
		return $this->fetch('/'.$this->web["admintemplate"]."/docs",[
			"docs" => $docs, "sel" => $safeSel, "content" => $out,
		]);
	}

	/**
	 * 邮件群发：支持 全部用户 / 指定产品下的用户 / 手动填邮箱，支持 HTML 与模板
	 */
	public function mailbroadcast() {
		$this->ensureEmailTplTable();
		if (Request::instance()->isPost()) {
			$mode     = trim(input('mode'));        // all / product / manual
			$product  = intval(input('product'));   // 产品(cart)id
			$manual   = trim(input('manual'));       // 手动邮箱(逗号/换行分隔)
			$useTpl   = intval(input('use_tpl'));
			$subject  = trim(input('subject'));
			$content  = input('content');            // HTML
			$tplRow = null;
			if ($useTpl > 0) {
				$tplRow = Db::name('email_tpl')->where('id', $useTpl)->find();
				if (!$tplRow) return json(['code' => -1, 'msg' => '所选模板不存在']);
			}
			// 收集收件人
			$emails = [];
			if ($mode === 'all') {
				$users = Db::name('user')->where('mail', 'neq', '')->select();
				foreach ($users as $u) { $m = trim($u['mail']); if ($m !== '') $emails[$m] = 1; }
			} elseif ($mode === 'product') {
				if ($product <= 0) return json(['code' => -1, 'msg' => '请选择产品']);
				$orderRows = Db::name('order')->where('cartid', $product)->select();
				$uidArr = [];
				foreach ($orderRows as $o) { if (intval($o['userid']) > 0) $uidArr[] = intval($o['userid']); }
				if ($uidArr) {
					$users = Db::name('user')->where('id', 'in', array_unique($uidArr))->where('mail', 'neq', '')->select();
					foreach ($users as $u) { $m = trim($u['mail']); if ($m !== '') $emails[$m] = 1; }
				}
			} else {
				$manual = str_replace([',', '，', ';', '；', ' ', "\r\n", "\n"], ',', $manual);
				foreach (explode(',', $manual) as $m) { $m = trim($m); if ($m !== '') $emails[$m] = 1; }
			}
			if (empty($emails)) return json(['code' => -1, 'msg' => '没有可发送的收件人邮箱']);
			// 确定主题与内容
			$subj = $subject !== '' ? $subject : ($tplRow['subject'] ?? '');
			if ($subj === '') return json(['code' => -1, 'msg' => '请填写邮件主题']);
			// 若选择了模板：以模板为外壳，将 {内容} 替换为填写的正文、{标题} 替换为主题，避免出现字面占位符/无法获取标题与数据
			if ($tplRow && !empty($tplRow['content'])) {
				$tplContent = (string)$tplRow['content'];
				$body = str_replace(['{标题}', '{内容}'], [$subj, $content], $tplContent);
				if (trim($body) === '') return json(['code' => -1, 'msg' => '模板内容为空，请先编辑模板']);
			} else {
				$body = $content;
			}
			if ($body === '') return json(['code' => -1, 'msg' => '请填写邮件内容（或选择含内容的模板）']);
			// 逐封发送
			$ok = 0; $fail = 0; $failDetail = [];
			foreach (array_keys($emails) as $to) {
				$r = Index::email($to, $subj, $body, true);
				if (isset($r['code']) && $r['code'] == 1) $ok++;
				else { $fail++; $failDetail[] = $to . ':' . ($r['msg'] ?? '失败'); }
			}
			return json(['code' => 1, 'msg' => "发送完成：成功 {$ok} 封，失败 {$fail} 封", 'ok' => $ok, 'fail' => $fail, 'fail_detail' => $failDetail]);
		}
		// GET：渲染群发页
		$tplList = Db::name('email_tpl')->order('id desc')->select();
		$cartList = Db::name('cart')->where('hide', '0')->order('sort desc, id asc')->select();
		// select() 在当前 resultset_type=array 时直接返回数组，兼容两种返回形态
		if (is_object($tplList) && method_exists($tplList, 'toArray')) $tplList = $tplList->toArray();
		if (is_object($cartList) && method_exists($cartList, 'toArray')) $cartList = $cartList->toArray();
		$tplList = (array)$tplList; $cartList = (array)$cartList;
		return $this->fetch('/'.$this->web["admintemplate"]."/mailbroadcast",[
			"tpl_list" => $tplList, "cart_list" => $cartList,
		]);
	}

	/** 账号生成设置页：配置产品管理账号的生成格式 */
	public function accountset() {
		// 确保 yun_set 表存在
		try { Db::execute("CREATE TABLE IF NOT EXISTS `yun_set` (`id` INT(11) NOT NULL AUTO_INCREMENT,`k` VARCHAR(64) NOT NULL DEFAULT '',`v` VARCHAR(500) NOT NULL DEFAULT '',PRIMARY KEY (`id`),UNIQUE KEY `k` (`k`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;"); } catch (\Throwable $e) {}
		if (Request::instance()->isPost()) {
			$prefix = trim(input('account_prefix'));
			$len    = max(1, intval(input('account_len')));
			$digit  = (input('account_use_digit') ? '1' : '0');
			$letter = (input('account_use_letter') ? '1' : '0');
			if ($digit === '0' && $letter === '0') return json(['code' => -1, 'msg' => '数字英文至少要开启一项']);
			$data = [
				'account_prefix' => $prefix,
				'account_len' => (string)$len,
				'account_use_digit' => $digit,
				'account_use_letter' => $letter,
			];
			foreach ($data as $k => $v) {
				$exists = Db::name('set')->where('k', $k)->find();
				if ($exists) Db::name('set')->where('k', $k)->update(['v' => $v]);
				else Db::name('set')->insert(['k' => $k, 'v' => $v]);
			}
			return json(['code' => 1, 'msg' => '保存成功']);
		}
		// 读当前配置
		$cfg = ['account_prefix' => 'a', 'account_len' => '7', 'account_use_digit' => '1', 'account_use_letter' => '0'];
		try {
			$rows = Db::name('set')->select();
			foreach ($rows as $r) $cfg[$r['k']] = $r['v'];
		} catch (\Throwable $e) {}
		// 按当前规则生成一个示例账号
		$chars = '';
		if ($cfg['account_use_letter'] == '1') $chars .= 'abcdefghijklmnopqrstuvwxyz';
		if ($cfg['account_use_digit'] == '1') $chars .= '0123456789';
		if ($chars === '') $chars = '0123456789';
		$need = max(1, intval($cfg['account_len']) - strlen($cfg['account_prefix']));
		$sample = $cfg['account_prefix'] . random($need, $chars);
		return $this->fetch('/'.$this->web["admintemplate"]."/accountset",[
			"cfg" => $cfg, "sample" => $sample,
		]);
	}


public function user($id=null,$orderid=null) {
if(!$id){
if(Request::instance()->isPost()) {

if(input("act")=="login"){
$userid=input("userid");
if($userid==""){
$this->redirect('/user/index');
}else{
session("userid",$userid);
$this->redirect('/user/index');
}
}

if(input("act")=="delete"){
if(input("userid")){
$userid=explode(",",input("userid"));
$a="0";
$b="0";
for($i=0;$i<count($userid);$i++){
$data=Db::name("order")->where("userid",$userid[$i])->find();
if($data){
$b=$b+1;
}else{
$data1=Db::name("user")->where("id",$userid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除或者账户下还有未删除的产品!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}else{
$array["code"]="-1";
$array["msg"]="必填参数不可为空!!";
}
return $array;
}


if(input("act")=="qbdelete"){
$data11=Db::name("user")->select();
$a="0";
$b="0";
for($i=0;$i<count($data11);$i++){
$data=Db::name("order")->where("userid",$data11[$i]["id"])->find();
if($data){
$b=$b+1;
}else{
$data1=Db::name("user")->where("id",$data11[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除或者账户下还有未删除的产品!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}

if(input("act")=="adduser"){
$name=input("name");
$user=input("user");
$qq=input("qq");
$mail=input("mail");
$password=input("password");
if($name=="" || $user=="" || $qq=="" || $password==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
if($mail){
$data4=filter_var($mail, FILTER_VALIDATE_EMAIL);
if($data4){
	$data=Db::name('user')->where("user",$user)->find();
			if($data) {
				$array["code"]="-1";
				$array["msg"]="账号已存在!";
			} else {
$data2=Db::name('user')->where("mail",$mail)->find();
if($data2){
				$array["code"]="-1";
				$array["msg"]="邮箱已存在!";
}else{
	$data3=Db::name('user')->insertGetId([
				"name"=>$name,
				"user"=>$user,
				"password"=>password_hash($password,PASSWORD_DEFAULT),
				"mail"=>$mail,
				"time"=>time(),
                "qq"=>$qq,
                "address"=>"",
                "aff"=>"",
                "upperid"=>"",
				]);
if($data3){
$array["code"]="1";
$array["msg"]="添加成功!";
}else{
$array["code"]="-1";
$array["msg"]="添加失败!";
}
}
}
}else{
$array["code"]="-1";
$array["msg"]="邮箱格式错误!";
}
}else{






	$data=Db::name('user')->where("user",$user)->find();
			if($data) {
				$array["code"]="-1";
				$array["msg"]="账号已存在!";
			} else {
	$data3=Db::name('user')->insertGetId([
				"name"=>$name,
				"user"=>$user,
				"password"=>password_hash($password,PASSWORD_DEFAULT),
				"mail"=>$mail,
				"time"=>time(),
                "qq"=>$qq,
                "address"=>"",
                "aff"=>"",
                "upperid"=>"",
				]);
if($data3){
$array["code"]="1";
$array["msg"]="添加成功!";
}else{
$array["code"]="-1";
$array["msg"]="添加失败!";
}
}



}
}
return $array;
}


}
$search=input("search");
if($search){
$users=Db::name('user')->whereor("id", 'like', '%'.$search.'%')->whereor("user", 'like', '%'.$search.'%')->whereor("name", 'like', '%'.$search.'%')->whereor("mail", 'like', '%'.$search.'%')->whereor("qq", 'like', '%'.$search.'%')->whereor("address", 'like', '%'.$search.'%')->whereor("aff", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$users=Db::name('user')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/user",[
"users"=>$users,
]);
}else{
$data=Db::name("user")->where("id",$id)->find();
if($data){
if($orderid){
$data1=Db::name("order")->where([
"id"=>$orderid,
"userid"=>$id,
])->find();
if($data1){
//用户产品
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="edit"){
$post=input("post.");
$post["atime"]=strtotime($post["atime"]);
if($post["atime"]==""){
$post["atime"]="1";
}
$post["ztime"]=strtotime($post["ztime"]);
if($post["ztime"]==""){
$post["ztime"]="1";
}
unset($post["act"]);
$db=Db::name("order")->where([
"id"=>$orderid,
"userid"=>$id,
])->update($post);
if($db){
	$array["code"]="1";
	$array["msg"]="修改成功!";
}else{
	$array["code"]="-1";
	$array["msg"]="修改失败!";
}
return $array;
}
//暂停
if($act=="stop"){
if($data1["state"]=="3"){
	$array["code"]="-1";
	$array["msg"]="产品已终止,禁止修改此状态!";
}else{
$da1=Db::name('cart')->where("id",$data1["cartid"])->find();
$da2=Db::name('server')->where("id",$da1["serverid"])->find();
include_once PATH."plugins/host/".$da2["serverplugins"]."/".$da2["serverplugins"].".php";
$function=$da2["serverplugins"]."_"."SuspendAccount";
if(function_exists($function)){
$da4=@$function($da2,$data1,$da1);
}
$da5=Db::name("order")->where("id",$data1["id"])->update([
"state"=>"2",
]);
	$array["code"]="1";
	$array["msg"]="暂停成功!";
}
return $array;

}
//解除暂停
if($act=="stopoff"){
if($data1["state"]=="3"){
	$array["code"]="-1";
	$array["msg"]="产品已终止,禁止修改此状态!";
}else{
$da1=Db::name('cart')->where("id",$data1["cartid"])->find();
$da2=Db::name('server')->where("id",$da1["serverid"])->find();
include_once PATH."plugins/host/".$da2["serverplugins"]."/".$da2["serverplugins"].".php";
$function=$da2["serverplugins"]."_"."UnsuspendAccount";
if(function_exists($function)){
$da3=@$function($da2,$data1,$da1);
}
$da5=Db::name("order")->where("id",$data1["id"])->update([
"state"=>"1",
]);
	$array["code"]="1";
	$array["msg"]="解除暂停成功!";
}
return $array;

}
//终止
if($act=="end"){
$da1=Db::name('cart')->where("id",$data1["cartid"])->find();
$da2=Db::name('server')->where("id",$da1["serverid"])->find();
include_once PATH."plugins/host/".$da2["serverplugins"]."/".$da2["serverplugins"].".php";
$function=$da2["serverplugins"]."_"."TerminateAccount";
if(function_exists($function)){
$da4=@$function($da2,$data1,$da1);
}
$da5=Db::name("order")->where("id",$data1["id"])->update([
"state"=>"3",
]);
$da6=Db::name("cart")->where("id",$data1["cartid"])->update([
"inventory"=>$da1["inventory"]+1,
]);
	$array["code"]="1";
	$array["msg"]="终止成功!";
return $array;

}
//删除
if($act=="delete"){
$da5=Db::name("order")->where("id",$data1["id"])->delete();
	$array["code"]="1";
	$array["msg"]="删除成功!";
return $array;
}


}



$userorder=Db::name("order")->where([
"id"=>$orderid,
"userid"=>$id,
])->find();


$da6=Db::name('cart')->where("id",$userorder["cartid"])->find();
$da5=Db::name('server')->where("id",$da6["serverid"])->find();
include_once PATH."plugins/host/".$da5["serverplugins"]."/".$da5["serverplugins"].".php";
$function=$da5["serverplugins"]."_"."OrderConfigOptions";
if(function_exists($function)){
$da4=@$function();
for($i=0;$i<count($da4);$i++){
foreach ($userorder as $key => $value){
if($da4[$i]["name"]==$key){
if($value!=""){
$da4[$i]["value"]=$value;
}
}
}
}
$data7=$da4;
}else{
$data7="";
}

return $this->fetch('/'.$this->web["admintemplate"]."/userorder",[
"userorder"=>$userorder,
"data7"=>$data7,
]);



}else{
$this->redirect(admin_url('/user/'.$id));
}
}else{
//用户信息
if(Request::instance()->isPost()) {
$name=input("name");
$user=input("user");
$money=input("money");
$qq=input("qq");
$mail=input("mail");
$address=input("address");
$password=input("password");
$aff=input("aff");
$affmoney=input("affmoney");
$upperid=input("upperid");
$state=input("state");
if($name=="" || $user=="" || $money=="" || $qq=="" || $state=="" || $affmoney==""){
	$array["code"]="-1";
	$array["msg"]="必填项不可为空!";
}else{
if($password){
$data3=Db::name('user')->where('id',$data["id"])->update([
"name"=>$name,
"user"=>$user,
"money"=>$money,
"qq"=>$qq,
"mail"=>$mail,
"address"=>$address,
"aff"=>$aff,
"affmoney"=>$affmoney,
"upperid"=>$upperid,
"state"=>$state,
"password"=>password_hash($password,PASSWORD_DEFAULT),
]);

}else{
$data3=Db::name('user')->where('id',$data["id"])->update([
"name"=>$name,
"user"=>$user,
"money"=>$money,
"qq"=>$qq,
"mail"=>$mail,
"address"=>$address,
"aff"=>$aff,
"affmoney"=>$affmoney,
"upperid"=>$upperid,
"state"=>$state,
]);

}
if($data3){
	$array["code"]="1";
	$array["msg"]="修改成功!";
}else{
	$array["code"]="-1";
	$array["msg"]="修改失败!";
}
}
return $array;
}

$data2=Db::name("order")->where([
"userid"=>$id,
])->order('id desc')->select();
for($i=0;$i<count($data2);$i++)  
   {
$cart=Db::name('cart')->where('id',$data2[$i]["cartid"])->find();
$data2[$i]["cartid"]=$cart["name"];
} 


	
return $this->fetch('/'.$this->web["admintemplate"]."/userinfo",[
"userinfo"=>$data,
"userorder"=>$data2,
"userid"=>$id,
]);

}
}else{
$this->redirect(admin_url('/user'));
}


}
}



public function ticket($id=null){
if($id){
$data=Db::name('ticket')->where("id",$id)->find();
if($data){
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="submit"){
$content=input("content");
if($content==""){
	$array["code"]="-1";
	$array["msg"]="必填参数不可为空!";
}else{
$array1=array(
array(
"personnel"=>"1",
"content"=>$content,
"time"=>time(),
),
);
$array2=array_merge(json_decode($data["content"],true),$array1);
$data1=Db::name('ticket')->where([
"id"=>$id,
])->update([
'content' =>json_encode($array2),
'state'=>'3',
]);
if($data1){
if($this->web["email"]=="1"){
$user=Db::name('user')->where("id",$data["userid"])->find();
if($user["mail"]){
$mailbox=$this->email($user["mail"],"回复工单通知","站长在时间:".date("Y-m-d H:i:s")."已回复工单<br/>工单id:".$id."<br/>请及时查看!<br/><br/>");
}
}
$array["code"]="1";
$array["msg"]="回复工单成功!";
}else{
$array["code"]="-1";
$array["msg"]="回复工单失败!";
}
}
return $array;
}
if($act=="end"){
if($data["state"]=="4"){
$array["code"]="-1";
$array["msg"]="工单已关闭!";
}else{
$data1=Db::name('ticket')->where([
"id"=>$id,
])->update([
'state'=>'4',
]);
if($data1){
if($this->web["email"]=="1"){
$user=Db::name('user')->where("id",$data["userid"])->find();
if($user["mail"]){
$mailbox=$this->email($user["mail"],"关闭工单通知","站长在时间:".date("Y-m-d H:i:s")."已关闭工单<br/>工单id:".$id."<br/><br/>");
}
}
$array["code"]="1";
$array["msg"]="关闭工单成功!";
}else{
$array["code"]="-1";
$array["msg"]="关闭工单失败!";
}
}
return $array;
}
}

$user=Db::name('user')->where('id',$data["userid"])->find();
$data["username"]=$user["name"];
$data["userqq"]=$user["qq"];
$data["content"]=json_decode($data["content"],true);
return $this->fetch('/'.$this->web["admintemplate"]."/tickets",[
"tickets"=>$data,
]);
}else{
$this->redirect(admin_url('/ticket'));
}
}else{
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name("ticket")->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已经删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}


if($act=="off"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data2=Db::name('ticket')->where("id",$cid[$i])->find();
$data1=Db::name("ticket")->where("id",$cid[$i])->update([
"state"=>"4",
]);
if($this->web["email"]=="1"){
$data3=Db::name('user')->where("id",$data2["userid"])->find();
if($data3["mail"]){
$mailbox=$this->email($data3["mail"],"你的工单已被站长关闭","站长在时间:".date("Y-m-d H:i:s")."已关闭你的工单<br/>工单ID:".$data2["id"]."<br/><br/>");
}
}
if($data2["state"]!="4"){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已经关闭过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}

if(input("act")=="qbdelete"){
$data11=Db::name("ticket")->select();
$a="0";
$b="0";
for($i=0;$i<count($data11);$i++){
$data1=Db::name("ticket")->where("id",$data11[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过此条记录了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}
}
$search=input("search");
if($search){
$data=Db::name('ticket')->whereor("id", 'like', '%'.$search.'%')->whereor("userid", 'like', '%'.$search.'%')->whereor("title", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('ticket')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/ticket",[
"ticket"=>$data,
]);
}
}


public function classification($id=null){
if($id){
$data2=$data=Db::name('product')->where("id",$id)->find();
if($data2){
if(Request::instance()->isPost()) {
$name=input("name");
$introduce=input("introduce");
$hide=input("hide");
$sort=input("sort");
if($name==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$data3=Db::name('product')->where("id",$id)->update([
"name"=>$name,
"introduce"=>$introduce,
"hide"=>$hide,
"sort"=>$sort,
]);
if($data3){
$array["code"]="1";
$array["msg"]="修改成功!";
}else{
$array["code"]="-1";
$array["msg"]="修改失败!";
}
}
return $array;
}

return $this->fetch('/'.$this->web["admintemplate"]."/classifications",[
"product"=>$data2,
]);
}else{
$this->redirect(admin_url('/classification'));
}

}else{
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="add"){
$name=input("name");
$introduce=input("introduce");
$hide=input("hide");
$sort=input("sort");
if($name==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$data1=Db::name('product')->insertGetId([
				"name"=>$name,
				"introduce"=>$introduce,
                "hide"=>$hide,
                "sort"=>$sort,
				]);
if($data1){
$array["code"]="1";
$array["msg"]="添加成功!";
}else{
$array["code"]="-1";
$array["msg"]="添加失败!";
}
}
return $array;
}

if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name("product")->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已经删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}

if(input("act")=="qbdelete"){
$data11=Db::name("product")->select();
$a="0";
$b="0";
for($i=0;$i<count($data11);$i++){
$data1=Db::name("product")->where("id",$data11[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过此条记录了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}


}
$search=input("search");
if($search){
$data=Db::name('product')->whereor("id", 'like', '%'.$search.'%')->whereor("name", 'like', '%'.$search.'%')->whereor("introduce", 'like', '%'.$search.'%')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('product')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/classification",[
"product"=>$data,
]);
}
}


public function server($id=null){
if($id){
$data2=$data=Db::name('server')->where("id",$id)->find();
if($data2){
if(Request::instance()->isPost()) {
$info=input("post.");
if($info["name"]==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$data3=Db::name('server')->where("id",$id)->update($info);
if($data3){
$array["code"]="1";
$array["msg"]="修改成功!";
}else{
$array["code"]="-1";
$array["msg"]="修改失败!";
}
}
return $array;
}

if(file_exists(PATH."plugins/host/".$data2["serverplugins"]."/".$data2["serverplugins"].".php")){
include_once PATH."plugins/host/".$data2["serverplugins"]."/".$data2["serverplugins"].".php";
$function=$data2["serverplugins"]."_"."AdminConfigOptions";
if(function_exists($function)){
$da4=@$function();

for($i=0;$i<count($da4);$i++){
foreach ($data2 as $key => $value){
if($da4[$i]["name"]==$key){
if($value!=""){
$da4[$i]["value"]=$value;
}
}
}
}
$data7=$da4;
}else{
$data7="";
}
}else{
$data7="";
}
return $this->fetch('/'.$this->web["admintemplate"]."/servers",[
"server"=>$data2,
"plugins"=>my_dir(PATH."/plugins/host"),
"data7"=>$data7,
]);
}else{
$this->redirect(admin_url('/server'));
}

}else{
if(Request::instance()->isPost()) {
$act=input("act");

if($act=="add"){
$info=input("post.");
if($info["name"]==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
unset($info["act"]);
$data1=Db::name('server')->insertGetId($info);
if($data1){
$array["code"]="1";
$array["msg"]="添加成功!";
}else{
$array["code"]="-1";
$array["msg"]="添加失败!";
}
}
return $array;
}

if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data4=Db::name('cart')->where("serverid",$cid[$i])->find();
if($data4){
$b=$b+1;
}else{
$data1=Db::name('server')->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了或者该服务器下还有未删除的产品!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}

if($act=="qbdelete"){
$data18=Db::name("server")->select();
$a="0";
$b="0";
for($i=0;$i<count($data18);$i++){
$data4=Db::name('cart')->where("serverid",$data18[$i]["id"])->find();
if($data4){
$b=$b+1;
}else{
$data1=Db::name('server')->where("id",$data18[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了或者该服务器下还有未删除的产品!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}
}
$search=input("search");
if($search){
$data=Db::name('server')->whereor("id", 'like', '%'.$search.'%')->whereor("name", 'like', '%'.$search.'%')->whereor("host", 'like', '%'.$search.'%')->whereor("ip", 'like', '%'.$search.'%')->whereor("security", 'like', '%'.$search.'%')->whereor("port", 'like', '%'.$search.'%')->whereor("user", 'like', '%'.$search.'%')->whereor("password", 'like', '%'.$search.'%')->whereor("serverplugins", 'like', '%'.$search.'%')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('server')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/server",[
"server"=>$data,
"plugins"=>my_dir(PATH."/plugins/host"),
]);
}
}

public function product($id=null){
// 确保 yun_cart 表存在 islicense / lic_level_id 字段(授权类产品标记与授权等级)
try { Db::execute("ALTER TABLE `yun_cart` ADD `islicense` varchar(10) NOT NULL DEFAULT '0'"); } catch (\Throwable $e) {}
try { Db::execute("ALTER TABLE `yun_cart` ADD `lic_level_id` int(11) NOT NULL DEFAULT '0'"); } catch (\Throwable $e) {}
// 授权等级列表(仅授权插件安装后提供)
$licPlugOn = 0;
try { $licPlugOn = Db::name('plugin')->where('code', 'license')->find() ? 1 : 0; } catch (\Throwable $e) {}
$licLevels = [];
if ($licPlugOn && is_file(PATH.'plugins/license/license/license.php')) {
    include_once PATH.'plugins/license/license/license.php';
    if (function_exists('license_level_list')) $licLevels = license_level_list();
}
$this->assign('lic_plug_on', $licPlugOn);
$this->assign('lic_levels', $licLevels);
if($id){
$data1=Db::name('cart')->where("id",$id)->find();
if($data1){
if(Request::instance()->isPost()) {
$info=input("post.");
if(!is_numeric($info["inventory"]) || !is_numeric($info["money"])){
$array["code"]="-1";
$array["msg"]="库存或价格必须是数字!";
}else{
if(floor($info["inventory"])!=$info["inventory"]){
$array["code"]="-1";
$array["msg"]="库存必须是整数!";
}else{
$upgrades=@json_encode($info["upgrades"]);
if($upgrades=="null"){
$upgrades="";
}
$info["upgrades"]=$upgrades;
if($info["name"]==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
if($info["serverid"]!=$data1["serverid"]){
$info["upgrade"]="0";
$info["upgrades"]="";
}
if($info["firstmo"]=="1" && $info["cycle"]=="unrestricted"){
$array["code"]="-1";
$array["msg"]="一次性产品不可设置首次购买免费!";
}else{
$data4=Db::name('cart')->where("id",$id)->update($info);
if($data4){
$array["code"]="1";
$array["msg"]="修改成功!";
}else{
$array["code"]="-1";
$array["msg"]="修改失败!";
}
}
}
}
}
return $array;
}
$data1["upgrades"]=json_decode($data1["upgrades"],true);
$data11=Db::name('cart')->where("serverid",$data1["serverid"])->select();


$data2=Db::name('product')->select();
$data3=Db::name('server')->select();


$da5=Db::name('server')->where("id",$data1["serverid"])->find();
if(file_exists(PATH."plugins/host/".$da5["serverplugins"]."/".$da5["serverplugins"].".php")){
include_once PATH."plugins/host/".$da5["serverplugins"]."/".$da5["serverplugins"].".php";
$function=$da5["serverplugins"]."_"."ConfigOptions";
if(function_exists($function)){
$da4=@$function();
for($i=0;$i<count($da4);$i++){
foreach ($data1 as $key => $value){
if($da4[$i]["name"]==$key){
if($value!=""){
$da4[$i]["value"]=$value;
}
}
}
}
$data7=$da4;
}else{
$data7="";
}
}else{
$data7="";
}
return $this->fetch('/'.$this->web["admintemplate"]."/products",[
"product"=>$data1,//产品信息
"upgrade"=>$data11,//全局升级产品数据
"data2"=>$data2,//全部分类数据
"data3"=>$data3,//全部服务器数据
"data7"=>$data7,
]);
}else{
$this->redirect(admin_url('/product'));
}
}else{
if(Request::instance()->isPost()) {
$act=input("act");

if($act=="add"){
$info=input("post.");
if($info["name"]==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
if(!is_numeric($info["inventory"]) || !is_numeric($info["money"])){
$array["code"]="-1";
$array["msg"]="库存或价格必须是数字!";
}else{
unset($info["act"]);
$data1=Db::name('cart')->insertGetId($info);
if($data1){
$array["code"]="1";
$array["msg"]="添加成功!";
}else{
$array["code"]="-1";
$array["msg"]="添加失败!";
}
}
}
return $array;
}

if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data4=Db::name('order')->where("cartid",$cid[$i])->find();
if($data4){
$b=$b+1;
}else{
$data1=Db::name('cart')->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了或者该产品下还有未删除的订单!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}


if($act=="qbdelete"){
$data12=Db::name("cart")->select();
$a="0";
$b="0";
for($i=0;$i<count($data12);$i++){
$data4=Db::name('order')->where("cartid",$data12[$i]["id"])->find();
if($data4){
$b=$b+1;
}else{
$data1=Db::name('cart')->where("id",$data12[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了或者该产品下还有未删除的订单!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}

}
$search=input("search");
if($search){
$data=Db::name('cart')->whereor("id", 'like', '%'.$search.'%')->whereor("name", 'like', '%'.$search.'%')->whereor("content", 'like', '%'.$search.'%')->whereor("money", 'like', '%'.$search.'%')->whereor("inventory", 'like', '%'.$search.'%')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('cart')->paginate(10);
}
$data2=Db::name('product')->select();
$data3=Db::name('server')->select();
return $this->fetch('/'.$this->web["admintemplate"]."/product",[
"product"=>$data,
"data2"=>$data2,
"data3"=>$data3,
]);
}
}


public function announcement($id=null){
if($id){
$data1=Db::name('announcement')->where("id",$id)->find();
if($data1){
if(Request::instance()->isPost()) {
$info=input("post.");
if($info["name"]==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$info["time"]=strtotime($info["time"]);
if($info["time"]==""){
$info["time"]="1";
}
$data4=Db::name('announcement')->where("id",$id)->update($info);
if($data4){
$array["code"]="1";
$array["msg"]="修改成功!";
}else{
$array["code"]="-1";
$array["msg"]="修改失败!";
}
}
return $array;
}
return $this->fetch('/'.$this->web["admintemplate"]."/announcements",[
"announcement"=>$data1,
]);
}else{
$this->redirect(admin_url('/announcement'));
}
}else{
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="add"){
$info=input("post.");
if($info["name"]==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
unset($info["act"]);
$info["time"]=time();
$data1=Db::name('announcement')->insertGetId($info);
if($data1){
$array["code"]="1";
$array["msg"]="添加成功!";
}else{
$array["code"]="-1";
$array["msg"]="添加失败!";
}
}
return $array;
}
if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name("announcement")->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已经删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}

if(input("act")=="qbdelete"){
$data11=Db::name("announcement")->select();
$a="0";
$b="0";
for($i=0;$i<count($data11);$i++){
$data1=Db::name("announcement")->where("id",$data11[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过此条记录了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}
}
$search=input("search");
if($search){
$data=Db::name('announcement')->whereor("id", 'like', '%'.$search.'%')->whereor("name", 'like', '%'.$search.'%')->whereor("information", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('announcement')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/announcement",[
"announcement"=>$data,
]);
}
}


public function aff(){
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="ok"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$data3=Db::name('afftxjl')->where("id",$cid)->find();
if($data3["state"]=="1"){
$array["code"]="-1";
$array["msg"]="已经处理过了!";
}else{
$data4=Db::name('afftxjl')->where("id",$cid)->update([
"state"=>"1",
]);
if($data4){
if($this->web["email"]=="1"){
$user=Db::name('user')->where("id",$data3["userid"])->find();
if($user["mail"]){
$mailbox=$this->email($user["mail"],"你的提现申请已处理","站长在时间:".date("Y-m-d H:i:s")."已处理你的提现申请<br/>提现记录ID:".$cid."<br/>请及时查看!<br/><br/>");
}
}
$array["code"]="1";
$array["msg"]="成功!";
}else{
$array["code"]="-1";
$array["msg"]="失败!";
}
}
}
return $array;
}
if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name("afftxjl")->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已经删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}

if(input("act")=="qbdelete"){
$data11=Db::name("afftxjl")->select();
$a="0";
$b="0";
for($i=0;$i<count($data11);$i++){
$data1=Db::name("afftxjl")->where("id",$data11[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过此条记录了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}
}
$search=input("search");
if($search){
$data=Db::name('afftxjl')->whereor("id", 'like', '%'.$search.'%')->whereor("information", 'like', '%'.$search.'%')->whereor("money", 'like', '%'.$search.'%')->whereor("state", 'like', '%'.$search.'%')->whereor("userid", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('afftxjl')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/aff",[
"aff"=>$data,
]);
}

public function order($id=null){
if($id){
$data1=Db::name('order')->where("id",$id)->find();
if($data1){
$da6=Db::name('cart')->where("id",$data1["cartid"])->find();
$da5=Db::name('server')->where("id",$da6["serverid"])->find();
include_once PATH."plugins/host/".$da5["serverplugins"]."/".$da5["serverplugins"].".php";
$function=$da5["serverplugins"]."_"."OrderConfigOptions";
if(function_exists($function)){
$da4=@$function();
for($i=0;$i<count($da4);$i++){
foreach ($data1 as $key => $value){
if($da4[$i]["name"]==$key){
if($value!=""){
$da4[$i]["value"]=$value;
}
}
}
}
$data7=$da4;
}else{
$data7="";
}

if(Request::instance()->isPost()) {
$act=input("act");


//暂停
if($act=="stop"){
if($data1["state"]=="3"){
	$array["code"]="-1";
	$array["msg"]="产品已终止,禁止修改此状态!";
}else{
$da1=Db::name('cart')->where("id",$data1["cartid"])->find();
$da2=Db::name('server')->where("id",$da1["serverid"])->find();
include_once PATH."plugins/host/".$da2["serverplugins"]."/".$da2["serverplugins"].".php";
$function=$da2["serverplugins"]."_"."SuspendAccount";
if(function_exists($function)){
$da4=@$function($da2,$data1,$da1);
}
$da5=Db::name("order")->where("id",$data1["id"])->update([
"state"=>"2",
]);
	$array["code"]="1";
	$array["msg"]="暂停成功!";
}
return $array;

}
//解除暂停
if($act=="stopoff"){
if($data1["state"]=="3"){
	$array["code"]="-1";
	$array["msg"]="产品已终止,禁止修改此状态!";
}else{
$da1=Db::name('cart')->where("id",$data1["cartid"])->find();
$da2=Db::name('server')->where("id",$da1["serverid"])->find();
include_once PATH."plugins/host/".$da2["serverplugins"]."/".$da2["serverplugins"].".php";
$function=$da2["serverplugins"]."_"."UnsuspendAccount";
if(function_exists($function)){
$da3=@$function($da2,$data1,$da1);
}
$da5=Db::name("order")->where("id",$data1["id"])->update([
"state"=>"1",
]);
	$array["code"]="1";
	$array["msg"]="解除暂停成功!";
}
return $array;

}
//终止
if($act=="end"){
$da1=Db::name('cart')->where("id",$data1["cartid"])->find();
$da2=Db::name('server')->where("id",$da1["serverid"])->find();
include_once PATH."plugins/host/".$da2["serverplugins"]."/".$da2["serverplugins"].".php";
$function=$da2["serverplugins"]."_"."TerminateAccount";
if(function_exists($function)){
$da4=@$function($da2,$data1,$da1);
}
$da5=Db::name("order")->where("id",$data1["id"])->update([
"state"=>"3",
]);
$da6=Db::name("cart")->where("id",$data1["cartid"])->update([
"inventory"=>$da1["inventory"]+1,
]);
	$array["code"]="1";
	$array["msg"]="终止成功!";
return $array;

}
 //删除
 if($act=="delete"){
 $da5=Db::name("order")->where("id",$data1["id"])->delete();
 	$array["code"]="1";
 	$array["msg"]="删除成功!";
 return $array;
 }

 //【API上游对接】提交上游开通
 if($act=="apiforward"){
 	$apiFile=PATH."plugins/api/api/api.php";
 	if(!is_file($apiFile)){ $array["code"]="-1"; $array["msg"]="未安装API对接插件"; return $array; }
 	include_once $apiFile;
 	if(!function_exists("api_forward_create")){ $array["code"]="-1"; $array["msg"]="API插件缺少开通函数"; return $array; }
 	$r=api_forward_create($data1["id"]);
 	$array["code"]=isset($r["code"])?$r["code"]:"-1";
 	$array["msg"]=isset($r["msg"])?$r["msg"]:"未知错误";
	return $array;
 }

 //【API上游对接】同步上游状态
 if($act=="apistatus"){
 	$apiFile=PATH."plugins/api/api/api.php";
 	if(!is_file($apiFile)){ $array["code"]="-1"; $array["msg"]="未安装API对接插件"; return $array; }
 	include_once $apiFile;
 	if(!function_exists("api_sync_upstream_status")){ $array["code"]="-1"; $array["msg"]="API插件缺少状态同步函数"; return $array; }
 	$r=api_sync_upstream_status($data1["id"]);
 	$array["code"]=isset($r["code"])?$r["code"]:"-1";
 	$array["msg"]=isset($r["msg"])?$r["msg"]:"未知错误";
	return $array;
 }

 if($act=="edit"){
$post=input("post.");
$post["atime"]=strtotime($post["atime"]);
if($post["atime"]==""){
$post["atime"]="1";
}
$post["ztime"]=strtotime($post["ztime"]);
if($post["ztime"]==""){
$post["ztime"]="1";
}
unset($post["act"]);
$db=Db::name("order")->where([
"id"=>$id,
])->update($post);
if($db){
	$array["code"]="1";
	$array["msg"]="修改成功!";
}else{
	$array["code"]="-1";
	$array["msg"]="修改失败!";
}
return $array;
}
}

return $this->fetch('/'.$this->web["admintemplate"]."/orders",[
"order"=>$data1,
"data7"=>$data7,
]);
}else{
$this->redirect(admin_url('/order'));
}
}else{
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name('order')->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}


if($act=="qbdelete"){
$data12=Db::name("order")->select();
$a="0";
$b="0";
for($i=0;$i<count($data12);$i++){
$data1=Db::name('order')->where("id",$data12[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}

}
$search=input("search");
if($search){
$data=Db::name('order')->whereor("id", 'like', '%'.$search.'%')->whereor("user", 'like', '%'.$search.'%')->whereor("password", 'like', '%'.$search.'%')->whereor("userid", 'like', '%'.$search.'%')->whereor("cartid", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('order')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/order",[
"order"=>$data,
]);
}
}


public function pay(){
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name('pay')->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}


if($act=="qbdelete"){
$data12=Db::name("pay")->select();
$a="0";
$b="0";
for($i=0;$i<count($data12);$i++){
$data1=Db::name('pay')->where("id",$data12[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}
}
$search=input("search");
if($search){
$data=Db::name('pay')->whereor("id", 'like', '%'.$search.'%')->whereor("name", 'like', '%'.$search.'%')->whereor("ordernumber", 'like', '%'.$search.'%')->whereor("pay", 'like', '%'.$search.'%')->whereor("money", 'like', '%'.$search.'%')->whereor("userid", 'like', '%'.$search.'%')->whereor("state", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('pay')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/pay",[
"pay"=>$data,
]);
}

public function transferrecord(){
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name('transferrecord')->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}


if($act=="qbdelete"){
$data12=Db::name("transferrecord")->select();
$a="0";
$b="0";
for($i=0;$i<count($data12);$i++){
$data1=Db::name('transferrecord')->where("id",$data12[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}
}
$search=input("search");
if($search){
$data=Db::name('transferrecord')->whereor("id", 'like', '%'.$search.'%')->whereor("userid", 'like', '%'.$search.'%')->whereor("record", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('transferrecord')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"].'/transferrecord',[
"data"=>$data,
]);
}

public function transaction(){
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name('transaction')->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}


if($act=="qbdelete"){
$data12=Db::name("transaction")->select();
$a="0";
$b="0";
for($i=0;$i<count($data12);$i++){
$data1=Db::name('transaction')->where("id",$data12[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}

}

$search=input("search");
if($search){
$data=Db::name('transaction')->whereor("id", 'like', '%'.$search.'%')->whereor("userid", 'like', '%'.$search.'%')->whereor("content", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('transaction')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"].'/transaction',[
"data"=>$data,
]);
}



public function pays($id=null){
if($id){
$data1=Db::name('pays')->where("id",$id)->find();
if($data1){
if(Request::instance()->isPost()) {
$input=input("post.");
if($input){
if(file_exists(PATH."/plugins/pay/".$data1["plugins"]."/set.php")){
$wj=include_once(PATH."/plugins/pay/".$data1["plugins"]."/set.php");
for($i=0;$i<count($wj);$i++){
foreach ($input as $key => $value){
if($wj[$i]["name"]==$key){
$wj[$i]["value"]=$value;
}
}
}
$sj=json_encode($wj);
}else{
$sj="";
}
$data=Db::name('pays')->where('id',$id)->update([
"name"=>$input["nname"],
"state"=>$input["nstate"],
"data"=>$sj,
]);
if($data){
$array["code"]="1";
$array["msg"]="修改成功!";
}else{
$array["code"]="-1";
$array["msg"]="修改失败!";
}
}else{
$array["code"]="-1";
$array["msg"]="没有数据!";
}
return $array;
}
$tyyy=@json_decode($data1["data"],true);
if($tyyy=="null"){
$tyyy="";
}
return $this->fetch('/'.$this->web["admintemplate"]."/payss",[
"nname"=>$data1["name"],
"nstate"=>$data1["state"],
"payss"=>$tyyy,
]);
}else{
$this->redirect(admin_url('/pays'));
}
}else{
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="add"){
$info=input("post.");
if($info["name"]=="" || !$info["plugins"]){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
unset($info["act"]);
if(file_exists(PATH."/plugins/pay/".$info["plugins"]."/set.php")){
$wj=include_once(PATH."/plugins/pay/".$info["plugins"]."/set.php");
$info["data"]=json_encode($wj);
}else{
$info["data"]="";
}
$data1=Db::name('pays')->insertGetId($info);
if($data1){
$array["code"]="1";
$array["msg"]="添加成功!";
}else{
$array["code"]="-1";
$array["msg"]="添加失败!";
}
}
return $array;
}





if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name("pays")->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已经删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}

if(input("act")=="qbdelete"){
$data11=Db::name("pays")->select();
$a="0";
$b="0";
for($i=0;$i<count($data11);$i++){
$data1=Db::name("pays")->where("id",$data11[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过此条通道了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}
}
$search=input("search");
if($search){
$data=Db::name('pays')->whereor("id", 'like', '%'.$search.'%')->whereor("name", 'like', '%'.$search.'%')->whereor("plugins", 'like', '%'.$search.'%')->whereor("state", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('pays')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/pays",[
"pays"=>$data,
"payss"=>my_dir(PATH."/plugins/pay"), 
]);
}
}


public function affsy(){
if(Request::instance()->isPost()) {
$act=input("act");
if($act=="delete"){
$cid=input("cid");
if($cid==""){
$array["code"]="-1";
$array["msg"]="必填参数不可为空!";
}else{
$cid=explode(",",input("cid"));
$a="0";
$b="0";
for($i=0;$i<count($cid);$i++){
$data1=Db::name("affsymoney")->where("id",$cid[$i])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已经删除过了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
}
return $array;
}

if(input("act")=="qbdelete"){
$data11=Db::name("affsymoney")->select();
$a="0";
$b="0";
for($i=0;$i<count($data11);$i++){
$data1=Db::name("affsymoney")->where("id",$data11[$i]["id"])->delete();
if($data1){
$a=$a+1;
}else{
$b=$b+1;
}
}
$c="";
if($b>0){
$c="<br/>失败原因:已删除过此条记录了!";
}
$array["code"]="1";
$array["msg"]="成功:".$a.";失败:".$b.$c;
return $array;
}

}
$search=input("search");
if($search){
$data=Db::name('affsymoney')->whereor("id", 'like', '%'.$search.'%')->whereor("information", 'like', '%'.$search.'%')->whereor("money", 'like', '%'.$search.'%')->whereor("userid", 'like', '%'.$search.'%')->order('id desc')->paginate(10,false,['query'=>request()->param()]);
}else{
$data=Db::name('affsymoney')->order('id desc')->paginate(10);
}
return $this->fetch('/'.$this->web["admintemplate"]."/affsy",[
"affsy"=>$data,
]);
}

//发送邮箱
		public static function email($email,$name,$body,$noTpl=false)
		{
$web=Db::name('web')->where('id',1)->find();
// 邮件模板优先：若 yun_email_tpl 中存在与主题匹配、且已启用的模板，则用模板内容发送（后台可编辑），动态内容通过 {内容} 占位符传入；禁用(enabled=0)则回退原始正文。$noTpl=true 时跳过模板套用（用于邮件群发，body 已是完整内容）
try {
	if($noTpl){ throw new \Exception('_skip_tpl'); }
	$tpl = \think\Db::name('email_tpl')->where('subject', $name)->find();
	// 仅当模板启用、且含 {内容} 占位符时才套用模板；否则回退原始正文，保证动态信息（如验证码）不丢失、发送始终正常
	if ($tpl && intval($tpl['enabled']) === 1 && !empty($tpl['content']) && strpos((string)$tpl['content'], '{内容}') !== false) {
		$body2 = str_replace(['{内容}','{标题}'], [$body, $name], (string)$tpl['content']);
		if (trim($body2) !== '') { $body = $body2; }
		if (!empty($tpl['subject'])) $name = $tpl['subject'];
	}
} catch (\Throwable $e) {}
try {
	$mail = new PHPMailer(); 
	$mail->IsSMTP();
	$mail->CharSet=$web["emailchar"]; //设置邮件的字符编码，这很重要，不然中文乱码
	$mail->SMTPAuth   = $web["emailauth"];       //开启认证
if($web["emailsecure"]){
    $mail->SMTPSecure = $web["emailsecure"];             // 允许 TLS 或者ssl协议
}
	$mail->Port       = $web["emailport"];                    
	$mail->Host       = $web["emailhost"]; 
	$mail->Username   = $web["emailname"];    
	$mail->Password   = $web["emailpass"];            
	$mail->From       = $web["emailname"];
	$mail->FromName   = $web["name"];
	$to = $email;
	$mail->AddAddress($to);
	$mail->Subject  = $name;
	$mail->Body = "<html><head><title>".$name."</title></head>".$body."</html>";
	$mail->WordWrap   = 80; // 设置每行字符串的长度
	$mail->IsHTML(true); 
	$mail->Send();
	$array["code"]="1";
	$array["msg"]="邮箱发送成功!";
return $array;
} catch (\Throwable $e) {
	$array["code"]="-1";
	$array["msg"]="邮箱发送失败:".(method_exists($e,'errorMessage')?$e->errorMessage():$e->getMessage());
return $array;
}
}

}
