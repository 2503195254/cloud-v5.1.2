<?php
function random($length = 8,$chars = null){
  if(empty($chars)){
    $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  }
  $count = strlen($chars) - 1;
  $code = '';
  while( strlen($code) < $length){
    $code .= substr($chars,rand(0,$count),1);
  }
  return $code;
}

function userrandom(){
	// 确保 yun_set 表存在（首次运行自动建表兜底）
	try {
		\think\Db::execute("CREATE TABLE IF NOT EXISTS `yun_set` (`id` INT(11) NOT NULL AUTO_INCREMENT,`k` VARCHAR(64) NOT NULL DEFAULT '',`v` VARCHAR(500) NOT NULL DEFAULT '',PRIMARY KEY (`id`),UNIQUE KEY `k` (`k`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
	} catch (\Throwable $e) {}
	// 读取账号生成配置
	$prefix = 'a'; $len = 7; $digit = 1; $letter = 0;
	try {
		$rows = \think\Db::name('set')->select();
		foreach ($rows as $r) {
			$k = $r['k']; $v = (string)$r['v'];
			if ($k === 'account_prefix') $prefix = trim($v);
			elseif ($k === 'account_len') $len = max(1, intval($v));
			elseif ($k === 'account_use_digit') $digit = trim($v);
			elseif ($k === 'account_use_letter') $letter = trim($v);
		}
	} catch (\Throwable $e) {}
	// 字符池：按是否含英文/数字组装
	$chars = '';
	if ($letter === '1') $chars .= 'abcdefghijklmnopqrstuvwxyz';
	if ($digit === '1') $chars .= '0123456789';
	if ($chars === '') $chars = '0123456789'; // 兜底纯数字
	$account = $prefix;
	$need = $len - strlen($prefix);
	if ($need < 1) $need = 1;
	$account .= random($need, $chars);
	return $account;
}

//获取目录下的子目录
function my_dir($dir) {
    $files = array();
    if(@$handle = opendir($dir)) { //注意这里要加一个@，不然会有warning错误提示：）
        while(($file = readdir($handle)) !== false) {
            if($file != ".." && $file != ".") { //排除根目录；
               $files[] = $file; 
            }
        }
        closedir($handle);
        return $files;
    }
}

function generateRand($m, $n)
{
    if ($m > $n) {
        $numMax = $m;
        $numMin = $n;
    } else {
        $numMax = $n;
        $numMin = $m;
    }
    /**
     * 生成$numMin和$numMax之间的随机浮点数，保留2位小数
     */
    $rand = $numMin + mt_rand() / mt_getrandmax() * ($numMax - $numMin);
    return floatval(number_format($rand,2));
}

//判断是否是HTTPS
function isHTTPS()
{
    if (defined('HTTPS') && HTTPS) return true;
    if (!isset($_SERVER)) return FALSE;
    if (!isset($_SERVER['HTTPS'])) return FALSE;
    if ($_SERVER['HTTPS'] === 1) {  //Apache
        return TRUE;
    } elseif ($_SERVER['HTTPS'] === 'on') { //IIS
        return TRUE;
    } elseif ($_SERVER['SERVER_PORT'] == 443) { //其他
        return TRUE;
    }
    return FALSE;
}


function judge($a,$b){
    if(in_array($b,$a)){
     return "1";
    }else{
return "2";
}
}

function getLen($num)
{
         $arr = explode('.',$num);
     $str=array_pop($arr);
if($str==$num){
$len="0";
}else{
     $len=strlen($str);
}
         return $len;
}

/* ========= 后台访问地址配置（动态后台地址） ========= */
/**
 * 获取后台访问路径（如 admin / mypanel）
 * 使用纯文本文件存储，避免 OPcache 缓存导致修改后无法即时生效
 */
function admin_path(){
    $file = PATH . 'app/admin_path.txt';
    if (file_exists($file)) {
        $p = @file_get_contents($file);
        $p = trim((string)$p);
        if ($p !== '' && preg_match('/^[a-zA-Z0-9_]+$/', $p)) {
            return $p;
        }
    }
    return 'admin';
}
/**
 * 拼接后台完整地址：admin_url('/index') => /后台路径/index
 */
function admin_url($suffix = ''){
    $path = admin_path();
    $suffix = ltrim((string)$suffix, '/');
    return '/' . $path . ($suffix !== '' ? '/' . $suffix : '');
}
/**
 * 写入后台访问路径配置（修改后旧地址立即失效）
 */
function admin_save_path($newPath){
    $newPath = strtolower(trim((string)$newPath));
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $newPath)) {
        return false; // 非法格式
    }
    // 保留字：与前台路由冲突的路径禁止使用（admin 是默认后台路径，允许改回）
    $reserved = ['index','login','register','user','sq','cart','product','announcement','cron','pwreset','aff','/','__rewrite__'];
    if (in_array($newPath, $reserved, true)) {
        return false;
    }
    $file = PATH . 'app/admin_path.txt';
    $ok = @file_put_contents($file, $newPath);
    return $ok !== false;
}

/* ============================================================
 * 系统级授权（内嵌于主系统，一打开即检测，不依赖插件）
 * ============================================================ */

/** 系统版本（用于系统信息页展示） */
function vhss_version(){ return 'V5.1.2'; }
/** 系统名称/信息 */
function vhss_product(){ return '云服务销售系统'; }
/** 授权端固定地址（用户不可修改） */
function vhss_lic_server(){ return 'https://idc.pantd.com/license_api'; }

/** 读取本系统授权码（存于私有文件，后台“去授权”写入，前端无法修改） */
function vhss_lic_key(){
    $f = PATH . 'app/license_key.txt';
    if (file_exists($f)) { return trim((string)@file_get_contents($f)); }
    return '';
}
/** 写入本系统授权码 */
function vhss_lic_save_key($code){
    $f = PATH . 'app/license_key.txt';
    return @file_put_contents($f, strtoupper(trim($code))) !== false;
}

/**
 * 本系统授权检测（内嵌，不依赖授权插件）。
 * 向固定授权端 https://idc.pantd.com/license_api 验证本系统授权码+当前域名。
 * @return array ['code'=>1已授权/0未授权,'msg','domain','edition'=>等级/版本]
 */
function vhss_system_license(){
    $domain = '';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $host = preg_replace('/:\d+$/', '', $host);
    $domain = strtolower(trim($host));
    $code = vhss_lic_key();
    if ($code === '') {
        return ['code' => 0, 'msg' => '系统未授权，请前往后台【系统信息】输入授权码', 'domain' => $domain];
    }
    $server = vhss_lic_server();
    $url = $server . '/verify?code=' . urlencode($code) . '&domain=' . urlencode($domain);
    $resp = false;
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
    }
    if ($resp === false || $resp === '') $resp = @file_get_contents($url);
    $json = json_decode($resp, true);
    if (!is_array($json)) {
        return ['code' => 0, 'msg' => '授权验证失败：无法连接授权服务器(' . $server . ')', 'domain' => $domain];
    }
    if (isset($json['code']) && $json['code'] == 1) {
        // 读取授权等级/版本
        $edition = '';
        $data = $json['data'] ?? null;
        if (is_array($data) && isset($data['product'])) $edition = $data['product'];
        return ['code' => 1, 'msg' => ($json['msg'] ?? '已授权'), 'domain' => $domain, 'edition' => $edition];
    }
    return ['code' => 0, 'msg' => ($json['msg'] ?? '未授权'), 'domain' => $domain];
}