<?php
/**
 * 云服务销售系统 - API 上游对接（服务器插件，标识：api）
 * ----------------------------------------------------------------
 * 以「服务器插件」身份嵌入系统核心产品开通/管理流程：
 *   - 商品(yun_cart) 的 serverid 指向「API上游」服务器(serverplugins=api)
 *   - 购买 -> 系统调用 api_CreateAccount() -> 转发上游API开通
 *   - 前台 -> api_ClientArea() 展示上游面板/账号/密码
 *   - 后台 -> api_OrderConfigOptions() 展示上游订单ID等扩展信息
 *   - 暂停/解除/终止/续费 -> api_* 函数转发上游
 * 上游协议与 plugins/api/api/api.php 中 api_upstream_* 保持一致。
 */
use think\Db;

/* 后台服务器配置项 */
function api_ConfigOptions()
{
    return [
        ["name"=>"data1",'title'=>'上游API标识', 'type'=>'input',"prompt"=>"本记录用于识别API上游对接","value"=>'api'],
    ];
}

/* 后台订单详情扩展字段展示 */
function api_OrderConfigOptions()
{
    return [
        ["name"=>"data1",'title'=>'服务订单号', 'type'=>'input',"prompt"=>"对方系统返回的订单号","value"=>''],
        ["name"=>"data2",'title'=>'对方产品ID', 'type'=>'input',"prompt"=>"对方商品ID","value"=>''],
        ["name"=>"data3",'title'=>'到期时间', 'type'=>'input',"prompt"=>"到期时间戳","value"=>''],
        ["name"=>"data4",'title'=>'运行状态', 'type'=>'input',"prompt"=>"产品状态(1正常/2暂停/3终止)","value"=>''],
        ["name"=>"data5",'title'=>'控制面板地址', 'type'=>'input',"prompt"=>"对方返回的面板访问地址","value"=>''],
        ["name"=>"data6",'title'=>'账号', 'type'=>'input',"prompt"=>"对方返回的账号","value"=>''],
        ["name"=>"data7",'title'=>'密码', 'type'=>'input',"prompt"=>"对方返回的密码","value"=>''],
        ["name"=>"data8",'title'=>'备注', 'type'=>'textarea',"prompt"=>"对方返回的备注/错误信息","value"=>''],
        ["name"=>"data9",'title'=>'扣款金额(元)', 'type'=>'input',"prompt"=>"本订单实时扣款金额","value"=>''],
        ["name"=>"data11",'title'=>'授权码', 'type'=>'input',"prompt"=>"授权类产品的授权码/序列号","value"=>''],
        ["name"=>"data12",'title'=>'完整信息快照', 'type'=>'textarea',"prompt"=>"对方返回的完整产品信息(JSON)，含全部扩展字段","value"=>''],
    ];
}

/* 读取上游插件配置 */
function api_upstream_cfg()
{
    api_api_ensure_tables();
    $cfg = [];
    try {
        $row = Db::name('plugin')->where('code','api')->find();
        $cfg = $row ? (json_decode($row['config'], true) ?: []) : [];
    } catch (\Throwable $e) {}
    return $cfg;
}

/* 确保 API 对接相关表存在（host 插件被独立加载时也能用） */
function api_api_ensure_tables()
{
    try {
        Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_map` (`id` INT(11) NOT NULL AUTO_INCREMENT,`up_id` VARCHAR(64) NOT NULL DEFAULT '',`cartid` INT(11) NOT NULL DEFAULT '0',`cycle` VARCHAR(50) NOT NULL DEFAULT 'month',`status` TINYINT(1) NOT NULL DEFAULT '1',`remark` VARCHAR(255) NOT NULL DEFAULT '',`create_time` INT(11) NOT NULL DEFAULT '0',PRIMARY KEY (`id`),KEY `up_id` (`up_id`),KEY `cartid` (`cartid`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        Db::execute("CREATE TABLE IF NOT EXISTS `yun_api_log` (`id` INT(11) NOT NULL AUTO_INCREMENT,`type` VARCHAR(40) NOT NULL DEFAULT '',`content` TEXT,`create_time` INT(11) NOT NULL DEFAULT '0',PRIMARY KEY (`id`),KEY `type` (`type`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
    } catch (\Throwable $e) {}
}

/* 按本地商品id取已启用映射 */
function api_map_for_cart($cartid)
{
    api_api_ensure_tables();
    try {
        $row = Db::name('api_map')->where('cartid', intval($cartid))->where('status', 1)->find();
        return $row ?: null;
    } catch (\Throwable $e) { return null; }
}

/* 记录操作日志 */
function api_write_log($type, $content)
{
    try {
        Db::name('api_log')->insert([
            'type' => $type,
            'content' => mb_substr((string)$content, 0, 1500),
            'create_time' => time(),
        ]);
    } catch (\Throwable $e) {}
}

/* 调用上游API统一入口（HTTP+签名+超时） */
function api_upstream_request($action, $params = [], $timeout = 0)
{
    $cfg = api_upstream_cfg();
    if (empty($cfg['upstream_enable']) || $cfg['upstream_enable'] === '0') {
        return ['code'=>-1, 'msg'=>'上游对接总开关未开启'];
    }
    $base = rtrim(trim($cfg['upstream_url'] ?? ''), '/');
    if ($base === '' || strpos($base, 'http') !== 0) {
        return ['code'=>-1, 'msg'=>'请先配置上游API地址'];
    }
    $key    = trim($cfg['upstream_appid'] ?? '');
    $secret = trim($cfg['upstream_appkey'] ?? '');
    if ($key === '') {
        return ['code'=>-1, 'msg'=>'未填写“上游AppID”：请先在对方(上游)系统用户中心自助开通专属API并填写其 AppID'];
    }
    if ($secret === '') {
        return ['code'=>-1, 'msg'=>'未填写“上游AppKey”：请填写在对方系统自助开通的 AppKey'];
    }
    $to     = $timeout > 0 ? $timeout : max(10, intval($cfg['api_timeout'] ?? 15));
    // 凭据：appid + appkey（对应对方系统「自助开通」的专属钥匙）
    $auth = ['appid'=>$key, 'appkey'=>$secret];
    $params = array_merge($params, $auth);
    $url = $base . ($action !== '' ? '/' . $action : '') . '?' . http_build_query($auth);
    $resp = '';
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($params),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => $to,
            CURLOPT_TIMEOUT => $to,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => ['X-Api-Appid: ' . $key, 'X-Api-Key: ' . $secret, 'Content-Type: application/x-www-form-urlencoded'],
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
    }
    if ($resp === false || $resp === '') {
        $resp = @file_get_contents($url, false, stream_context_create([
            'http' => ['method'=>'POST','header'=>"X-Api-Appid: $key\r\nX-Api-Key: $secret\r\nContent-Type: application/x-www-form-urlencoded",'content'=>http_build_query($params),'timeout'=>$to]
        ]));
    }
    $json = json_decode($resp, true);
    if (!is_array($json)) {
        return ['code'=>-1, 'msg'=>'上游响应解析失败', 'raw'=>mb_substr((string)$resp,0,500)];
    }
    return $json;
}

/**
 * 开通（购买时系统自动调用 / 后台手动触发）
 * @param array $server  yun_server 记录
 * @param array $buy    用户提交的购买参数(user/password/time)
 * @param array $cart   商品 yun_cart 记录
 * @param int   $times  购买时长(秒)
 * @return array
 */
function api_CreateAccount($server, $buy, $cart, $times)
{
    $map = api_map_for_cart($cart['id']);
    if (!$map) {
        return ['code'=>-1, 'msg'=>'该商品未配置上游API商品映射，无法转发开通'];
    }
    $cycle = trim($map['cycle'] ?? ($cart['cycle'] ?? 'month'));
    $num   = max(1, intval($buy['time'] ?? 1));
    $cfg   = api_upstream_cfg();
    $auto  = (isset($cfg['order_auto']) && $cfg['order_auto'] === '0') ? 0 : 1; // 默认自动开通
    // 自动开通关闭：仅建单标记待人工，不转发
    if (!$auto) {
        $orderId = 0;
        try {
            $orderId = Db::name('order')->insertGetId([
                'user'=>$buy['user'], 'password'=>$buy['password'], 'userid'=>session('userid'),
                'cartid'=>$cart['id'], 'atime'=>time(), 'ztime'=>time()+$times, 'state'=>'1',
                'data1'=>'PENDING', 'data2'=>$map['up_id'], 'data3'=>$cycle, 'data4'=>'0',
            ]);
        } catch (\Throwable $e) {}
        api_write_log('create', '手动模式：订单已建待人工开通。本地cart='.$cart['id'].' 上游商品='.$map['up_id']);
        return ['code'=>1, 'msg'=>'订单已创建（手动开通模式，请到后台提交上游开通）', 'id'=>$orderId, 'pending'=>true];
    }
    // 自动开通：转发上游
    $params = [
        'up_id'   => $map['up_id'],
        'cycle'   => $cycle,
        'num'     => $num,
        'user'    => trim($buy['user'] ?? ''),
        'password'=> trim($buy['password'] ?? ''),
        'cartid'  => intval($cart['id']),
    ];
    $ret = api_upstream_request('create', $params);
    if (!isset($ret['code']) || $ret['code'] != 1) {
        api_write_log('create', '转发开通失败：'.($ret['msg'] ?? '未知错误').' 本地cart='.$cart['id']);
        $orderId = 0;
        try {
            $orderId = Db::name('order')->insertGetId([
                'user'=>$buy['user'], 'password'=>$buy['password'], 'userid'=>session('userid'),
                'cartid'=>$cart['id'], 'atime'=>time(), 'ztime'=>time()+$times, 'state'=>'1',
                'data1'=>'ERR', 'data2'=>$map['up_id'], 'data3'=>$cycle, 'data4'=>'0',
                'data8'=>mb_substr(($ret['msg'] ?? '转发失败'),0,200),
            ]);
        } catch (\Throwable $e) {}
        return ['code'=>-1, 'msg'=>'上游开通失败：'.($ret['msg'] ?? '未知错误'), 'id'=>$orderId, 'abnormal'=>true];
    }
    $d = $ret['data'] ?? [];
    // 通用化：全量接收上游返回的完整信息快照，写入本地订单
    $upState = (string)($d['state'] ?? '1');
    $localState = '1';
    if ($upState === '2') $localState = '2';
    elseif ($upState === '3' || $upState === '0') $localState = '3';
    // data12 存档上游完整快照(JSON)，以备任何插件信息不丢失
    $snapshot = json_encode($d, JSON_UNESCAPED_UNICODE);
    $licenseCode = trim($d['license_code'] ?? '');
    $orderId = 0;
    try {
        $orderId = Db::name('order')->insertGetId([
            'user'=>($d['username'] ?? $buy['user']), 'password'=>($d['password'] ?? $buy['password']),
            'userid'=>session('userid'), 'cartid'=>$cart['id'],
            'atime'=>time(), 'ztime'=>($d['expire_time'] ? intval($d['expire_time']) : (time()+$times)), 'state'=>$localState,
            'data1'=>$d['up_order_id'] ?? '', 'data2'=>$map['up_id'], 'data3'=>($d['expire_time'] ?? 0),
            'data4'=>$upState, 'data5'=>$d['panel_url'] ?? '', 'data6'=>$d['username'] ?? $buy['user'],
            'data7'=>$d['password'] ?? $buy['password'], 'data8'=>($d['remark'] ?? ''),
            'data9'=>($d['deduct'] ?? '0'), 'data10'=>time(), 'data11'=>$licenseCode,
            'data12'=>$snapshot,
        ]);
        api_write_log('create', '开通成功：本地订单#'.$orderId.' 上游订单='.($d['up_order_id'] ?? '').' 授权码='.(($licenseCode!=='')?$licenseCode:'-'));
    } catch (\Throwable $e) {
        api_write_log('create', '订单写入异常：'.$e->getMessage());
    }
    return ['code'=>1, 'msg'=>'开通成功', 'id'=>$orderId, 'up_order_id'=>($d['up_order_id'] ?? '')];
}

/* 前台控制面板展示（每次打开实时向上游同步状态与面板，去「上游」字样） */
function api_ClientArea($server, $cart, $order)
{
    // 实时同步：若订单已有有效服务订单号，则向上游请求最新状态并回写本地
    $upOrderId = trim($order['data1'] ?? '');
    if ($upOrderId !== '' && $upOrderId !== 'PENDING' && $upOrderId !== 'ERR') {
        $sync = api_sync_order_status($order, $server, $cart);
        if (isset($sync['code']) && $sync['code'] === 1) {
            // 回写成功，重新读取最新订单数据
            try {
                $fresh = Db::name('order')->where('id', $order['id'])->find();
                if ($fresh) $order = $fresh;
            } catch (\Throwable $e) {}
        }
    }

    $panel = trim($order['data5'] ?? '');
    $user  = trim($order['data6'] ?? $order['user'] ?? '');
    $pass  = trim($order['data7'] ?? $order['password'] ?? '');
    $upOrderId = trim($order['data1'] ?? '');
    $remark = trim($order['data8'] ?? '');
    $upState = trim($order['data4'] ?? '');
    $expire = intval($order['ztime'] ?? 0);
    $stateText = ($upState === '2') ? '已暂停' : (($upState === '3') ? '已终止' : '运行中');
    // 授权码 + 附加信息（通用：从快照 data12 解析上游返回的所有额外字段）
    $licenseCode = trim($order['data11'] ?? '');
    $extra = [];
    try {
        $snap = json_decode((string)($order['data12'] ?? ''), true);
        if (is_array($snap)) $extra = $snap;
    } catch (\Throwable $e) {}
    // 附加信息里可能没在语义字段中的（如授权等级、序列号等），收集成键值对展示
    $extraRows = [];
    foreach ([
        'product_name' => '产品名称', 'cycle' => '计费周期', 'deduct' => '本次扣款(元)',
        'panel_url' => '控制面板', 'username' => '账号', 'password' => '密码',
    ] as $ek => $el) {
        if (isset($extra[$ek]) && (string)$extra[$ek] !== '' && !in_array($ek, ['panel_url','username','password','product_name','cycle']) ) {
            $extraRows[$el] = $extra[$ek];
        }
    }
    // 若快照里含 data 扩展字段（data1~data20 可能有插件写入的自定义信息），原样展示其中非空且非语义的
    foreach ($extra as $ek => $ev) {
        if (is_string($ek) && strpos($ek, 'data') === 0 && preg_match('/^data\d+$/', $ek) && (string)$ev !== '') {
            // 跳过已在语义字段表达的 data3~data7 等，只显示 data12+ 及未映射的自定义项
            if (!in_array($ek, ['data1','data2','data3','data4','data5','data6','data7','data8','data9','data10','data11','data12','data13'])) {
                $extraRows[$ek] = $ev;
            }
        }
    }

    $html = '<div style="background:#f7f9fc;border:1px solid #eef2f7;border-radius:10px;padding:16px;font-size:14px;line-height:2;">';
    $html .= '<div style="font-weight:600;color:#1f2d3d;margin-bottom:8px;"><i class="fas fa-cloud" style="color:#0052D9;margin-right:6px;"></i>服务管理信息</div>';
    if ($licenseCode !== '') {
        $html .= '<div style="background:#EAF3FF;border:1px solid #BBD8FF;border-radius:8px;padding:10px 12px;margin-bottom:10px;">'
               . '<i class="fas fa-key" style="color:#0052D9;margin-right:6px;"></i><b style="color:#0052D9;">授权码：</b>'
               . '<span style="font-family:monospace;font-size:15px;font-weight:700;color:#0B4E9E;word-break:break-all;user-select:all;">'.htmlspecialchars($licenseCode).'</span>'
               . '<div style="font-size:12px;color:#5A6A85;margin-top:4px;">请妥善保存此授权码，用于软件/服务激活。</div></div>';
    }
    if ($panel !== '') {
        $html .= '<div style="margin-bottom:6px;"><i class="fas fa-external-link-alt" style="color:#0052D9;margin-right:6px;"></i>控制面板：<a href="'.htmlspecialchars($panel).'" target="_blank" rel="noopener" style="color:#0052D9;font-weight:600;">'.htmlspecialchars($panel).'</a></div>';
    }
    if ($user !== '') { $html .= '<div><i class="fas fa-user" style="color:#0052D9;margin-right:6px;"></i>管理账号：<b style="color:#0052D9;">'.htmlspecialchars($user).'</b></div>'; }
    if ($pass !== '') { $html .= '<div><i class="fas fa-key" style="color:#0052D9;margin-right:6px;"></i>服务密码：<b style="color:#0052D9;">'.htmlspecialchars($pass).'</b></div>'; }
    if ($upOrderId !== '' && $upOrderId !== 'PENDING' && $upOrderId !== 'ERR') {
        $html .= '<div><i class="fas fa-hashtag" style="color:#0052D9;margin-right:6px;"></i>服务订单号：'.htmlspecialchars($upOrderId).'</div>';
    }
    if ($upState !== '') { $html .= '<div><i class="fas fa-signal" style="color:#0052D9;margin-right:6px;"></i>服务状态：<b style="color:'.($upState=='2'?'#e67e22':($upState=='3'?'#c0392b':'#27ae60')).';">'.$stateText.'</b></div>'; }
    if ($expire > 0) { $html .= '<div><i class="fas fa-calendar-alt" style="color:#0052D9;margin-right:6px;"></i>到期时间：<b style="color:#0052D9;">'.date('Y-m-d H:i', $expire).'</b></div>'; }
    if (!empty($extraRows)) {
        $html .= '<div style="border-top:1px dashed #D8E2EE;margin-top:10px;padding-top:10px;">';
        $html .= '<div style="font-size:12px;color:#8A96A8;margin-bottom:4px;">产品附加信息</div>';
        foreach ($extraRows as $k => $v) {
            $html .= '<div style="color:#3A4A5F;"><b>'.htmlspecialchars((string)$k).'：</b>'.htmlspecialchars((string)$v).'</div>';
        }
        $html .= '</div>';
    }
    if ($remark !== '') { $html .= '<div style="color:#c0392b;"><i class="fas fa-info-circle" style="margin-right:6px;"></i>备注：'.htmlspecialchars($remark).'</div>'; }
    if ($upOrderId === 'PENDING') { $html .= '<div style="color:#e67e22;">该服务等待人工开通处理。</div>'; }
    if ($upOrderId === 'ERR') { $html .= '<div style="color:#c0392b;">该服务开通异常，请前往后台处理。</div>'; }
    $html .= '</div>';
    return $html;
}

/* 后台手动触发开通（重发） */
function api_resend_order($order, $server, $cart)
{
    $map = api_map_for_cart($cart['id']);
    if (!$map) return ['code'=>-1, 'msg'=>'该商品未配置上游API商品映射'];
    $params = [
        'up_id'   => $map['up_id'],
        'cycle'   => trim($order['data3'] ?? ($cart['cycle'] ?? 'month')),
        'num'     => 1,
        'user'    => trim($order['user'] ?? ''),
        'password'=> trim($order['password'] ?? ''),
        'cartid'  => intval($cart['id']),
    ];
    $ret = api_upstream_request('create', $params);
    if (!isset($ret['code']) || $ret['code'] != 1) {
        api_write_log('resend', '手动开通失败：#'.$order['id'].' '.($ret['msg'] ?? '未知错误'));
        return ['code'=>-1, 'msg'=>'开通失败：'.($ret['msg'] ?? '未知错误')];
    }
    $d = $ret['data'] ?? [];
    Db::name('order')->where('id',$order['id'])->update([
        'user'=>($d['username'] ?? $order['user']),
        'password'=>($d['password'] ?? $order['password']),
        'state'=>'1',
        'data1'=>$d['up_order_id'] ?? '', 'data2'=>$map['up_id'], 'data3'=>($d['expire_time'] ?? $order['ztime']),
        'data4'=>'1', 'data5'=>$d['panel_url'] ?? '', 'data6'=>$d['username'] ?? $order['user'],
        'data7'=>$d['password'] ?? $order['password'], 'data8'=>($d['remark'] ?? ''),
        'data9'=>($d['deduct'] ?? '0'), 'data11'=>($d['license_code'] ?? ''),
        'data12'=>json_encode($d, JSON_UNESCAPED_UNICODE),
    ]);
    api_write_log('resend', '手动开通成功：#'.$order['id'].' 上游订单='.($d['up_order_id'] ?? '').' 授权码='.((trim($d['license_code']??'')!=='')?$d['license_code']:'-'));
    return ['code'=>1, 'msg'=>'开通成功', 'up_order_id'=>($d['up_order_id'] ?? '')];
}

/* 同步上游状态回写本地订单 */
function api_sync_order_status($order, $server, $cart)
{
    $upOrderId = trim($order['data1'] ?? '');
    if ($upOrderId === '' || $upOrderId === 'PENDING' || $upOrderId === 'ERR') {
        return ['code'=>-1, 'msg'=>'该订单尚无上游订单ID，请先提交上游开通'];
    }
    $ret = api_upstream_request('status', ['up_order_id'=>$upOrderId]);
    if (!isset($ret['code']) || $ret['code'] != 1) {
        api_write_log('status', '同步状态失败：#'.$order['id'].' '.($ret['msg'] ?? '未知错误'));
        return ['code'=>-1, 'msg'=>'同步失败：'.($ret['msg'] ?? '未知错误')];
    }
    $d = $ret['data'] ?? [];
    $upState = isset($d['state']) ? (string)$d['state'] : '';
    $upExpire = isset($d['expire_time']) ? intval($d['expire_time']) : 0;
    $localState = '1';
    if ($upState === '2') $localState = '2';
    elseif ($upState === '3' || $upState === '0') $localState = '3';
    $update = [
        'state'=>$localState,
        'data4'=>$upState,
        'data3'=>$upExpire ? $upExpire : $order['data3'],
    ];
    if (!empty($d['panel_url'])) $update['data5'] = $d['panel_url'];
    if (!empty($d['username']))  $update['data6'] = $d['username'];
    if (!empty($d['password']))  $update['data7'] = $d['password'];
    if (!empty($d['remark']))    $update['data8'] = $d['remark'];
    if (isset($d['license_code']) && $d['license_code'] !== '') $update['data11'] = $d['license_code'];
    if (isset($d['deduct']) && $d['deduct'] !== '') $update['data9'] = $d['deduct'];
    if (is_array($d)) $update['data12'] = json_encode($d, JSON_UNESCAPED_UNICODE);
    if ($upExpire) $update['ztime'] = $upExpire;
    Db::name('order')->where('id',$order['id'])->update($update);
    api_write_log('status', '同步状态成功：#'.$order['id'].' 上游状态='.$upState.' 到期='.($upExpire?date('Y-m-d',$upExpire):'-'));
    return ['code'=>1, 'msg'=>'同步成功', 'state'=>$upState, 'expire_time'=>$upExpire];
}

/* 暂停 */
function api_SuspendAccount($server, $order, $cart)
{
    $upOrderId = trim($order['data1'] ?? '');
    if ($upOrderId === '' || $upOrderId === 'PENDING' || $upOrderId === 'ERR') {
        Db::name('order')->where('id',$order['id'])->update(['state'=>'2','data4'=>'2']);
        return ['code'=>1, 'msg'=>'已本地暂停（无上游订单）'];
    }
    $ret = api_upstream_request('suspend', ['up_order_id'=>$upOrderId]);
    if (!isset($ret['code']) || $ret['code'] != 1) {
        return ['code'=>-1, 'msg'=>'暂停失败：'.($ret['msg'] ?? '未知错误')];
    }
    Db::name('order')->where('id',$order['id'])->update(['state'=>'2','data4'=>'2']);
    api_write_log('suspend', '暂停成功：#'.$order['id'].' 上游订单='.$upOrderId);
    return ['code'=>1, 'msg'=>'暂停成功'];
}

/* 解除暂停 */
function api_UnsuspendAccount($server, $order, $cart)
{
    $upOrderId = trim($order['data1'] ?? '');
    if ($upOrderId === '' || $upOrderId === 'PENDING' || $upOrderId === 'ERR') {
        Db::name('order')->where('id',$order['id'])->update(['state'=>'1','data4'=>'1']);
        return ['code'=>1, 'msg'=>'已本地解除暂停（无上游订单）'];
    }
    $ret = api_upstream_request('unsuspend', ['up_order_id'=>$upOrderId]);
    if (!isset($ret['code']) || $ret['code'] != 1) {
        return ['code'=>-1, 'msg'=>'解除暂停失败：'.($ret['msg'] ?? '未知错误')];
    }
    Db::name('order')->where('id',$order['id'])->update(['state'=>'1','data4'=>'1']);
    api_write_log('unsuspend', '解除暂停成功：#'.$order['id']);
    return ['code'=>1, 'msg'=>'解除暂停成功'];
}

/* 终止 */
function api_TerminateAccount($server, $order, $cart)
{
    $upOrderId = trim($order['data1'] ?? '');
    if ($upOrderId !== '' && $upOrderId !== 'PENDING' && $upOrderId !== 'ERR') {
        $ret = api_upstream_request('terminate', ['up_order_id'=>$upOrderId]);
        if (!isset($ret['code']) || $ret['code'] != 1) {
            return ['code'=>-1, 'msg'=>'终止失败：'.($ret['msg'] ?? '未知错误')];
        }
        api_write_log('terminate', '终止成功：#'.$order['id'].' 上游订单='.$upOrderId);
    } else {
        api_write_log('terminate', '本地终止（无上游订单）：#'.$order['id']);
    }
    Db::name('order')->where('id',$order['id'])->update(['state'=>'3','data4'=>'3']);
    return ['code'=>1, 'msg'=>'终止成功'];
}

/* 续费（转发上游，上游支持则生效） */
function api_renew($server, $order, $cart, $times, $time)
{
    $upOrderId = trim($order['data1'] ?? '');
    if ($upOrderId === '' || $upOrderId === 'PENDING' || $upOrderId === 'ERR') {
        return ['code'=>-1, 'msg'=>'尚无上游订单，无法续费'];
    }
    $ret = api_upstream_request('renew', ['up_order_id'=>$upOrderId, 'num'=>max(1,intval($time))]);
    if (!isset($ret['code']) || $ret['code'] != 1) {
        return ['code'=>-1, 'msg'=>'上游续费失败：'.($ret['msg'] ?? '未知错误')];
    }
    $d = $ret['data'] ?? [];
    if (!empty($d['expire_time'])) {
        Db::name('order')->where('id',$order['id'])->update(['ztime'=>intval($d['expire_time']), 'data3'=>intval($d['expire_time'])]);
    }
    api_write_log('renew', '续费成功：#'.$order['id'].' 上游订单='.$upOrderId);
    return ['code'=>1, 'msg'=>'续费成功'];
}

/* 升级（上游支持则生效，否则本地改配） */
function api_upgrade($server, $order, $cart, $newcart)
{
    $upOrderId = trim($order['data1'] ?? '');
    if ($upOrderId === '' || $upOrderId === 'PENDING' || $upOrderId === 'ERR') {
        return ['code'=>-1, 'msg'=>'尚无上游订单，无法升级'];
    }
    $map = api_map_for_cart($newcart['id']);
    if (!$map) return ['code'=>-1, 'msg'=>'目标商品未配置上游API商品映射'];
    $ret = api_upstream_request('upgrade', ['up_order_id'=>$upOrderId, 'up_id'=>$map['up_id']]);
    if (!isset($ret['code']) || $ret['code'] != 1) {
        return ['code'=>-1, 'msg'=>'上游升级失败：'.($ret['msg'] ?? '未知错误')];
    }
    Db::name('order')->where('id',$order['id'])->update(['data2'=>$map['up_id']]);
    api_write_log('upgrade', '升级成功：#'.$order['id'].' 迁移至上游商品='.$map['up_id']);
    return ['code'=>1, 'msg'=>'升级成功'];
}