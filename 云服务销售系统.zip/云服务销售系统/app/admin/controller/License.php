<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;
use think\Request;

/**
 * 授权插件：后台授权管理
 * 入口：/admin/license  （授权列表/添加/编辑/删除/绑定域名/附件）
 */
class License extends Controller
{
    protected $root;

    public function _initialize()
    {
        if (!session("adminid")) {
            $this->redirect(admin_url('/login'));
        }
        $this->user = Db::name('admin')->where('id', session("adminid"))->find();
        $this->web  = Db::name('web')->where('id', 1)->find();
        $this->root = PATH;
        // 与其它后台控制器保持一致：分配后台公共模板变量（否则 header.html 里 webname/admin_path/user 会渲染为空）
        $this->assign([
            'webname'    => isset($this->web['name']) ? $this->web['name'] : '',
            'user'       => $this->user,
            'admin_path' => admin_path(),
        ]);
        // 授权插件是否启用（仅启用后后台菜单才出现）
        $licOn = 0;
        try { $licRow = Db::name('plugin')->where('code', 'license')->find(); if ($licRow && (int)$licRow['status'] == 1) $licOn = 1; } catch (\Throwable $e) {}
        $this->assign('plug_license', $licOn);
        // 内嵌系统授权（供后台横幅显示）
        $sysLic = function_exists('vhss_system_license') ? vhss_system_license() : ['code'=>-1,'msg'=>'','domain'=>'','edition'=>''];
        $this->assign('sys_lic', $sysLic);
        $this->assign('sys_lic_msg', $sysLic['msg'] ?? '');
        $this->assign('sys_lic_domain', $sysLic['domain'] ?? '');
    }

    /** 加载授权插件函数（仅插件已启用才加载并返回 true） */
    protected function loadPlug()
    {
        $entry = $this->root . 'plugins/license/license/license.php';
        $installed = 0;
        try {
            $licRow = Db::name('plugin')->where('code', 'license')->find();
            if ($licRow && (int)$licRow['status'] == 1) $installed = 1;
        } catch (\Throwable $e) {}
        if (!is_file($entry) || !$installed) {
            $this->assign('plug_installed', 0);
            return false;
        }
        include_once $entry;
        $this->assign('plug_installed', 1);
        return true;
    }

    /** 授权列表 */
    public function index()
    {
        $this->loadPlug();
        $kw = trim(input('kw'));
        $list = [];
        try {
            $q = Db::name('license')->order('id desc');
            if ($kw !== '') $q = $q->where('code|product|uname', 'like', "%$kw%");
            $list = $q->paginate(10);
            if (function_exists('license_attach_list')) {
                foreach ($list as &$r) {
                    if (function_exists('license_domains')) $r['domains_arr'] = license_domains($r['domains']);
                    else $r['domains_arr'] = [];
                }
            }
        } catch (\Throwable $e) { $list = []; }
        return $this->fetch(APP_PATH . 'admin/view/' . ($this->web['admintemplate']??'default') . '/license.html', [
            'list' => $list, 'kw' => $kw, 'admin_path' => admin_path(),
        ]);
    }

    /** 添加/编辑授权（表单页） */
    public function edit()
    {
        if (!$this->loadPlug()) return $this->fetch(APP_PATH . 'admin/view/' . ($this->web['admintemplate']??'default') . '/license_edit.html', ['row'=>[],'act'=>'add','levels'=>[], 'admin_path'=>admin_path()]);
        $id = intval(input('id'));
        $row = [];
        if ($id) { try { $row = Db::name('license')->where('id', $id)->find(); } catch (\Throwable $e) {} }
        // 编辑时若查不到（如旧数据异常）也保留 id，确保前端 f_id 有值、保存不走“新增”以免误生成新授权码
        if ($id > 0 && empty($row)) $row = ['id' => $id];
        $row['domains_arr'] = isset($row['domains']) ? license_domains($row['domains']) : [];
        // 编辑时装载附件列表，供编辑页“授权附件”区块正常读取
        $row['attach'] = ($id && isset($row['id'])) ? license_attach_list($row['id']) : [];
        $levels = function_exists('license_level_list') ? license_level_list() : [];
        return $this->fetch(APP_PATH . 'admin/view/' . ($this->web['admintemplate']??'default') . '/license_edit.html', [
            'row' => $row, 'act' => $id ? 'edit' : 'add', 'admin_path' => admin_path(), 'levels' => $levels,
        ]);
    }

    /** 保存授权（act=edit 强制更新；act=add / 无id 则为新增） */
    public function save()
    {
        if (!$this->loadPlug()) return json(['code' => -1, 'msg' => '授权插件未启用或未安装，请先在【插件管理】启用']);
        $act = trim((string)input('act'));
        $id  = intval(input('id'));
        // 防误新增：明确为编辑姿态(act=edit)却缺少授权ID时，直接报错，绝不回落为“新增/生成新授权码”
        if ($act === 'edit' && $id <= 0) return json(['code' => -1, 'msg' => '编辑失败：缺少授权ID']);
        $opts = [
            'code' => input('code'),
            'product' => input('product'),
            'uname' => input('uname'),
            'userid' => intval(input('userid')),
            'type' => input('type'),
            'duration' => intval(input('duration')),
            'domain_limit' => intval(input('domain_limit')),
            'domains' => input('domains'),
            'status' => intval(input('status')) ? 1 : 0,
            'remark' => input('remark'),
            'reset_limit' => intval(input('reset_limit')),
            'level_id' => intval(input('level_id')),
        ];
        // 兜底：域名上限为空/为0时，退回授权插件默认「默认绑定域名数」
        if (!function_exists('license_config')) { if (is_file($this->root . 'plugins/license/license/license.php')) include_once $this->root . 'plugins/license/license/license.php'; }
        if (function_exists('license_config')) {
            if (empty($opts['domain_limit'])) {
                $__cfg = license_config();
                $opts['domain_limit'] = intval($__cfg['lic_max_domains'] ?? 1);
            }
        } else {
            if (empty($opts['domain_limit'])) $opts['domain_limit'] = 1;
        }
        // 明确编辑模式：必须带有效 id，否则不允许走“新增”，避免误新增一条授权
        $isEdit = ($act === 'edit') || (!$act && $id > 0);
        if ($isEdit) {
            if ($id <= 0) return json(['code' => -1, 'msg' => '编辑失败：缺少授权ID']);
            try {
                $lvName = '';
                if ($opts['level_id'] > 0 && function_exists('license_level_list')) {
                    $lvRow = null;
                    try { $lvRow = Db::name('license_level')->where('id', $opts['level_id'])->find(); } catch (\Throwable $e) {}
                    if ($lvRow) $lvName = $lvRow['name'];
                }
                $data = [
                    'product' => $opts['product'], 'uname' => $opts['uname'], 'userid' => $opts['userid'],
                    'type' => $opts['type'], 'domain_limit' => $opts['domain_limit'],
                    'domains' => implode(',', license_domains($opts['domains'])), 'status' => $opts['status'],
                    'remark' => $opts['remark'], 'reset_limit' => $opts['reset_limit'],
                    'level_id' => $opts['level_id'], 'level_name' => $lvName,
                ];
                // 编辑：授权码通常保持不变；若填了新码则一并更新
                if ($opts['code'] !== '') $data['code'] = $opts['code'];
                if (empty($data['domains'])) $data['domains'] = '';
                $row = Db::name('license')->where('id', $id)->find();
                if (!$row) return json(['code' => -1, 'msg' => '编辑失败：授权不存在']);
                Db::name('license')->where('id', $id)->update($data);
                return json(['code' => 1, 'msg' => '保存成功']);
            } catch (\Throwable $e) { return json(['code' => -1, 'msg' => '保存失败：' . $e->getMessage()]); }
        }
        $r = license_add($opts);
        return json(['code' => $r['code'], 'msg' => $r['msg']]);
    }

    /** 快速新增授权（无表单，弹窗确认后自动生成授权码，待用户端绑定域名） */
    public function quickadd()
    {
        if (!$this->loadPlug()) return json(['code' => -1, 'msg' => '授权插件未启用或未安装，请先在【插件管理】启用']);
        $product = trim((string)input('product'));
        $uname   = trim((string)input('uname'));
        // 默认：永久、启用、可绑定1个域名；授权码由后端自动生成（可读性强、防重复）
        $opts = [
            'code' => '', 'product' => $product, 'uname' => $uname, 'userid' => 0,
            'type' => 'permanent', 'duration' => 1, 'domain_limit' => 1, 'domains' => '',
            'status' => 1, 'remark' => '后台一键新增', 'reset_limit' => 0, 'level_id' => 0,
        ];
        $r = license_add($opts);
        if ($r['code'] == 1) {
            return json(['code' => 1, 'msg' => '新增授权成功', 'license_code' => $r['license_code'] ?? '']);
        }
        return json(['code' => -1, 'msg' => $r['msg'] ?? '新增失败']);
    }

    /** 删除授权 */
    public function del()
    {
        $this->loadPlug();
        $id = intval(input('id'));
        try {
            Db::name('license')->where('id', $id)->delete();
            Db::name('license_attach')->where('license_id', $id)->delete();
            return json(['code' => 1, 'msg' => '删除成功']);
        } catch (\Throwable $e) { return json(['code' => -1, 'msg' => '删除失败']); }
    }

    /** 启用/停用 */
    public function setstatus()
    {
        $this->loadPlug();
        $id = intval(input('id'));
        $st = intval(input('status')) ? 1 : 0;
        try { Db::name('license')->where('id', $id)->update(['status' => $st]); return json(['code' => 1, 'msg' => 'ok']); }
        catch (\Throwable $e) { return json(['code' => -1, 'msg' => '失败']); }
    }

    /** 绑定域名 */
    public function bind()
    {
        $this->loadPlug();
        $id = intval(input('id'));
        $domains = input('domains');
        try {
            $row = Db::name('license')->where('id', $id)->find();
            if (!$row) return json(['code' => -1, 'msg' => '授权不存在']);
            $new = license_domains($domains);
            $cur = license_domains($row['domains']);
            $merged = array_merge($cur, array_diff($new, $cur));
            Db::name('license')->where('id', $id)->update(['domains' => implode(',', $merged)]);
            return json(['code' => 1, 'msg' => '绑定成功', 'domains' => $merged]);
        } catch (\Throwable $e) { return json(['code' => -1, 'msg' => '绑定失败']); }
    }

    /** 附件上传（multipart） */
    public function attach()
    {
        $this->loadPlug();
        $id = intval(input('license_id'));
        if (!$id) return json(['code' => -1, 'msg' => '缺少授权']);
        $updir = $this->root . 'public/static/license_attach/';
        if (!is_dir($updir)) @mkdir($updir, 0777, true);
        $file = Request::instance()->file('file');
        if (!$file) return json(['code' => -1, 'msg' => '未选择文件']);
        $info = $file->move($updir, md5(date('YmdHis') . $file->getInfo('name')) . '_' . $file->getInfo('name'));
        if ($info) {
            $rel = 'static/license_attach/' . $info->getFilename();
            license_attach_add($id, $file->getInfo('name'), $rel, $file->getSize());
            return json(['code' => 1, 'msg' => '上传成功']);
        }
        return json(['code' => -1, 'msg' => '上传失败']);
    }

    /** 删除附件 */
    public function attachdel()
    {
        if (!$this->loadPlug()) return json(['code' => -1, 'msg' => '插件未加载']);
        $aid = intval(input('aid'));
        try {
            $a = Db::name('license_attach')->where('id', $aid)->find();
            if ($a) {
                @unlink($this->root . 'public/' . $a['filepath']);
                Db::name('license_attach')->where('id', $aid)->delete();
            }
            return json(['code' => 1, 'msg' => '已删除']);
        } catch (\Throwable $e) { return json(['code' => -1, 'msg' => '失败']); }
    }

    public function ajaxlist()
    {
        $this->loadPlug();
        $list = [];
        try { $list = Db::name('license')->order('id desc')->limit(200)->select(); }
        catch (\Throwable $e) {}
        if (function_exists('license_domains')) foreach ($list as &$r) $r['domains_arr'] = license_domains($r['domains']);
        return json(['code' => 1, 'list' => $list]);
    }

    /** 获取本系统授权状态（用于后台顶部提示/去授权页面） */
    public function status()
    {
        $this->loadPlug();
        $r = function_exists('license_check_local') ? license_check_local() : ['code' => -1, 'msg' => '插件未就绪', 'domain' => ''];
        return json([
            'code' => $r['code'],
            'enabled' => ($r['code'] === -1) ? 0 : 1,
            'msg' => $r['msg'],
            'domain' => $r['domain'] ?? '',
        ]);
    }

    /** 后台“去授权”：输入授权码自动绑定当前域名并开启验证 */
    public function active()
    {
        $this->loadPlug();
        $code = trim(input('code'));
        if (!$this->loadPlug()) return json(['code' => -1, 'msg' => '授权插件未安装']);
        $r = function_exists('license_activate_local') ? license_activate_local($code) : ['code' => -1, 'msg' => '插件未就绪'];
        return json(['code' => $r['code'], 'msg' => $r['msg'], 'domain' => $r['domain'] ?? '']);
    }

    /* ============================================================
     * 授权等级管理
     * ============================================================ */
    public function level()
    {
        $this->loadPlug();
        $levels = function_exists('license_level_list') ? license_level_list() : [];
        return $this->fetch(APP_PATH . 'admin/view/' . ($this->web['admintemplate']??'default') . '/license_level.html', [
            'levels' => $levels, 'admin_path' => admin_path(),
        ]);
    }
    public function leveladd()
    {
        $this->loadPlug();
        if (!function_exists('license_level_add')) return json(['code' => -1, 'msg' => '插件未就绪']);
        $r = license_level_add(input('name'), intval(input('sort')));
        return json(['code' => $r['code'], 'msg' => $r['msg']]);
    }
    public function levelrename()
    {
        $this->loadPlug();
        if (!function_exists('license_level_rename')) return json(['code' => -1, 'msg' => '插件未就绪']);
        $r = license_level_rename(intval(input('id')), input('name'));
        return json(['code' => $r['code'], 'msg' => $r['msg']]);
    }
    public function leveldel()
    {
        $this->loadPlug();
        if (!function_exists('license_level_del')) return json(['code' => -1, 'msg' => '插件未就绪']);
        $r = license_level_del(intval(input('id')));
        return json(['code' => $r['code'], 'msg' => $r['msg']]);
    }
}