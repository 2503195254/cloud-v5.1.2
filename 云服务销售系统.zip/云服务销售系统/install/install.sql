-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- 主机： localhost:3306
-- 生成日期： 2026-08-07 21:43:05
-- 服务器版本： 5.7.44
-- PHP 版本： 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `user`
--

-- --------------------------------------------------------

--
-- 表的结构 `yun_admin`
--

CREATE TABLE `yun_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `qq` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `password` varchar(288) NOT NULL,
  `mail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `yun_admin`
--

INSERT INTO `yun_admin` (`id`, `name`, `qq`, `user`, `password`, `mail`) VALUES
(1, '超级管理员', 'youremail', 'admin', '$2y$10$6eIBzxwHvCcm9K4DuZf1DeTj36/L29ILGmknzkJyj4wHuHlxSdrSe', 'youremail@example.com');

-- --------------------------------------------------------

--
-- 表的结构 `yun_affsymoney`
--

CREATE TABLE `yun_affsymoney` (
  `id` int(11) NOT NULL,
  `information` text NOT NULL,
  `money` varchar(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `time` varchar(50) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_afftxjl`
--

CREATE TABLE `yun_afftxjl` (
  `id` int(11) NOT NULL,
  `information` text NOT NULL,
  `money` varchar(100) NOT NULL,
  `state` varchar(10) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `time` varchar(50) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_announcement`
--

CREATE TABLE `yun_announcement` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `information` text NOT NULL,
  `time` varchar(288) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `yun_announcement`
--

INSERT INTO `yun_announcement` (`id`, `name`, `information`, `time`) VALUES
(1, '云服务销售系统服务条例', '<h3>禁止条例</h3>\n<p>禁止搭建违反中国网络法律的内容,比如:外挂,诈骗,钓鱼,赌博,色情,VPN等,查到直接删机,冻结账户,不退款!</p>\n<h3>退款条例</h3>\n<p>不支持退款!</p>\n', '1729342986');

-- --------------------------------------------------------

--
-- 表的结构 `yun_cart`
--

CREATE TABLE `yun_cart` (
  `id` int(11) NOT NULL,
  `product` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `money` varchar(200) NOT NULL DEFAULT '0',
  `cycle` varchar(100) NOT NULL,
  `firstmo` varchar(288) NOT NULL DEFAULT '0',
  `serverid` varchar(200) NOT NULL,
  `upgrade` varchar(10) NOT NULL DEFAULT '0',
  `upgrades` text,
  `buy` varchar(10) NOT NULL DEFAULT '0',
  `hide` varchar(10) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `renew` varchar(100) NOT NULL DEFAULT '0',
  `limits` varchar(288) NOT NULL DEFAULT '0',
  `inventory` varchar(100) NOT NULL DEFAULT '0',
  `islicense` varchar(10) NOT NULL DEFAULT '0',
  `lic_level_id` int(11) NOT NULL DEFAULT '0',
  `data1` text,
  `data2` text,
  `data3` text,
  `data4` text,
  `data5` text,
  `data6` text,
  `data7` text,
  `data8` text,
  `data9` text,
  `data10` text,
  `data11` text,
  `data12` text,
  `data13` text,
  `data14` text,
  `data15` text,
  `data16` text,
  `data17` text,
  `data18` text,
  `data19` text,
  `data20` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_order`
--

CREATE TABLE `yun_order` (
  `id` int(11) NOT NULL,
  `user` varchar(300) DEFAULT NULL,
  `password` varchar(320) DEFAULT NULL,
  `userid` varchar(100) NOT NULL,
  `cartid` varchar(100) NOT NULL,
  `atime` varchar(300) NOT NULL,
  `ztime` varchar(300) NOT NULL,
  `state` varchar(200) NOT NULL,
  `data1` text,
  `data2` text,
  `data3` text,
  `data4` text,
  `data5` text,
  `data6` text,
  `data7` text,
  `data8` text,
  `data9` text,
  `data10` text,
  `data11` text,
  `data12` text,
  `data13` text,
  `data14` text,
  `data15` text,
  `data16` text,
  `data17` text,
  `data18` text,
  `data19` text,
  `data20` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_pay`
--

CREATE TABLE `yun_pay` (
  `id` int(11) NOT NULL,
  `name` varchar(288) NOT NULL,
  `ordernumber` varchar(288) NOT NULL,
  `pay` varchar(288) NOT NULL,
  `money` varchar(288) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `time` varchar(288) NOT NULL,
  `state` varchar(288) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_pays`
--

CREATE TABLE `yun_pays` (
  `id` int(11) NOT NULL,
  `name` varchar(288) NOT NULL,
  `plugins` varchar(288) NOT NULL,
  `state` varchar(10) NOT NULL DEFAULT '0',
  `data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `yun_pays`
--

INSERT INTO `yun_pays` (`id`, `name`, `plugins`, `state`, `data`) VALUES
(7, '支付宝', 'f2fpay', '1', '[{\"name\":\"appId\",\"title\":\"APPID\",\"type\":\"input\",\"prompt\":\"APPID\",\"value\":\"2021003196616285\"},{\"name\":\"rsaPrivateKey\",\"title\":\"\\u5e94\\u7528\\u79c1\\u94a5\",\"type\":\"textarea\",\"prompt\":\"\\u5e94\\u7528\\u79c1\\u94a5\",\"value\":\"MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDci++ngVV7vJyqjZdyUXNjQKk4eN0U9QnTuFjgeb5\\/Xq9R30Bo8fUfSxYlpj1s10gyaaULApLau6i\\/yZ1\\/sPxEogk4EIRNELUsJDYVL61R6Rmd+Yy7liAA9uMphihjswtjmZ\\/ylIOlHAC7504RCLvMKobL6aVb43QPV8SIR7TmAbObR5cXC5\\/6awxLXvcrgNmtOGpMlB2uEDc8EDhjP05\\/FWkpDrTm1z20xmqNgEFtMarCqqiWdZMuJgQdP+aUgD9ptx0RmDv2Lom9jS0irVAW6nIzLlfx33Q+NECU6Q\\/kVfp\\/SGwiKn+WwcB2Bw4YwW6QeETq7+uWr0YraYC4iAgzAgMBAAECggEBAKS0QMq4dM2OovVf\\/p0aJPEXhgitgnW3NZqOzpj9cn2OiaG7908oeyXennCJgM\\/6ymkTqnTZfDCr+q8X8248D3l2BSqAcz1WX+bSOC2ESIymZ0Ip7qbcy5PMzQLitOEYAkZkoSW5McMpcYbii9N+0Tj8\\/WPlXl+MMs2OfzBDVN57PcSbzhQfzCrSajvH+dcnQPI5UQqVZdAaChq0A1X36ExtnpYKAGWgyqsv66q+NNCMAIW+U403sIBwPvRS\\/McamlcATQe6eJUQHM2N9U2rtJ9EYzX5NTjdlGU+w1eMRoT7mY6c4vlpXIaSdesA6w7os9L9MSY\\/aDynsTNSv3dVWakCgYEA9Ojw\\/2JvPuneRkY2rr2dKqxosvWAy+vO\\/VhJtdEnQ1SXwoJgKw14+lwQ3m6KAH50f0FQWlvNo0zEUyDG4ER3BwXwXNG7Ty0fCRE3ZXCFRd8jaoRL\\/VaT+VIJYL0ttMr0lQ7iPg7CsFtRuMoJw2Za+TYXMqt11g8aVnZONP7VTpcCgYEA5oiRscpu9z3dUvZRLsnOR5JAWZfT4tjbXA\\/7zzQ0LsYjMCjSFUr8WwqHqQg2\\/qmY0SyyWwPZSfnzcHLLO6n9TCcmkdf51oLEuh9Ql5JD+uh7XgRhh3Ks3JQJZUiSssBzGVKXz1ExSUxmg1NOTs3EkXwUZpq3U4xXi72Z8d5xosUCgYBQsjhGTc7N8g01Jol6Biw1FV3iKZZomqg3PdH7wJCpVMQ0aPT6+pN0GsXMJKwAAaqtC35IZ5tYRUEjCte8qZJ2k\\/RhARIwwnNJb4zLNcoT\\/bQTsse\\/D7nuGqPQZkUbHwx72M2fGQn5Rf2lX5zb72vmVXZLUcef4pYRCyY1vAnYvQKBgFcYkbLSAEp4nP2TAejjZYO0xYsTyYGS3I1TnJcT6gMh6Hlxcq2Ivv7GY6qA6AYenRWqBVhNg\\/Jm9IovVIkeGAyFXhULu+BHV3vaCOC66eQJoVJL5Wz+7kAHzeTuHj5aZyHSCnjQ\\/AXtT22eM5+iLfmpHywEl+6AvzKUV20B1XzhAoGAUB46wCVtFFeNIIJ0hRoX1EsxeA4G7ue0nOHrMb+7s7ssR0\\/ykVrjjFkMM8DR6uLo0i9zMYw2kdzgMPWsvEW6AnFpTpVse5bvlpuhAMJyG4oXY+6qBBGdgVrtz7LhKgTAf3NZgRh06wQBNciuD6ZYaVsPEZVfe94jKv2d\\/s7I2TI=\"},{\"name\":\"alipayrsaPublicKey\",\"title\":\"\\u652f\\u4ed8\\u5b9d\\u516c\\u94a5\",\"type\":\"textarea\",\"prompt\":\"\\u652f\\u4ed8\\u5b9d\\u516c\\u94a5\",\"value\":\"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnraZEwjsTNeQ\\/7IdpGC4zs985r453181+sL9jX4DpHtD+F+LMQsWodBvsdUmXnafALOs6W7dUzZ9N26Hn8X1EQq215XlpdZfBk7yT9Zg+Ze3vCiKKCVl9XtGgwlrPQMwGcNJD4zKNg0WfPjdqTvb+unnyMLGFzJPFHUGW7zVYO+9rWG71LlGkfq0TMgKELYq0bJ39xHcMCG6+2Mf0Ul8t5ukMq7LcS1xHLunlI1V8tZr6GWqnd3KxM05zolzJwNfjaXgoNkoMCvK2ghM94Mw4gmf0sP15jVXUBd2EnfKDO4+SCn4vsn7bR8YN7rd\\/vLIgWVJoiBr09lNXaO5s9c5owIDAQAB\"}]');

-- --------------------------------------------------------

--
-- 表的结构 `yun_product`
--

CREATE TABLE `yun_product` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `introduce` text NOT NULL,
  `hide` varchar(10) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_server`
--

CREATE TABLE `yun_server` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `host` varchar(100) NOT NULL,
  `ip` varchar(200) NOT NULL,
  `security` text NOT NULL,
  `port` varchar(200) NOT NULL,
  `ssl` varchar(200) NOT NULL DEFAULT '0',
  `user` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `serverplugins` varchar(288) NOT NULL,
  `data1` text,
  `data2` text,
  `data3` text,
  `data4` text,
  `data5` text,
  `data6` text,
  `data7` text,
  `data8` text,
  `data9` text,
  `data10` text,
  `data11` text,
  `data12` text,
  `data13` text,
  `data14` text,
  `data15` text,
  `data16` text,
  `data17` text,
  `data18` text,
  `data19` text,
  `data20` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_sq`
--

CREATE TABLE `yun_sq` (
  `id` int(11) NOT NULL,
  `domain` text NOT NULL,
  `qq` varchar(288) NOT NULL,
  `ip` varchar(288) NOT NULL,
  `time` varchar(288) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_ticket`
--

CREATE TABLE `yun_ticket` (
  `id` int(11) NOT NULL,
  `title` varchar(288) NOT NULL,
  `content` mediumtext NOT NULL,
  `userid` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `state` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_transaction`
--

CREATE TABLE `yun_transaction` (
  `id` int(11) NOT NULL,
  `userid` varchar(288) NOT NULL,
  `content` text NOT NULL,
  `time` varchar(288) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_transferrecord`
--

CREATE TABLE `yun_transferrecord` (
  `id` int(11) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `record` mediumtext NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_user`
--

CREATE TABLE `yun_user` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `user` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `money` varchar(200) NOT NULL DEFAULT '0',
  `mail` varchar(300) NOT NULL,
  `qq` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `aff` varchar(100) NOT NULL,
  `affmoney` varchar(100) NOT NULL DEFAULT '0',
  `upperid` varchar(100) NOT NULL,
  `time` varchar(200) NOT NULL,
  `state` varchar(10) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `yun_web`
--

CREATE TABLE `yun_web` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  `favicon` text NOT NULL,
  `template` varchar(288) NOT NULL,
  `admintemplate` varchar(288) NOT NULL,
  `wh` varchar(10) NOT NULL DEFAULT '0',
  `whxx` text NOT NULL,
  `email` varchar(100) DEFAULT '0',
  `emailchar` varchar(500) NOT NULL,
  `emailsecure` varchar(100) NOT NULL,
  `emailport` varchar(500) NOT NULL,
  `emailhost` varchar(500) NOT NULL,
  `emailname` varchar(500) NOT NULL,
  `emailpass` varchar(500) NOT NULL,
  `emailauth` varchar(500) NOT NULL,
  `affdiscount` varchar(100) NOT NULL,
  `affwithdrawal` varchar(100) NOT NULL,
  `cronzz` varchar(100) NOT NULL,
  `cronsc` varchar(100) NOT NULL,
  `paycron` varchar(100) NOT NULL,
  `tickcron` varchar(100) NOT NULL,
  `zcyxyz` varchar(100) NOT NULL DEFAULT '0',
  `yxdl` varchar(288) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `yun_web`
--

 INSERT INTO `yun_web` (`id`, `name`, `description`, `keywords`, `favicon`, `template`, `admintemplate`, `wh`, `whxx`, `email`, `emailchar`, `emailsecure`, `emailport`, `emailhost`, `emailname`, `emailpass`, `emailauth`, `affdiscount`, `affwithdrawal`, `cronzz`, `cronsc`, `paycron`, `tickcron`, `zcyxyz`, `yxdl`) VALUES
(1, '云服务销售系统', '云服务销售系统,提供快速、稳定、优质的云服务！', '云服务销售系统,云服务器,云主机,免备案云服务器,香港云服务器,美国云服务器', '/favicon.ico', 'default', 'default', '0', '<title>维护中...</title>\r\n网站维护中...', '1', 'UTF-8', 'ssl', '465', 'your-smtp-host', 'youremail@example.com', '', 'true', '0.25', '10', '3', '3', '5', '3', '1', '1');

-- --------------------------------------------------------

--
-- 表的结构 `rsthemes_displays`
--

CREATE TABLE `rsthemes_displays` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `rsthemes_displays`
--

INSERT INTO `rsthemes_displays` (`id`, `name`, `active`, `created_at`, `updated_at`) VALUES
(1, 'Default', 1, '2024-11-02 13:00:18', '2024-11-02 13:00:18');

--
-- 转储表的索引
--

--
-- 表的索引 `yun_admin`
--
ALTER TABLE `yun_admin`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_affsymoney`
--
ALTER TABLE `yun_affsymoney`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_afftxjl`
--
ALTER TABLE `yun_afftxjl`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_announcement`
--
ALTER TABLE `yun_announcement`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_cart`
--
ALTER TABLE `yun_cart`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_order`
--
ALTER TABLE `yun_order`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_pay`
--
ALTER TABLE `yun_pay`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_pays`
--
ALTER TABLE `yun_pays`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_product`
--
ALTER TABLE `yun_product`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_server`
--
ALTER TABLE `yun_server`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_sq`
--
ALTER TABLE `yun_sq`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_ticket`
--
ALTER TABLE `yun_ticket`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_transaction`
--
ALTER TABLE `yun_transaction`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_transferrecord`
--
ALTER TABLE `yun_transferrecord`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_user`
--
ALTER TABLE `yun_user`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `yun_web`
--
ALTER TABLE `yun_web`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `rsthemes_displays`
--
ALTER TABLE `rsthemes_displays`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `yun_admin`
--
ALTER TABLE `yun_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `yun_affsymoney`
--
ALTER TABLE `yun_affsymoney`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_afftxjl`
--
ALTER TABLE `yun_afftxjl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_announcement`
--
ALTER TABLE `yun_announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `yun_cart`
--
ALTER TABLE `yun_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_order`
--
ALTER TABLE `yun_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_pay`
--
ALTER TABLE `yun_pay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_pays`
--
ALTER TABLE `yun_pays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- 使用表AUTO_INCREMENT `yun_product`
--
ALTER TABLE `yun_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_server`
--
ALTER TABLE `yun_server`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_sq`
--
ALTER TABLE `yun_sq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_ticket`
--
ALTER TABLE `yun_ticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_transaction`
--
ALTER TABLE `yun_transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_transferrecord`
--
ALTER TABLE `yun_transferrecord`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_user`
--
ALTER TABLE `yun_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `yun_web`
--
ALTER TABLE `yun_web`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `rsthemes_displays`
--
ALTER TABLE `rsthemes_displays`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
-- --------------------------------------------------------
-- 通用插件管理系统：插件登记表 yun_plugin
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `yun_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '插件名称',
  `type` varchar(50) NOT NULL DEFAULT 'other' COMMENT '类型:api/pay/host/template/other',
  `code` varchar(100) NOT NULL DEFAULT '' COMMENT '插件唯一标识(目录名)',
  `version` varchar(30) NOT NULL DEFAULT '1.0.0' COMMENT '版本号',
  `desc` varchar(500) NOT NULL DEFAULT '' COMMENT '描述',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1启用 0停用',
  `config` text COMMENT '插件配置(JSON)',
  `installtime` int(11) NOT NULL DEFAULT '0' COMMENT '安装时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- API对接插件：第三方应用/专属密钥表 yun_api_app
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `yun_api_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `appid` varchar(64) NOT NULL DEFAULT '',
  `appname` varchar(100) NOT NULL DEFAULT '',
  `appkey` varchar(64) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `expire` int(11) NOT NULL DEFAULT '0',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `create_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `appid` (`appid`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- API对接插件：API订单表 yun_api_order
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `yun_api_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `out_trade_no` varchar(64) NOT NULL DEFAULT '',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `appid` varchar(64) NOT NULL DEFAULT '',
  `cartid` int(11) NOT NULL DEFAULT '0',
  `cycle` varchar(50) NOT NULL DEFAULT '',
  `num` int(11) NOT NULL DEFAULT '1',
  `paymoney` varchar(50) NOT NULL DEFAULT '0',
  `discount` varchar(20) NOT NULL DEFAULT '1',
  `upper` varchar(100) NOT NULL DEFAULT '',
  `state` varchar(20) NOT NULL DEFAULT '0',
  `create_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `out_trade_no` (`out_trade_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- API对接插件：同步日志表 yun_api_synclog
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `yun_api_synclog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL DEFAULT 'product',
  `content` text,
  `create_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 授权插件：授权记录表 yun_license
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `yun_license` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL DEFAULT '',
  `product` varchar(200) NOT NULL DEFAULT '',
  `userid` int(11) NOT NULL DEFAULT '0',
  `uname` varchar(100) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'permanent',
  `domain_limit` int(11) NOT NULL DEFAULT '1',
  `domains` text,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `create_time` int(11) NOT NULL DEFAULT '0',
  `expire_time` int(11) NOT NULL DEFAULT '0',
  `remark` varchar(500) NOT NULL DEFAULT '',
  `reset_limit` int(11) NOT NULL DEFAULT '0',
  `reset_used` int(11) NOT NULL DEFAULT '0',
  `level_id` int(11) NOT NULL DEFAULT '0',
  `level_name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 授权插件：授权附件表 yun_license_attach
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `yun_license_attach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `license_id` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(300) NOT NULL DEFAULT '',
  `filepath` varchar(500) NOT NULL DEFAULT '',
  `filesize` varchar(50) NOT NULL DEFAULT '0',
  `create_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `license_id` (`license_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 邮件模板表（系统设置 → 邮件模板配置）
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `yun_email_tpl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '模板名称',
  `subject` varchar(200) NOT NULL DEFAULT '' COMMENT '邮件主题',
  `content` text COMMENT '邮件内容(HTML)',
  `category` varchar(50) NOT NULL DEFAULT '通知' COMMENT '分类：验证码/通知/营销',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用发送 1启用 0禁用',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 系统自带邮件模板（对应源码各处发送的邮件，{内容} 占位符会在发送时替换为动态正文）
INSERT INTO `yun_email_tpl` (`name`,`subject`,`content`,`create_time`) VALUES
('回复工单通知','回复工单通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('关闭工单通知','关闭工单通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('你的工单已被站长关闭','你的工单已被站长关闭','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('你的提现申请已处理','你的提现申请已处理','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('推广余额提现通知','推广余额提现通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('产品过户通知','产品过户通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('产品接收通知','产品接收通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('过户成功通知','过户成功通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('修改邮箱通知','修改邮箱通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('请求绑定邮箱通知','请求绑定邮箱通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('旧密码修改密码通知','旧密码修改密码通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('修改密码通知','修改密码通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('邮箱修改密码通知','邮箱修改密码通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('提交工单通知','提交工单通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('客户提交工单通知','客户提交工单通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('客户回复工单通知','客户回复工单通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('找回密码通知','找回密码通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('重置密码通知','重置密码通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('登录成功通知','登录成功通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('邮箱登录验证码通知','邮箱登录验证码通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('邮箱登录成功通知','邮箱登录成功通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('注册成功通知','注册成功通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('注册验证码通知','注册验证码通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('购买授权成功通知','购买授权成功通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('购买产品通知','购买产品通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('产品暂停通知','产品暂停通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('产品终止通知','产品终止通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0),
('工单关闭通知','工单关闭通知','<div style="margin:0;padding:0;background:#F0F4FA;font-family:Arial,Helvetica,''Microsoft YaHei'',sans-serif;"><div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(20,50,120,.08);"><div style="background:linear-gradient(120deg,#0A3F8F,#1A66E8);padding:30px 32px;"><div style="color:#FFFFFF;font-size:20px;font-weight:bold;line-height:1.5;letter-spacing:.5px;">{标题}</div><div style="color:rgba(255,255,255,.82);font-size:13px;margin-top:6px;">您收到一条新的系统消息通知</div></div><div style="padding:30px 32px;color:#24324D;font-size:14px;line-height:1.9;"><p style="margin:0 0 6px;font-weight:600;">尊敬的用户：</p><div style="margin:0 0 18px;">{内容}</div><div style="padding:14px 18px;background:#F5F8FF;border-left:4px solid #1A66E8;border-radius:6px;color:#5B6B84;font-size:13px;line-height:1.9;">温馨提醒：此邮件由系统自动发送，请勿直接回复。如并非本人操作，请及时登录账号核实并修改安全设置。<br/>如有任何疑问，欢迎随时联系客服，我们将竭诚为您服务。</div></div><div style="padding:20px 32px;background:#F7F9FC;border-top:1px solid #E8EEF8;text-align:center;color:#9AA6B8;font-size:12px;line-height:1.9;">这是一封系统通知邮件 · 请勿回复<br/>如遇问题请通过官方渠道联系在线客服处理</div></div></div>',0);

-- --------------------------------------------------------
-- 系统键值配置表（如：产品管理账号生成格式）
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `yun_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `k` varchar(64) NOT NULL DEFAULT '',
  `v` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k` (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `yun_set` (`k`, `v`) VALUES
('account_prefix', 'a'),
('account_len', '7'),
('account_use_digit', '1'),
('account_use_letter', '0'),
('crontask_1', '1'),
('crontask_2', '1'),
('crontask_3', '1'),
('crontask_4', '1'),
('crontask_5', '1');

COMMIT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
