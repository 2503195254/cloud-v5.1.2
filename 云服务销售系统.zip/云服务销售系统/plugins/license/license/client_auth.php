<?php
/**
 * ============================================================
 *  授权用户端验证文件  client_auth.php   （可独立使用/嵌入被授权系统）
 * ============================================================
 *  作用：放在被销售的源码/插件/模板中，向【授权端】请求验证。
 *  用法（在被授权系统中）：
 *      require_once('client_auth.php');
 *      $auth = LicenseClient::check('授权码/或留空用内置配置');
 *      if ($auth['valid']) {  // 已授权
 *      } else { exit('未授权：' . $auth['msg']); }
 *
 *  更简单：直接以 函数方式：
 *      $result = client_auth_check($AUTH_SERVER, $AUTH_CODE, $currentDomain);
 *      // $result['valid'] === true 表示有效
 *
 *  配置示例（请修改下面前三项服务器信息）：
 *      $AUTH_SERVER = 'https://你授权端的域名/license_api/';
 *      $AUTH_CODE   = '在此填入授权码';     // 可留空，由系统文件读取
 *      $AUTH_SECRET = '';                    // 若授权端配置了签名秘钥则填一致
 * ============================================================
 */

/**
 * 安全获取当前域名
 */
if (!function_exists('license_client_domain')) {
    function license_client_domain() {
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : '');
        // 去掉端口
        $host = preg_replace('/:\d+$/', '', $host);
        return strtolower(trim($host));
    }
}

/**
 * 向授权端发起验证请求
 * @param string $server  授权端验证接口基址，如 https://xx.com/license_api/
 * @param string $authCode 授权码
 * @param string $domain   当前域名（可留空则自动取）
 * @param string $secret   签名秘钥（与授权端一致才签名）
 * @return array ['valid'=>bool,'verified'=>bool,'msg'=>string,'data'=>array|null]
 */
if (!function_exists('client_auth_check')) {
    function client_auth_check($server, $authCode, $domain = '', $secret = '') {
        $server = rtrim(trim($server), '/');
        $domain = $domain === '' ? license_client_domain() : strtolower(trim($domain));
        $url = $server . '/verify?code=' . urlencode($authCode) . '&domain=' . urlencode($domain);
        if ($secret !== '') {
            $url .= '&sign=' . md5($authCode . $domain . $secret);
        }
        $resp = client_auth_http($url);
        $json = json_decode($resp, true);
        if (!is_array($json)) {
            return ['valid' => false, 'verified' => false, 'msg' => '无法连接授权服务器', 'data' => null];
        }
        if (isset($json['code']) && $json['code'] == 1) {
            return ['valid' => true, 'verified' => true, 'msg' => ($json['msg'] ?? '授权有效'), 'data' => ($json['data'] ?? null)];
        }
        return ['valid' => false, 'verified' => true, 'msg' => ($json['msg'] ?? '授权无效'), 'data' => null];
    }
}

/**
 * HTTP GET（curl 优先，回退 file_get_contents）
 */
if (!function_exists('client_auth_http')) {
    function client_auth_http($url, $timeout = 15) {
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => $timeout, CURLOPT_TIMEOUT => $timeout,
                CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false,
            ]);
            $res = curl_exec($ch);
            curl_close($ch);
            if ($res !== false && $res !== '') return $res;
        }
        return @file_get_contents($url);
    }
}

/**
 * 便捷类版本（可实例化使用）
 */
if (!class_exists('LicenseClient')) {
    class LicenseClient {
        public $server = '';
        public $code = '';
        public $secret = '';
        public function __construct($server = '', $code = '', $secret = '') {
            $this->server = $server; $this->code = $code; $this->secret = $secret;
        }
        public function check($domain = '') {
            return client_auth_check($this->server, $this->code, $domain, $this->secret);
        }
    }
}

// ---------- 演示配置（请按实际修改） ----------
// $AUTH_SERVER = 'https://你的授权端域名/license_api';
// $AUTH_CODE   = '在此填授权码';
// $AUTH_SECRET = '';
// $demo = client_auth_check($AUTH_SERVER, $AUTH_CODE);
// echo $demo['valid'] ? '已授权' : '未授权：' . $demo['msg'];

/* 说明：此文件为通用授权用户端，授权端需安装“授权系统”插件并提供 /license_api/verify 接口。 */