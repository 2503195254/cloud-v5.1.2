<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\Route;
//定义404
Route::miss('index/index/null');

return [
//前台
"/"=>"index/index/index",
"/index"=>"index/index/index",
"/login"=>"index/index/login",
"/register"=>"index/index/register",
"/cart/[:id]"=>"index/index/cart",
"/user"=>"index/user/index",
"/user/index"=>"index/user/index",
"/user/password"=>"index/user/password",
"/user/information"=>"index/user/information",
"/user/logout"=>"index/user/logout",
"/product/[:id]"=>"index/index/product",
"/user/pay"=>"index/user/pay",
"/user/order/[:id]"=>"index/user/order",
"/user/return/:id"=>"index/user/return",
"/index/notify/:id"=>"index/index/notify",
"/announcement/[:id]"=>"index/index/announcement",
"/user/payrecord"=>"index/user/payrecord",
"/cron"=>"index/index/cron",
"/pwreset"=>"index/index/pwreset",
"/user/submitticket"=>"index/user/submitticket",
"/user/supportticket/[:id]"=>"index/user/supportticket",
"/user/mail"=>"index/user/mail",
"/user/transfer"=>"index/user/transfer",
"/user/transaction"=>"index/user/transaction",
"/user/aff"=>"index/user/aff",
"/user/transferrecord"=>"index/user/transferrecord",
"/user/api"=>"index/user/api",
"/aff/:upper"=>"index/index/aff",
"/sq"=>"index/sq/sq",
//授权插件：授权端验证接口
"/license_api/:action"=>"index/LicenseApi/index",
//授权插件：本系统授权状态(前台横幅)
"/license-status"=>"index/license/status",
//授权插件：前台授权查询页(免登录)
"/license-query"=>"index/license/query",
//授权插件：用户中心我的授权
"/user/mylicense"=>"index/license/my",
"/user/license/selfdo"=>"index/license/selfdo",
"/license/download"=>"index/license/download",

//插件API统一入口
"/api/:plugin/:action"=>"index/api/index",
//后台
"/admin"=>"admin/index/index",
"/admin/login"=>"admin/login/index",
"/admin/plugin"=>"admin/plugin/index",
"/admin/plugin/install"=>"admin/plugin/install",
"/admin/plugin/uninstall"=>"admin/plugin/uninstall",
"/admin/plugin/setstatus"=>"admin/plugin/setstatus",
"/admin/plugin/sync"=>"admin/plugin/sync",
"/admin/plugin/config"=>"admin/plugin/config",
"/admin/plugin/apimanage"=>"admin/plugin/apimanage",
//授权插件：后台授权管理
"/admin/license"=>"admin/License/index",
"/admin/license/edit/[:id]"=>"admin/License/edit",
"/admin/license/save"=>"admin/License/save",
"/admin/license/quickadd"=>"admin/License/quickadd",
"/admin/license/del"=>"admin/License/del",
"/admin/license/setstatus"=>"admin/License/setstatus",
"/admin/license/bind"=>"admin/License/bind",
"/admin/license/attach"=>"admin/License/attach",
"/admin/license/attachdel"=>"admin/License/attachdel",
"/admin/license/ajaxlist"=>"admin/License/ajaxlist",
"/admin/license/status"=>"admin/License/status",
"/admin/license/active"=>"admin/License/active",
"/admin/license/level"=>"admin/License/level",
"/admin/license/leveladd"=>"admin/License/leveladd",
"/admin/license/levelrename"=>"admin/License/levelrename",
"/admin/license/leveldel"=>"admin/License/leveldel",
"/admin/index"=>"admin/index/index",
"/admin/sysinfo"=>"admin/index/sysinfo",
"/admin/info"=>"admin/index/info",
"/admin/password"=>"admin/index/password",
"/admin/logout"=>"admin/index/logout",
"/admin/set"=>"admin/index/set",
"/admin/sysbase"=>"admin/index/sysbase",
"/admin/accountset"=>"admin/index/accountset",
"/admin/mailset"=>"admin/index/mailset",
		"/admin/mailtest"=>"admin/index/mailtest",
"/admin/mailtemplate"=>"admin/index/mailtemplate",
"/admin/mailtemplate-edit"=>"admin/index/mailtemplateEdit",
"/admin/mailbroadcast"=>"admin/index/mailbroadcast",
"/admin/affset"=>"admin/index/affset",
"/admin/cronset"=>"admin/index/cronset",
"/admin/docs"=>"admin/index/docs",
"/admin/yxset"=>"admin/index/yxset",
"/admin/user/[:id]/[:orderid]"=>"admin/index/user",
"/admin/ticket/[:id]"=>"admin/index/ticket",
"/admin/classification/[:id]"=>"admin/index/classification",
"/admin/server/[:id]"=>"admin/index/server",
"/admin/product/[:id]"=>"admin/index/product",
"/admin/announcement/[:id]"=>"admin/index/announcement",
"/admin/aff"=>"admin/index/aff",
"/admin/affsy"=>"admin/index/affsy",
"/admin/pay"=>"admin/index/pay",
"/admin/transferrecord"=>"admin/index/transferrecord",
"/admin/transaction"=>"admin/index/transaction",
		"/admin/order/[:id]"=>"admin/index/order",
"/admin/pays/[:id]"=>"admin/index/pays",
"/admin/sq/[:id]"=>"admin/index/sq",
		"/admin/cronset"=>"admin/index/cronset",
		"/admin/docs"=>"admin/index/docs",
];
