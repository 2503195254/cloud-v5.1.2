<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | 云服务销售系统 · 应用入口文件
// | 功能：PHP8 兼容、伪静态自检、未安装跳转、动态后台地址
// +----------------------------------------------------------------------

// 屏蔽 PHP 8 对旧版框架的弃用/弱类型提示，避免被框架转成异常
error_reporting(E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED & ~E_WARNING & ~E_NOTICE & ~E_STRICT);

// 读取后台访问路径配置（纯文本文件，避免 OPcache 缓存导致修改后无法即时生效）
$adminPathFile = __DIR__ . '/../app/admin_path.txt';
$_adminPath = 'admin';
if (file_exists($adminPathFile)) {
    $_p = trim((string)@file_get_contents($adminPathFile));
    if ($_p !== '' && preg_match('/^[a-zA-Z0-9_]+$/', $_p)) {
        $_adminPath = $_p;
    }
}
define('DYN_ADMIN_PATH', $_adminPath);

// ---- 伪静态自检接口（加载框架前运行，无需数据库）----
if (isset($_SERVER['PATH_INFO']) && stripos(trim($_SERVER['PATH_INFO'], '/'), '__rewrite__') === 0) {
    echo 'REWRITE_OK:' . $_SERVER['PATH_INFO'];
    exit;
}
if (isset($_SERVER['REDIRECT_URL']) && stripos(trim($_SERVER['REDIRECT_URL'], '/'), '__rewrite__') !== false) {
    echo 'REWRITE_OK:' . $_SERVER['REDIRECT_URL'];
    exit;
}

// ---- 未安装则跳转到安装程序 ----
define('__INSTALL_LOCK__', __DIR__ . '/../install/install.lock');
$isInstalling = (isset($_SERVER['SCRIPT_NAME']) && basename($_SERVER['SCRIPT_NAME']) === 'install.php');
if (!$isInstalling && !@file_exists(__INSTALL_LOCK__)) {
    // 强制不缓存跳转响应，避免浏览器缓存 “未安装跳转”/“已安装” 旧页面造成假象
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    $base = dirname($_SERVER['SCRIPT_NAME'] ?? '/');
    header('Location: ' . rtrim($base, '/') . '/install.php');
    exit;
}
// 安装阶段（install.lock 不存在或安装中）：主站不缓存，始终读取最新状态
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// ---- 动态后台地址：内部将【配置的后台路径】映射为标准 admin 模块 ----
// 前台所有 /xxx 都不会受影响；只有命中配置路径才会被重写到 /admin/… 交由后台路由处理。
$_pathInfo = $_SERVER['PATH_INFO'] ?? '';
if ($_pathInfo === '') {
    foreach (['REDIRECT_URL','ORIG_PATH_INFO'] as $_type) {
        if (!empty($_SERVER[$_type])) {
            $_pi = $_SERVER[$_type];
            // 去掉入口脚本前缀
            if (isset($_SERVER['SCRIPT_NAME']) && strpos($_pi, $_SERVER['SCRIPT_NAME']) === 0) {
                $_pi = substr($_pi, strlen($_SERVER['SCRIPT_NAME']));
            }
            $_pathInfo = $_pi;
            break;
        }
    }
    // 兼容 PATHINFO 兼容模式 s=
    if ($_pathInfo === '' && isset($_GET['s'])) {
        $_pathInfo = '/' . trim((string)$_GET['s'], '/');
    }
}
// 取第一段
$_first = ltrim($_pathInfo, '/');
$_firstSeg = '';
$slashPos = strpos($_first, '/');
if ($slashPos === false) { $_firstSeg = $_first; } else { $_firstSeg = substr($_first, 0, $slashPos); }

if ($_firstSeg !== '') {
    if (strcasecmp($_firstSeg, DYN_ADMIN_PATH) === 0) {
        // 匹配到配置的后台路径：把第一段替换为 admin，保证路由与控制器正常
        $_rest = substr($_first, strlen($_firstSeg));
        $_rewriteTo = 'admin' . $_rest;
        $_SERVER['PATH_INFO'] = '/' . ltrim($_rewriteTo, '/');
        if (isset($_GET['s'])) { $_GET['s'] = ltrim($_rewriteTo, '/'); }
    } elseif (strcasecmp($_firstSeg, 'admin') === 0 && strcasecmp(DYN_ADMIN_PATH, 'admin') !== 0) {
        // 访问旧 /admin 而配置路径已改变 → 直接 404，使旧地址立即失效
        http_response_code(404);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>404</title></head><body style="text-align:center;padding:80px;font-family:Microsoft YaHei;">';
        echo '<h1 style="font-size:60px;color:#c0392b;">404</h1>';
        echo '<p style="color:#888;">对不起，您访问的页面不存在或已被移除。</p>';
        echo '</body></html>';
        exit;
    }
}

// 定义应用目录
define('APP_PATH', __DIR__ . '/../app/');
define('PATH', __DIR__ . '/../');
// 加载框架引导文件
require __DIR__ . '/../frame/start.php';