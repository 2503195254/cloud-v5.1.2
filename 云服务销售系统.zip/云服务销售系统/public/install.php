<?php
/**
 * 云服务销售系统 · 一键安装程序 install.php
 * 流程：伪静态检测 → 环境检测 → 数据库配置 → 管理员设置 → 安装完成
 * 【缓存防护】本文件采用最强防护，彻底杜绝“上传新版本/已装却直接跳到安装完成”的缓存问题。
 */
error_reporting(E_ALL & ~E_DEPRECATED & ~E_WARNING & ~E_NOTICE & ~E_STRICT);
@ini_set('display_errors', 0);
@set_time_limit(0);
date_default_timezone_set('Asia/Shanghai');

/* ============ 最强缓存防护（必须最先执行） ============ */
// 1) 立即让本文件从 OPcache 中失效：上传新版本后当下次请求立即用新代码
if (function_exists('opcache_invalidate')) { @opcache_invalidate(__FILE__, true); }
if (function_exists('opcache_reset')) { @opcache_reset(); }
// 2) 清空 PHP 文件状态缓存，让 file_exists/is_dir 等实时反映磁盘
@clearstatcache(true);

// 安装页禁止任何缓存，覆盖 浏览器/中间层/代理/OPcache 等一切缓存
function no_cache_headers(){
    if (function_exists('header_remove')) {
        @header_remove('Cache-Control'); @header_remove('Pragma'); @header_remove('Expires');
        @header_remove('ETag'); @header_remove('Last-Modified'); @header_remove('Age');
        @header_remove('X-Cache'); @header_remove('X-Cache-Remote');
    }
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, post-check=0, pre-check=0, no-transform');
    header('Cache-Control: private, no-store, no-cache'); // 双保险：避免某些代理只认其中一种
    header('Pragma: no-cache');
    header('Expires: 0');
    header('Vary: *');
    // 旧协议头，兼容老浏览器/代理
    header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
    for ($i = 0; $i < 5; $i++) { header('Cache-Control: no-cache'); } // 用多个头进一步确保
}
if (function_exists('session_cache_limiter')) { @session_cache_limiter('nocache'); }
no_cache_headers();

define('ROOT', dirname(__DIR__));          // 网站根目录
define('APP',  ROOT . '/app');              // 应用目录
define('DB_FILE', APP . '/database.php');   // 数据库配置文件
define('SQL_FILE', ROOT . '/install/install.sql');
define('LOCK_FILE', ROOT . '/install/install.lock');
define('INSTALLING_FILE', APP . '/installing.lock'); // 安装过程锁
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}
/**
 * 判断是否“真正已安装”：
 * 1) 存在 install.lock 锁定标记
 * 2) database.php 已配置了数据库名
 * 3) 能成功连接该数据库（说明安装数据真正就绪）
 * 若 lock 存在但数据库未配置/无法连接，视为残留锁，返回 false 允许重新安装。
 */
function is_installed_value(){
    // 关键：清空文件状态缓存，避免 OPcache/磁盘 stat 缓存导致误判
    @clearstatcache(true);
    $lockFile = LOCK_FILE;
    if (!@file_exists($lockFile)) {
        return false;
    }
    // database.php 是否已写入数据库名（用文件内容判断，避免 include 被 OPcache 缓存旧值）
    if (!@file_exists(DB_FILE)) {
        @unlink($lockFile);
        return false;
    }
    $dbSrc = (string)@file_get_contents(DB_FILE);
    // 匹配 database 配置非空（形如 'database' => 'xxx'，且 xxx 非空）
    if (!preg_match("/['\\\"]database['\\\"]\\s*=>\\s*['\\\"]([^'\\\"]+)['\\\"]/", $dbSrc, $m) || trim($m[1]) === '') {
        @unlink($lockFile);
        return false;
    }
    // 解析连接参数（从文件内容提取，不依赖 include 缓存）
    $host = '127.0.0.1'; $port = '3306'; $user = ''; $pass = ''; $db = $m[1];
    if (preg_match("/['\\\"]hostname['\\\"]\\s*=>\\s*['\\\"]([^'\\\"]+)['\\\"]/", $dbSrc, $mm)) $host = $mm[1];
    if (preg_match("/['\\\"]hostport['\\\"]\\s*=>\\s*['\\\"]([^'\\\"]*)['\\\"]/", $dbSrc, $mm)) $port = $mm[1] !== '' ? $mm[1] : '3306';
    if (preg_match("/['\\\"]username['\\\"]\\s*=>\\s*['\\\"]([^'\\\"]*)['\\\"]/", $dbSrc, $mm)) $user = $mm[1];
    if (preg_match("/['\\\"]password['\\\"]\\s*=>\\s*['\\\"]([^'\\\"]*)['\\\"]/", $dbSrc, $mm)) $pass = $mm[1];
    if (!$user || !$db) {
        @unlink($lockFile);
        return false;
    }
    // 尝试连接，能连上才算真正已安装
    if (extension_loaded('PDO')) {
        try {
            $dsn = 'mysql:host=' . $host . ';port=' . $port . ';dbname=' . $db . ';charset=utf8';
            $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_TIMEOUT=>3]);
            if ($pdo) { return true; }
        } catch (\Throwable $e) {
            @unlink($lockFile);
            return false;
        }
    }
    return true; // 无PDO则按配置存在判定为已安装
}
$installed = is_installed_value();

/* ============ 工具函数 ============ */
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
// 清理 ThinkPHP 的 runtime 缓存目录（含文件、模板编译、日志），避免残留缓存干扰
function clear_framework_cache(){
    foreach (['runtime' => ROOT . '/runtime', 'compile' => ROOT . '/runtime/temp'] as $_cname => $_cpath) {
        if (!is_dir($_cpath)) { continue; }
        $items = @scandir($_cpath);
        if ($items === false) { continue; }
        foreach ($items as $it) {
            if ($it === '.' || $it === '..') { continue; }
            $full = $_cpath . '/' . $it;
            if (is_file($full) || is_link($full)) { @unlink($full); }
            elseif (is_dir($full)) {
                // 深度清理子目录，最多2层避免误删框架关键目录
                $sub = @scandir($full);
                if ($sub !== false) {
                    foreach ($sub as $s) {
                        if ($s === '.' || $s === '..') { continue; }
                        $sfull = $full . '/' . $s;
                        if (is_file($sfull)) { @unlink($sfull); }
                        elseif (is_dir($sfull)) { @rmdir($sfull); }
                    }
                }
                @rmdir($full);
            }
        }
    }
}

// 判断是否 HTTPS
function is_https(){
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
    if (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) return true;
    if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') return true;
    return false;
}
function base_url(){
    $scheme = is_https() ? 'https' : 'http';
    $host   = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    $dir    = rtrim(str_replace('\\','/', dirname($_SERVER['SCRIPT_NAME'])), '/');
    return $scheme . '://' . $host . $dir;
}

// 目录可写检测
function check_writable($path){
    return is_writable($path);
}
// 尽力将该目录设置为可写（0777），保证 Web 用户/属主都能写入
function chmod_dir($path, $mode=0777){
    if (is_dir($path)) {
        @chmod($path, $mode);
        // 尝试递归确保 runtime 子目录也可写（部分框架需写 temp/log）
        if ($path === ROOT . '/runtime') {
            $items = @scandir($path);
            if ($items !== false) {
                foreach ($items as $it) {
                    if ($it === '.' || $it === '..') { continue; }
                    $sub = $path . '/' . $it;
                    if (is_dir($sub)) { @chmod($sub, $mode); }
                }
            }
        }
        @clearstatcache(true);
    }
}

// 环境检测结果
function env_checks(){
    @clearstatcache(true);
    $checks = [];
    $checks['php_version']  = version_compare(PHP_VERSION, '5.6', '>=') ? ['ok'=>true,'cur'=>PHP_VERSION,'need'=>'5.6+'] : ['ok'=>false,'cur'=>PHP_VERSION,'need'=>'5.6+'];
    $need = ['PDO','pdo_mysql','mbstring','curl','openssl','fileinfo','gd'];
    foreach ($need as $ext) {
        $checks['ext_'.$ext] = extension_loaded($ext) ? ['ok'=>true,'cur'=>'已加载','need'=>$ext] : ['ok'=>false,'cur'=>'未加载','need'=>$ext];
    }
    // 目录可写：自动尝试 chmod 为可写，避免 0755 导致 Web 用户无法写入
    $dirs = [
        'runtime目录' => ROOT . '/runtime',
        'app目录'     => APP,
        'install目录' => ROOT . '/install',
    ];
    foreach ($dirs as $name => $dir) {
        // 确保目录存在
        if (!is_dir($dir)) { @mkdir($dir, 0777, true); }
        // 尝试设置可写权限（不可用 @chmod 失败时不影响判断，以实际 is_writable 为准）
        @chmod($dir, 0777);
        @clearstatcache(true);
        $writable = (is_dir($dir) && is_writable($dir));
        // 若仍不可写，给出清晰的修复指引
        $checks['dir_'.$name] = $writable
            ? ['ok'=>true,'cur'=>'可写','need'=>$name]
            : ['ok'=>false,'cur'=>'不可写(请将目录权限设为 777 或 可写)','need'=>$name];
    }
    return $checks;
}

// 校验重写是否开启
function check_rewrite(){
    // PHP 内置开发服务器是单线程的，无法自我发起 HTTP 请求（会死锁），改为提示手动确认
    $server = isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : '';
    if (stripos($server, 'Development Server') !== false) {
        return ['ok'=>-1,'msg'=>'检测到正在使用 PHP 内置开发服务器（不支持伪静态），请在生产环境（Apache/Nginx）配置伪静态后访问。'];
    }
    $base = rtrim(preg_replace('#/install\.php$#i','',base_url()), '/');
    $token = 'RT' . substr(md5(uniqid()),0,8);
    $url   = $base . '/__rewrite__' . $token;
    $body  = http_get($url, 5);
    if ($body !== false && strpos($body, 'REWRITE_OK:') === 0) {
        return ['ok'=>true,'msg'=>'伪静态/URL重写已正确开启'];
    }
    return ['ok'=>false,'msg'=>'未能通过伪静态自检，请先配置伪静态再继续'];
}

function http_get($url, $timeout=8){
    // 尝试 file_get_contents
    $opts = ['http'=>['timeout'=>$timeout,'method'=>'GET','follow_location'=>1,'max_redirects'=>2,'header'=>"User-Agent: install-probe\r\n"]];
    $ctx = stream_context_create($opts);
    $fp = @fopen($url, 'r', false, $ctx);
    if ($fp) {
        $body = @stream_get_contents($fp);
        @fclose($fp);
        if ($body !== false) return $body;
    }
    if (function_exists('curl_init')) {
        $ch = @curl_init();
        @curl_setopt_array($ch, [CURLOPT_URL=>$url, CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>$timeout, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_MAXREDIRS=>2, CURLOPT_USERAGENT=>'install-probe']);
        $body = @curl_exec($ch);
        @curl_close($ch);
        if ($body !== false) return $body;
    }
    return false;
}

// SQL 拆分为可执行语句
function split_sql($sql){
    // 去掉注释行
    $lines = preg_split('/\r\n|\r|\n/', $sql);
    $out = [];
    foreach ($lines as $line) {
        $t = ltrim($line);
        if ($t === '' || strpos($t,'--') === 0 || strpos($t,'#') === 0 || strpos($t,'/*') === 0) {
            continue;
        }
        $out[] = $line;
    }
    $buffer = '';
    $result = [];
    foreach ($out as $line) {
        $buffer .= $line . "\n";
        if (substr(rtrim($line), -1) === ';') {
            $result[] = trim($buffer);
            $buffer = '';
        }
    }
    if (trim($buffer) !== '') { $result[] = trim($buffer); }
    return $result;
}

// 执行 SQL 文件（支持表前缀替换，兼容单/多库）
function exec_sql_file($pdo, $file, $prefix_replace = false){
    if (!file_exists($file)) return ['ok'=>false,'msg'=>'未找到 install/install.sql 安装数据文件'];
    $sql = file_get_contents($file);
    // 表前缀替换：install.sql 使用 yun_ 前缀
    if ($prefix_replace && is_array($prefix_replace)) {
        $from = $prefix_replace['from'];
        $to   = $prefix_replace['to'];
        if ($from !== $to) {
            $sql = str_replace('`' . $from, '`' . $to, $sql);
        }
    }
    $statements = split_sql($sql);
    $count = 0;
    foreach ($statements as $stmt) {
        try {
            $pdo->exec($stmt);
            $count++;
            // 处理需要在后续语句执行后才生效的主键/AUTO_INCREMENT
        } catch (\Throwable $e) {
            // 某些 ALTER 可能因已存在主键而失败，忽略继续
            $msg = $e->getMessage();
            if (stripos($stmt, 'ALTER') !== false && (stripos($msg,'already')!==false || stripos($msg,'Duplicate')!==false || stripos($msg,'multiple primary')!==false)) {
                continue;
            }
            if (stripos($stmt, 'CREATE TABLE') !== false || stripos($stmt,'INSERT') !== false) {
                return ['ok'=>false,'msg'=>'执行SQL失败: ' . $msg . ' <br/>语句: ' . e(substr($stmt,0,200))];
            }
            continue;
        }
    }
    return ['ok'=>true,'count'=>$count];
}

/* ============ 处理 POST ============ */

// 步骤1：伪静态确认（继续到环境检测）
if (isset($_POST['action']) && $_POST['action'] === 'rewrite_ok') {
    $_SESSION['install_step'] = 'env';
    header('Location: install.php?step=env'); exit;
}
// 步骤2：环境检测确认
if (isset($_POST['action']) && $_POST['action'] === 'env_ok') {
    $_SESSION['install_step'] = 'db';
    header('Location: install.php?step=db'); exit;
}
// 步骤3：数据库配置提交
if (isset($_POST['action']) && $_POST['action'] === 'db_submit') {
    $host     = trim($_POST['dbhost'] ?? '127.0.0.1');
    $port     = trim($_POST['dbport'] ?? '3306');
    $name     = trim($_POST['dbname'] ?? '');
    $user     = trim($_POST['dbuser'] ?? '');
    $pass     = $_POST['dbpass'] ?? '';
    $prefix   = trim($_POST['dbprefix'] ?? 'yun_');
    $useSocket= isset($_POST['dbsocket']) ? trim($_POST['dbsocket']) : '';

    if ($name === '' || $user === '') {
        $db_error = '数据库名和数据库用户不能为空';
    } else {
        try {
            $dsn = 'mysql:host=' . $host . ';port=' . $port . ';charset=utf8';
            if ($useSocket !== '') { $dsn = 'mysql:unix_socket=' . $useSocket . ';charset=utf8'; }
            $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
            // 尝试创建数据库（虚拟主机通常已建好库，无权限创建时忽略）
            try {
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . str_replace('`','',$name) . "` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci");
            } catch (\Throwable $e) {
                // 无建库权限：若库已存在可正常连接则继续
            }
            try {
                $pdo->exec("USE `" . str_replace('`','',$name) . "`");
            } catch (\Throwable $e) {
                $db_error = '无法使用数据库「' . $name . '」：' . $e->getMessage() . '。提示：多数虚拟主机的数据库需在主机控制面板中预先创建，且当前账号需拥有该库权限。';
                throw new \RuntimeException($db_error);
            }
            // 导入数据结构
            $res = exec_sql_file($pdo, SQL_FILE, ['from'=>'yun_','to'=>$prefix]);
            if (!$res['ok']) {
                $db_error = $res['msg'];
            } else {
                // 保存数据库配置到 app/database.php
                $prefixQuoted = "'" . addslashes($prefix) . "'";
                $dbCfg = '<?php' . "\n"
                    . 'return [' . "\n"
                    . "    'type'            => 'mysql',\n"
                    . "    'hostname'        => " . var_export($host,true) . ",\n"
                    . "    'database'        => " . var_export($name,true) . ",\n"
                    . "    'username'        => " . var_export($user,true) . ",\n"
                    . "    'password'        => " . var_export($pass,true) . ",\n"
                    . "    'hostport'        => " . var_export($port,true) . ",\n"
                    . "    'dsn'             => '',\n"
                    . "    'params'          => [],\n"
                    . "    'charset'         => 'utf8',\n"
                    . "    'prefix'          => " . var_export($prefix,true) . ",\n"
                    . "    'debug'           => true,\n"
                    . "    'deploy'          => 0,\n"
                    . "    'rw_separate'     => false,\n"
                    . "    'master_num'      => 1,\n"
                    . "    'slave_no'        => '',\n"
                    . "    'read_master'     => false,\n"
                    . "    'fields_strict'   => true,\n"
                    . "    'resultset_type'  => 'array',\n"
                    . "    'auto_timestamp'  => false,\n"
                    . "    'datetime_format' => 'Y-m-d H:i:s',\n"
                    . "    'sql_explain'     => false,\n"
                    . "];\n";
                if (!@file_put_contents(DB_FILE, $dbCfg)) {
                    $db_error = '无法写入数据库配置文件 ' . DB_FILE . '，请检查 app 目录写入权限';
                } else {
                    $_SESSION['install_db'] = ['prefix'=>$prefix, 'name'=>$name];
                    $_SESSION['install_step'] = 'admin';
                    header('Location: install.php?step=admin'); exit;
                }
            }
        } catch (\Throwable $e) {
            $db_error = '数据库连接失败：' . $e->getMessage();
        }
    }
    $_SESSION['install_step'] = 'db';
}

// 步骤4：管理员设置提交
if (isset($_POST['action']) && $_POST['action'] === 'admin_submit') {
    $aname = trim($_POST['adminname'] ?? '');
    $auser = trim($_POST['adminuser'] ?? '');
    $apass = $_POST['adminpass'] ?? '';
    $apass2= $_POST['adminpass2'] ?? '';
    $amail = trim($_POST['adminmail'] ?? '');
    $prefix = $_SESSION['install_db']['prefix'] ?? 'yun_';
    $dbname = $_SESSION['install_db']['name'] ?? '';

    $aerror = '';
    if ($auser === '' || $aname === '' || $apass === '') {
        $aerror = '管理员账号、昵称、密码均不能为空';
    } elseif (strlen($apass) < 6) {
        $aerror = '管理员密码至少 6 位';
    } elseif ($apass !== $apass2) {
        $aerror = '两次输入的密码不一致';
    } elseif ($amail !== '' && !filter_var($amail, FILTER_VALIDATE_EMAIL)) {
        $aerror = '邮箱格式不正确';
    } else {
        try {
            // 复用数据库配置连接
            $dbCfg = require DB_FILE;
            $dsn = 'mysql:host=' . $dbCfg['hostname'] . ';port=' . ($dbCfg['hostport'] ?: '3306' ) . ';dbname=' . $dbCfg['database'] . ';charset=utf8';
            $pdo = new PDO($dsn, $dbCfg['username'], $dbCfg['password'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
            $table = '`' . $prefix . 'admin`';
            // 先清空可能存在的默认管理员
            $pdo->exec("DELETE FROM " . $table);
            $sql = "INSERT INTO " . $table . " (`name`,`qq`,`user`,`password`,`mail`) VALUES (?,?,?,?,?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$aname, '', $auser, password_hash($apass, PASSWORD_DEFAULT), $amail]);

            // 写入安装完成锁定标记
            file_put_contents(LOCK_FILE, date('Y-m-d H:i:s') . " PKG=vhss\n");
            @touch(INSTALLING_FILE);
            @unlink(INSTALLING_FILE);
            // 安装完成后清理框架缓存，避免旧缓存导致首页/后台数据异常
            clear_framework_cache();
            no_cache_headers();
            if (function_exists('opcache_reset')) { @opcache_reset(); }
            @clearstatcache(true);
            // 记录管理员信息用于完成页展示
            $_SESSION['install_done'] = ['user'=>$auser, 'pass'=>$apass, 'mail'=>$amail, 'prefix'=>$prefix, 'dbname'=>$dbname];
            $_SESSION['install_step'] = 'done';
            header('Location: install.php?step=done'); exit;
        } catch (\Throwable $e) {
            $aerror = '保存管理员数据失败：' . $e->getMessage();
        }
    }
    $_SESSION['install_step'] = 'admin';
}

/* ============ 渲染 ============ */
// 关键：step 完全由 URL 参数决定，绝不依赖 session 中的残留值，防止 session 里旧 done 导致直接跳到安装完成页
no_cache_headers();
@clearstatcache(true);
if (function_exists('opcache_invalidate')) { @opcache_invalidate(__FILE__, true); }

$stepArr = ['rewrite','env','db','admin','done'];
$reqStep = $_GET['step'] ?? '';
// 表单提交（POST）且填错返回时，用 session 暂存的上一步继续（但绝不回退到 done）
if ($reqStep === '' && !empty($_POST['action'])) {
    $sessStep = $_SESSION['install_step'] ?? '';
    if ($sessStep !== 'done' && in_array($sessStep, $stepArr, true)) {
        $reqStep = $sessStep;
    }
}
$step = in_array($reqStep, $stepArr, true) ? $reqStep : '';

// 强制重新安装：清锁 + 重置 session，完全重新走安装向导
if (($_GET['reset'] ?? '') === '1') {
    @unlink(LOCK_FILE);
    @clearstatcache(true);
    // 清除所有安装相关 session，避免残留 done/db/admin 影响
    unset($_SESSION['install_step'], $_SESSION['install_db'], $_SESSION['install_done'], $_SESSION['install_admin']);
    $step = 'rewrite';
    if (!in_array($step, $stepArr, true)) { $step = 'rewrite'; }
    no_cache_headers();
    header('Location: install.php?step=rewrite'); exit;
}

// 重新检测真实安装状态
$installed = is_installed_value();
if ($installed) {
    no_cache_headers();
    // 已安装的情况下，仅允许显式访问 step=done 的完成页（用于安装刚完成的回显）
    $allowDone = ($step === 'done' && !empty($_SESSION['install_done']));
    // 若已安装且不是回显完成页，则显示“系统已安装”提示页（含重新安装入口）
    if (!$allowDone) {
        render_already_installed($step);
        exit;
    }
}
// 未安装：step 必须从明文步骤开始；若是 done 但并未真处于安装完成态，强制回到第一步
if (!$installed && $step === 'done') {
    $step = 'rewrite';
}
if (!in_array($step, $stepArr, true)) { $step = 'rewrite'; }
// 每次渲染前再次确保无缓存
no_cache_headers();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>云服务销售系统 - 安装向导</title>
<style>
:root{--sb:#0052d9;--sbl:#006eff;--bg:#f4f7fb;--card:#fff;--line:#e5e9f0;}
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:"PingFang SC","Microsoft YaHei",Arial,sans-serif;background:var(--bg);color:#1d2b3a;min-height:100vh;}
.wrap{max-width:760px;margin:0 auto;padding:30px 16px 50px;}
.logo{text-align:center;margin-bottom:24px;}
.logo h1{font-size:22px;color:#0a2540;letter-spacing:1px;}
.logo p{color:#8a96a8;font-size:13px;margin-top:6px;}
.steps{display:flex;margin-bottom:26px;background:#fff;border:1px solid var(--line);border-radius:10px;padding:14px 10px;}
.step{flex:1;text-align:center;position:relative;font-size:13px;color:#9aa7b8;}
.step .dot{width:26px;height:26px;line-height:26px;border-radius:50%;background:#e8eef7;color:#70809a;margin:0 auto 6px;font-weight:600;}
.step.active .dot{background:var(--sb);color:#fff;}
.step.done .dot{background:#00b870;color:#fff;}
.step.active{color:var(--sb);font-weight:600;}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:26px 28px;margin-bottom:16px;}
.card h2{font-size:18px;color:#0a2540;margin-bottom:6px;}
.card .desc{color:#8a96a8;font-size:13px;margin-bottom:18px;line-height:1.7;}
label{display:block;font-size:13px;color:#3d4c5e;margin:14px 0 6px;}
input[type=text],input[type=password],input[type=email],select{width:100%;padding:10px 12px;border:1px solid #cdd6e2;border-radius:6px;font-size:14px;color:#1d2b3a;background:#fff;}
input:focus,select:focus{outline:none;border-color:var(--sbl);box-shadow:0 0 0 3px rgba(0,110,255,.12);}
.btn{display:inline-block;background:var(--sb);color:#fff;border:none;padding:11px 26px;border-radius:6px;font-size:14px;cursor:pointer;}
.btn:hover{background:var(--sbl);}
.btn.ghost{background:#fff;color:var(--sb);border:1px solid var(--sbl);margin-left:8px;}
.row-right{text-align:right;margin-top:20px;}
.alert{padding:12px 14px;border-radius:6px;font-size:13px;margin-bottom:14px;line-height:1.7;}
.alert.ok{background:#e9f8f0;border:1px solid #b8e6cf;color:#0d7a44;}
.alert.err{background:#fdeeee;border:1px solid #f5c2c2;color:#c03528;}
.alert.info{background:#eef4ff;border:1px solid #c6d9ff;color:#1f5fd0;}
table.kv{width:100%;border-collapse:collapse;font-size:13px;}
table.kv td,table.kv th{border:1px solid var(--line);padding:9px 12px;text-align:left;}
table.kv th{background:#f7f9fc;color:#5a6a7d;width:36%;}
table.kv td{color:#2c3e50;}
.okmark{color:#00b870;font-weight:700;}
.errmark{color:#e1352b;font-weight:700;}
pre.code{background:#11213a;color:#cdd9ec;padding:14px;border-radius:8px;font-size:12px;overflow:auto;line-height:1.6;margin:10px 0;}
.hint{font-size:12px;color:#8a96a8;margin-top:6px;}
.success-icon{width:64px;height:64px;border-radius:50%;background:#00b870;color:#fff;font-size:34px;line-height:64px;text-align:center;margin:0 auto 18px;}
.f{display:flex;gap:8px;}
.f input{flex:1;}
#copyBtn{cursor:pointer;}
</style>
</head>
<body>
<div class="wrap">
  <div class="logo">
    <h1>云服务销售系统</h1>
    <p>一键安装向导 · 请按步骤完成配置</p>
  </div>
  <div class="steps">
    <div class="step <?php echo step_cls($step,'rewrite','rewrite','env');?>">
      <div class="dot">1</div>伪静态检测</div>
    <div class="step <?php echo step_cls($step,'env','env','db');?>">
      <div class="dot">2</div>环境检测</div>
    <div class="step <?php echo step_cls($step,'db','db','admin');?>">
      <div class="dot">3</div>数据库设置</div>
    <div class="step <?php echo step_cls($step,'admin','admin','done');?>">
      <div class="dot">4</div>管理员设置</div>
    <div class="step <?php echo step_cls($step,'done','done','');?>">
      <div class="dot">✓</div>安装完成</div>
  </div>

<?php
function step_cls($current, $thisStep, $activeStep, $doneStep){
    if ($current === $thisStep) {
        return ($thisStep === $doneStep || ($activeStep===$thisStep && $current===$thisStep)) ? 'active' : ($current===$doneStep?'done':'active');
    }
    $order = ['rewrite'=>1,'env'=>2,'db'=>3,'admin'=>4,'done'=>5];
    $curIdx = $order[$current] ?? 0;
    $thisIdx = $order[$thisStep] ?? 0;
    if ($curIdx > $thisIdx) return 'done';
    return '';
}
?>

<?php if ($step === 'rewrite'): ?>
  <div class="card">
    <h2>第一步：伪静态检测</h2>
    <div class="desc">请先将网站的 <b>运行目录</b> 设置为 <code>public</code>，并开启伪静态（URL重写），使地址形如 <b>/admin/login</b> 无需 <code>index.php</code> 即可访问。</div>
    <?php
      $rw = check_rewrite();
      $apacheConfig = '&lt;IfModule mod_rewrite.c&gt;
  Options +FollowSymlinks -Multiviews
  RewriteEngine On
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteRule ^(.*)$ index.php/$1 [QSA,PT,L]
&lt;/IfModule&gt;';
      $nginxConfig = 'location / {
    index index.php index.html;
    try_files $uri $uri/ /index.php$is_args$args;
}
# 伪静态备选写法参考
# if (!-e $request_filename) { rewrite ^(.*)$ /index.php?s=$1 last; }';
      if ($rw['ok'] === true) {
          echo '<div class="alert ok">✓ ' . e($rw['msg']) . '</div>';
          $showConfig = false;
      } elseif ($rw['ok'] === -1) {
          echo '<div class="alert info">ℹ ' . e($rw['msg']) . '</div>';
          echo '<div class="desc">若你已部署到 Apache/Nginx 并已配置伪静态，可跳过自动检测直接继续；否则请按下述规则配置：</div>';
          $showConfig = true;
      } else {
          echo '<div class="alert err">✗ ' . e($rw['msg']) . '</div>';
          echo '<div class="desc">请根据你的服务器选择并配置对应伪静态规则：</div>';
          $showConfig = true;
      }
      if (!empty($showConfig)) {
          echo '<div class="desc">【Apache 服务器】将以下内容保存为 public/.htaccess（宝塔/Apache 选择 thinkphp 伪静态后粘贴）：</div>';
          echo '<pre class="code">' . $apacheConfig . '</pre>';
          echo '<div class="desc">【Nginx 服务器】在站点配置的 server{} 内 location / 添加（宝塔伪静态选择“thinkphp”即可）：</div>';
          echo '<pre class="code">' . $nginxConfig . '</pre>';
          echo '<div class="desc">配置完成后点击“重新检测”，若自动检测受限也可直接点击“我已配置伪静态，继续安装”。</div>';
      }
    ?>
    <form method="post" action="install.php">
      <input type="hidden" name="action" value="rewrite_ok">
      <div class="row-right">
          <a class="btn ghost" href="install.php?step=rewrite">重新检测</a>
          <button type="submit" class="btn">下一步：环境检测 →</button>
      </div>
    </form>
  </div>
<?php elseif ($step === 'env'): ?>
  <div class="card">
    <h2>第二步：环境检测</h2>
    <div class="desc">以下项目必须全部通过才可以继续安装。</div>
    <?php $ec = env_checks(); $allOk = true; ?>
    <table class="kv">
      <tr><th>检查项</th><th>要求</th><th>当前状态</th><th>结果</th></tr>
      <?php foreach ($ec as $k=>$v):
          if (!$v['ok']) $allOk = false; ?>
      <tr>
        <td><?php echo e(ucfirst(str_replace(['ext_','dir_','php_version'],['扩展: ','目录: ','PHP版本'],$k))); ?></td>
        <td><?php echo e($v['need']); ?></td>
        <td><?php echo e($v['cur']); ?></td>
        <td><?php echo $v['ok'] ? '<span class="okmark">通过</span>' : '<span class="errmark">失败</span>'; ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
    <form method="post" action="install.php">
      <input type="hidden" name="action" value="env_ok">
      <div class="row-right">
        <a class="btn ghost" href="install.php?step=env">重新检测</a>
        <?php if ($allOk): ?>
          <button type="submit" class="btn">下一步：数据库设置 →</button>
        <?php else: ?>
          <button type="button" class="btn" onclick="alert('存在未通过项，请先解决上面的问题再继续。')">请先修复环境</button>
        <?php endif; ?>
      </div>
    </form>
  </div>

<?php elseif ($step === 'db'): ?>
  <div class="card">
    <h2>第三步：数据库设置</h2>
    <div class="desc">请填写数据库连接信息。安装程序会自动创建数据库并导入数据表。</div>
    <?php if (!empty($db_error)) echo '<div class="alert err">' . e($db_error) . '</div>'; ?>
    <form method="post" action="install.php">
      <input type="hidden" name="action" value="db_submit">
      <div class="f">
        <div style="flex:2"><label>数据库主机</label><input type="text" name="dbhost" value="<?php echo e($_POST['dbhost'] ?? '127.0.0.1'); ?>"></div>
        <div style="flex:1"><label>端口</label><input type="text" name="dbport" value="<?php echo e($_POST['dbport'] ?? '3306'); ?>"></div>
      </div>
      <label>数据库名</label>
      <input type="text" name="dbname" value="<?php echo e($_POST['dbname'] ?? 'vhss'); ?>" placeholder="例如 vhss">
      <label>数据库用户</label>
      <input type="text" name="dbuser" value="<?php echo e($_POST['dbuser'] ?? ''); ?>" placeholder="请输入数据库用户名">
      <label>数据库密码</label>
      <input type="password" name="dbpass" value="" placeholder="请输入数据库密码">
      <label>数据表前缀</label>
      <input type="text" name="dbprefix" value="<?php echo e($_POST['dbprefix'] ?? 'yun_'); ?>">
      <label>Unix Socket（可选，虚拟主机一般留空）</label>
      <input type="text" name="dbsocket" value="" placeholder="留空即可，如 /tmp/mysql.sock">
      <div class="row-right">
        <a class="btn ghost" href="install.php?step=env">上一步</a>
        <button type="submit" class="btn">下一步：管理员设置 →</button>
      </div>
    </form>
  </div>

<?php elseif ($step === 'admin'): ?>
  <div class="card">
    <h2>第四步：管理员设置</h2>
    <div class="desc">设置后台超级管理员账号信息，请务必牢记。</div>
    <?php if (!empty($aerror)) echo '<div class="alert err">' . e($aerror) . '</div>'; ?>
    <form method="post" action="install.php">
      <input type="hidden" name="action" value="admin_submit">
      <label>管理员昵称</label>
      <input type="text" name="adminname" value="<?php echo e($_POST['adminname'] ?? '超级管理员'); ?>">
      <label>管理员账号</label>
      <input type="text" name="adminuser" value="<?php echo e($_POST['adminuser'] ?? 'admin'); ?>">
      <label>管理员密码（至少6位）</label>
      <input type="password" name="adminpass" value="" placeholder="请输入登录密码">
      <label>确认密码</label>
      <input type="password" name="adminpass2" value="" placeholder="请再次输入密码">
      <label>管理员邮箱</label>
      <input type="email" name="adminmail" value="<?php echo e($_POST['adminmail'] ?? ''); ?>" placeholder="用于接收系统通知">
      <div class="row-right">
        <a class="btn ghost" href="install.php?step=db">上一步</a>
        <button type="submit" class="btn">完成安装 →</button>
      </div>
    </form>
  </div>

<?php elseif ($step === 'done'): ?>
  <?php
    $info = $_SESSION['install_done'] ?? ['user'=>'admin','pass'=>'','mail'=>'','prefix'=>'yun_','dbname'=>''];
    $base = rtrim(preg_replace('#/install\.php$#i','',base_url()), '/');
    $frontUrl = $base . '/';
    $adminUrl = $base . '/admin';
  ?>
  <div class="card" style="text-align:center;">
    <div class="success-icon">✓</div>
    <h2 style="margin-bottom:10px;">恭喜！安装完成</h2>
    <div class="desc">系统已成功安装，以下是你的初始信息，请务必妥善保存。</div>
    <table class="kv" style="margin:0 auto;max-width:480px;">
      <tr><th>后台管理员账号</th><td><?php echo e($info['user']); ?></td></tr>
      <tr><th>后台登录密码</th><td><?php echo e($info['pass']); ?></td></tr>
      <tr><th>管理员邮箱</th><td><?php echo e($info['mail']); ?></td></tr>
      <tr><th>前台地址</th><td><a href="<?php echo e($frontUrl); ?>" target="_blank"><?php echo e($frontUrl); ?></a></td></tr>
      <tr><th>后台地址</th><td><a href="<?php echo e($adminUrl); ?>" target="_blank"><?php echo e($adminUrl); ?></a></td></tr>
    </table>
    <div class="alert info" style="margin-top:18px;text-align:left;">
      为安全起见，请尽快登录后台修改管理员密码，并妥善保管 <code>install/install.lock</code> 文件。
      如需重新安装，请删除 install/install.lock 后访问本安装向导。
    </div>
    <div class="row-right" style="text-align:center;margin-top:24px;">
      <a class="btn" href="<?php echo e($frontUrl); ?>">前往前台</a>
      <a class="btn" style="margin-left:10px;" href="<?php echo e($adminUrl); ?>">进入后台</a>
    </div>
    <div style="margin-top:22px;padding-top:18px;border-top:1px dashed #d5dfec;">
      <div class="desc" style="text-align:center;font-size:12px;color:#8a96a8;margin-bottom:10px;">
        ⚠ 如需完全重置，请彻底删除数据库中的所有表后再执行强制重装。
      </div>
      <div style="text-align:center;">
        <a class="btn" style="background:#e54545;border-color:#e54545;margin:0 5px;"
           href="<?php echo e($base); ?>/install.php?reset=1"
           onclick="return confirm('确定要强制重新安装吗？\n\n这会清除安装锁定并重新进入安装向导。\n注意：原数据库数据不会被自动删除，重新安装会重新导入数据表并可能覆盖数据。\n请务必先备份数据库！');">
           强制重新安装
        </a>
      </div>
    </div>
  </div>

<?php endif; ?>
</div>
</body>
</html>

<?php
/* ============ 已安装提示页 ============ */
function render_already_installed($step){
    no_cache_headers();
    $base = rtrim(preg_replace('#/install\.php$#i','',base_url()), '/');
    $frontUrl = $base . '/';
    $adminUrl = $base . '/admin';
    echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>系统已安装</title>';
    echo '<style>
        body{font-family:"PingFang SC","Microsoft YaHei",Arial,sans-serif;background:#f4f7fb;color:#1d2b3a;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;}
        .box{background:#fff;border:1px solid #e5e9f0;border-radius:12px;padding:36px 40px;max-width:520px;width:90%;text-align:center;box-shadow:0 6px 24px rgba(0,0,0,.05);}
        .box h1{font-size:20px;color:#0a2540;margin-bottom:10px;}
        .box p{color:#8a96a8;font-size:14px;line-height:1.7;margin-bottom:22px;}
        .btn{display:inline-block;background:#0052d9;color:#fff;text-decoration:none;padding:11px 24px;border-radius:6px;font-size:14px;margin:5px;}
        .btn:hover{background:#006eff;}
        .btn.ghost{background:#fff;color:#0052d9;border:1px solid #0052d9;}
        .warn{background:#fff7e6;border:1px solid #ffe1a8;color:#8a6100;border-radius:6px;padding:10px;font-size:12px;margin-top:16px;}
    </style></head><body><div class="box">';
    echo '<h1>系统已安装</h1>';
    echo '<p>检测到本系统已完成安装。<br/>如需清除锁定并重新安装，请点击下方「重新安装」按钮；为避免数据被覆盖，请务必先备份数据库。</p>';
    echo '<a class="btn" href="' . e($frontUrl) . '">前往前台</a>';
    echo '<a class="btn" href="' . e($adminUrl) . '">进入后台</a>';
    echo '<br/><br/>';
    echo '<a class="btn ghost" href="install.php?reset=1" style="cursor:pointer;">清除锁定 · 重新安装</a>';
    echo '<div class="warn">重新安装会重新导入数据表并覆盖原数据库数据，请先备份！如不确定请勿点击。</div>';
    echo '</div></body></html>';
    exit;
}
