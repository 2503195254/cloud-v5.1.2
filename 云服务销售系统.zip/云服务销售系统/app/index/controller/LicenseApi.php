<?php
namespace app\index\controller;
use think\Controller;

/**
 * 授权插件：授权端对外验证接口入口
 * 路由：/license_api/:action  -> 调用插件 license.php 的 license_dispatch
 * action: verify(验证) / bind(绑定域名) / query(免登录查询)
 * 本控制器仅当授权插件存在时工作，不影响系统其余功能。
 */
class LicenseApi extends Controller
{
    public function index($action = '')
    {
        $action = trim($action);
        if ($action === '') {
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['code' => -1, 'msg' => '缺少接口参数']));
        }
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $action)) {
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['code' => -1, 'msg' => '参数格式非法']));
        }
        $entry = PATH . 'plugins/license/license/license.php';
        if (!is_file($entry)) {
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['code' => -1, 'msg' => '授权插件未安装']));
        }
        include_once $entry;
        if (!function_exists('license_dispatch')) {
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['code' => -1, 'msg' => '授权插件未就绪']));
        }
        license_dispatch($action);
        header('Content-Type: application/json; charset=utf-8');
        exit(json_encode(['code' => -1, 'msg' => '接口无返回']));
    }
}